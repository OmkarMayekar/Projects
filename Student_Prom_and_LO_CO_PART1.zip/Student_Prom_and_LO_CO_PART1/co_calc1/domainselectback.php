<?php
include("db.php");
include("db1.php");

$choice=$_POST['choice'];
//echo "$domainname";
if ($choice=="a") {
	$domainname="domain".$_POST['domaino'];
$sql="SELECT * FROM $domainname";
$result=mysqli_query($conn,$sql); 
		$row = mysqli_fetch_array($result);
			echo $row['Domain_Name'];
		}

elseif ($choice=="b") {
			$domainname="domain".$_POST['domaino'];
			$sql="SELECT * FROM $domainname";
			$result=mysqli_query($conn,$sql); ?>
			<select  name="tcname" id="tcname" class="tcname" onchange="fun()">
			<option>Select Theory Course Name</option>
			<?php
		while($row = mysqli_fetch_array($result))
		{
			echo"<option>";
		    echo $row['Course_Name']; 
			echo "</option>";
		}

		echo "</select>";
		}

		elseif ($choice=="c") {
			//echo $_POST['uniquecode'];
			 $Course_Name=$_POST['coursename'];
			$domainname="domain".$_POST['domaino']; echo "<br>";
			//echo "$Course_Name";
			$sql="SELECT * FROM $domainname WHERE Course_Name='$Course_Name'";
			$result1=mysqli_query($conn,$sql);
			//if($result1){echo "string";}else {echo "false";}
			$rowcount=mysqli_num_rows($result1);
			if ($rowcount==0) {
			echo "$rowcount";
				
			}
			else{
			$row = mysqli_fetch_assoc($result1);
			echo $row['Course_Code'];
		}
		}
		elseif($choice=="d"){
			$domainname="domain".$_POST['domaino']; 
			$sql="SELECT * FROM $domainname";
			$result=mysqli_query($conn,$sql); ?>
			<select  name="lcname" id="lcname" class="lcname" onchange="fun1()">
			<option>Select Theory Course Outcome Name</option>
			<?php
		while($row = mysqli_fetch_array($result))
		{
			echo"<option>";
		    echo $row['Course_Name']; 
			echo "</option>";
		}

		echo "</select>";
		

		}

		elseif($choice=="e"){
			$domainname="domain".$_POST['domaino']; 
			$Course_Name=$_POST['coursename'];
			$sql="SELECT * FROM $domainname WHERE Course_Name='$Course_Name'";
			$result3=mysqli_query($conn,$sql);
			// if (!$result3) {
			// 	echo "string";
			// 	# code...
			// }else{echo "Success";}

			$row3=mysqli_fetch_assoc($result3);
			echo $row3['Course_Code'];
		

		}
		elseif($choice=="f"){
			$domainname="domain".$_POST['domaino']; 
			$Course_Name=$_POST['coursename'];
			$sql="SELECT * FROM $domainname WHERE Course_Name='$Course_Name'";
			$result3=mysqli_query($conn,$sql);
			// if (!$result3) {
			// 	echo "string";
			// 	# code...
			// }else{echo "Success";}

			$row3=mysqli_fetch_assoc($result3);
			echo $row3['Semester'];
		

		}
		
?>