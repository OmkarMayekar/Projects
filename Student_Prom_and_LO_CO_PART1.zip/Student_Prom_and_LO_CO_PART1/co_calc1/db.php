<?php
/* Database connection settings */
$host = 'localhost';
$user = 'root';
$pass = 'donquixote';
$db = 'domaininfo';
$conn = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
?>
