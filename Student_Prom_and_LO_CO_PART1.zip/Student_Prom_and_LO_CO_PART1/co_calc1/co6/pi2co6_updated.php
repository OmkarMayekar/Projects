<?php

include_once('db.php');

$percen26=array();
$wtg26=array();
$ten26=array();
$att26=array();
/*session_start();*/
$ttlm26=array();
?>

<!DOCTYPE html>

<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI2 CO1

    </title>

  </head>

  <body>

    <table class='table table-bordered ' class='table table-hover'>

      

        
    

      <?php

$sqlwght = "SELECT * FROM `CO_IA_Mapping` WHERE Course_Outcome_Number=6";

$result_newwght = $conn3->query($sqlwght);

if ($result_newwght->num_rows > 0) {

while(($rowwght = $result_newwght->fetch_assoc())) 

{

?>

      

          <?php  $w1=$rowwght['IA1_Q_No_1']; $wtg26[1]=$w1;  ?>

       

       

          <?php   $w2=$rowwght['IA1_Q_No_2']; $wtg26[2]=$w2; ?>

        

          <?php   $w3=$rowwght['IA1_Q_No_3']; $wtg26[3]=$w3;  ?>

       

          <?php   $w4=$rowwght['IA2_Q_No_1']; $wtg26[4]=$w4;  ?>

        

          <?php   $w5=$rowwght['IA2_Q_No_2']; $wtg26[5]=$w5; ?>

        
          <?php   $w6=$rowwght['IA2_Q_No_3']; $wtg26[6]=$w6;  ?>

       

      <?php

}

}

else{



} 

?>

      

       

      

      <?php 

// $sqlname = "SELECT Name FROM `SE5_UNIVERSITY`";

// $resultname = $conn3->query($sqlname);

// $sqlrollno = "SELECT Roll_no FROM `SE5_UNIVERSITY`";

// $resultrollno = $conn3->query($sqlrollno);

// $sql1_7 = "SELECT Sr_no,Total_Q1_ADJ,Total_Q2_ADJ,Total_Q3_ADJ FROM `SE5_IA_1`";

// $result1_7 = $conn3->query($sql1_7);

// $sql2_7 = "SELECT Total_Q1_ADJ,Total_Q2_ADJ,Total_Q3_ADJ FROM `SE5_IA_2`";

// $result2_7 = $conn3->query($sql2_7);

//if (($resultname->num_rows > 0 && $resultrollno->num_rows > 0) && ($result1_7->num_rows > 0 && $result2_7->num_rows > 0 )) {

$sql="SELECT *
FROM `se5_ia_1` AS A
INNER JOIN `se5_ia_2` AS B
ON B.`Roll_no` = A.`Roll_no`";
$result=mysqli_query($conn3,$sql);
$i=0;
$j=1;
while($row=mysqli_fetch_array($result)) 

{

?>

      

          
          <?php  $a1=$row[1]; ?> <!-- roll -->

        

          <?php  $a2=$row[2];  ?> <!-- name -->

        

          <?php  $a3=$row[10];  ?> <!-- total ques 1 round off -->

        

          <?php  $a4=$row[13];  ?> <!-- ques 2 total -->

        
          <?php  $a5=$row[17];  ?> <!-- ques 3 total -->

        

          <?php  $a6=$row[29];  ?>  <!-- total ques 1 ia2 round off -->

        

          <?php  $a7=$row[32];  ?>

        

          <?php  $a8=$row[36];  ?>

        

          <?php $sum=$a3+$a4+$a5+$a6+$a7+$a8; 

          $ttlm26[$j]=$sum;
          $j++;

          ?>

        

      <?php

}

// } else { echo "0 results"; }

?>

      <?php

$sqlIA1i1 = "select count(Total_Q1_ADJ)*100  as a1 from SE5_IA_1 where Total_Q1_ADJ >=3 ";

$result_new11 = $conn3->query($sqlIA1i1);

$sqlIA1i2 = "select count(TotalQ2)*100  as a2 from SE5_IA_1 where TotalQ2 >=3";

$result_new12 = $conn3->query($sqlIA1i2);

$sqlIA1i3 = "select count(TotalQ3)*100  as a3 from SE5_IA_1 where TotalQ3 >=3";

$result_new13 = $conn3->query($sqlIA1i3);

$sqlIA2i1 = "select count(Total_Q3_ADJ)*100 as a4 from SE5_IA_2 where Total_Q1_ADJ >=3";

$result_new21 = $conn3->query($sqlIA2i1);

$sqlIA2i2 = "select count(TotalQ2)*100  as a5 from SE5_IA_2 where TotalQ2 >=3";

$result_new22 = $conn3->query($sqlIA2i2);

$sqlIA2i3 = "select count(TotalQ3)*100  as a6 from SE5_IA_2 where TotalQ3 >=3";

$result_new23 = $conn3->query($sqlIA2i3);                                                

$sqlavg = "select count(*) as c from SE5_IA_1";

$result_newavg = $conn3->query($sqlavg);
  
    $row1=mysqli_fetch_array($result_new11);
    $row2=mysqli_fetch_array($result_new12);
    $row3=mysqli_fetch_array($result_new13);
    $row4=mysqli_fetch_array($result_new21);
    $row5=mysqli_fetch_array($result_new22);
    $row6=mysqli_fetch_array($result_new23);
    $row7=mysqli_fetch_array($result_newavg);
     $ttl=$row7['c'];
    ?>

    
       
    <?php 
    $a1=$row1['a1']/$ttl; 
    $a2=$row2['a2']/$ttl; 
    $a3=$row3['a3']/$ttl; 
    $a4=$row4['a4']/$ttl; 
    $a5=$row5['a5']/$ttl; 
    $a6=$row6['a6']/$ttl; 


    $percen26[1]=$a1;
    $percen26[2]=$a2;
    $percen26[3]=$a3;
    $percen26[4]=$a4;
    $percen26[5]=$a5;
    $percen26[6]=$a6;
      ?>
      
  
      <?php  
      $sum=0;
      for ($i=1; $i < 7; $i++) { 
      $ten26[$i]=$percen26[$i]*$wtg26[$i]/1000;      
             $sum=$sum+$ten26[$i];
      
}
      ?>
    
      <?php $no=count($wtg26);
        $v=1;
      while ($v<=$no) {
              if($percen26[$v]>=70)
              { $l=3;
                $att26[$v]=$l;
                
              }elseif ($percen26[$v]>=65) {
                $l=2;$att26[$v]=$l;
               
              }elseif ($percen26[$v]>=60) {
                $l=1;$att26[$v]=$l;
                
              }else{$l=round(($percen26[$v])/60);
                $att26[$v]=$l;
              }
              
            $v++;
            }?>

           
          <?php 
          $z=1;
          $sum1=0;
          while ($z<$no) { 
            $sum1=$sum1+($att26[$z]*$wtg26[$z]);
            $z++;

          }$fnlatt26=$sum1/100;?>
   
    


      </body>

    </html>

​