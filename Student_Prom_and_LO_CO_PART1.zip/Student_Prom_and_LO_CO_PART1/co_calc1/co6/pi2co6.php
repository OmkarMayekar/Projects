<?php

include_once('db.php');

$percen26=array();
$wtg26=array();
$ten26=array();
$att26=array();
/*session_start();*/
$ttlm26=array();
?>

<!DOCTYPE html>

<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI2 CO1

    </title>

  </head>

  <body>

    <table class='table table-bordered ' class='table table-hover'>

      <tr>

        <th colspan="3">Internal Assesment Number

        </th>

        <th colspan="3">1

        </th>

        <th colspan="3">2

        </th>

        <th rowspan="3">

        </th>

      </tr>

      <tr>

        <th colspan="3">Question Number

        </th>

        <th>1

        </th>

        <th>2

        </th>

        <th>3

        </th>

        <th>1

        </th>

        <th>2

        </th>

        <th>3

        </th>

      </tr>

      <?php

$sqlwght = "SELECT * FROM `CO_IA_Mapping` WHERE Course_Outcome_Number=6";

$result_newwght = $conn3->query($sqlwght);

if ($result_newwght->num_rows > 0) {

while(($rowwght = $result_newwght->fetch_assoc())) 

{

?>

      <tr>

        <th colspan="3">Weightage

        </th>

        <td>

          <?php  $w1=$rowwght['IA1_Q_No_1']; $wtg26[1]=$w1; echo $w1; ?>

        </td>

        <td>

          <?php   $w2=$rowwght['IA1_Q_No_2']; $wtg26[2]=$w2; echo $w2; ?>

        </td>

        <td>

          <?php   $w3=$rowwght['IA1_Q_No_3']; $wtg26[3]=$w3; echo $w3; ?>

        </td>

        <td>

          <?php   $w4=$rowwght['IA2_Q_No_1']; $wtg26[4]=$w4; echo $w4; ?>

        </td>

        <td>

          <?php   $w5=$rowwght['IA2_Q_No_2']; $wtg26[5]=$w5; echo $w5; ?>

        </td>

        <td>

          <?php   $w6=$rowwght['IA2_Q_No_3']; $wtg26[6]=$w6; echo $w6; ?>

        </td>

      </tr>

      <?php

}

}

else{

echo "not working";

} 

?>

      <tr>

        <th>Sr_no

        </th>

        <th>Roll_no

        </th>

        <th>Name

        </th>   

        <th>

        </th>

        <th>

        </th>

        <th>

        </th>

        <th>

        </th>

        <th>

        </th>

        <th>

        </th>

        <th>Total

        </th>

      </tr>

      <?php 

// $sqlname = "SELECT Name FROM `SE5_UNIVERSITY`";

// $resultname = $conn3->query($sqlname);

// $sqlrollno = "SELECT Roll_no FROM `SE5_UNIVERSITY`";

// $resultrollno = $conn3->query($sqlrollno);

// $sql1_7 = "SELECT Sr_no,Total_Q1_ADJ,Total_Q2_ADJ,Total_Q3_ADJ FROM `SE5_IA_1`";

// $result1_7 = $conn3->query($sql1_7);

// $sql2_7 = "SELECT Total_Q1_ADJ,Total_Q2_ADJ,Total_Q3_ADJ FROM `SE5_IA_2`";

// $result2_7 = $conn3->query($sql2_7);

//if (($resultname->num_rows > 0 && $resultrollno->num_rows > 0) && ($result1_7->num_rows > 0 && $result2_7->num_rows > 0 )) {

$sql="SELECT *
FROM `se5_ia_1` AS A
INNER JOIN `se5_ia_2` AS B
ON B.`Roll_no` = A.`Roll_no`";
$result=mysqli_query($conn3,$sql);
$i=0;
$j=1;
while($row=mysqli_fetch_array($result)) 

{

?>

      <tr>

        <td>

          <?php  echo $row['Sr_no'];?>

        </td>

        <td>

          <?php  $a1=$row[1];echo $a1; ?> <!-- roll -->

        </td>

        <td>

          <?php  $a2=$row[2]; echo $a2; ?> <!-- name -->

        </td>

        <td>

          <?php  $a3=$row[10]; echo $a3; ?> <!-- total ques 1 round off -->

        </td>

        <td>

          <?php  $a4=$row[13]; echo $a4; ?> <!-- ques 2 total -->

        </td>

        <td>

          <?php  $a5=$row[17]; echo $a5; ?> <!-- ques 3 total -->

        </td>

        <td>

          <?php  $a6=$row[29]; echo $a6; ?>  <!-- total ques 1 ia2 round off -->

        </td>

        <td>

          <?php  $a7=$row[32]; echo $a7; ?>

        </td>

        <td>

          <?php  $a8=$row[36]; echo $a8; ?>

        </td>

        <td>

          <?php $sum=$a3+$a4+$a5+$a6+$a7+$a8; echo $sum; 

          $ttlm26[$j]=$sum;
          $j++;

          ?>

        </td>

      </tr>

      <?php

}

// } else { echo "0 results"; }

?>

      <?php

$sqlIA1i1 = "select count(Total_Q1_ADJ)*100  as a1 from SE5_IA_1 where Total_Q1_ADJ >=3 ";

$result_new11 = $conn3->query($sqlIA1i1);

$sqlIA1i2 = "select count(TotalQ2)*100  as a2 from SE5_IA_1 where TotalQ2 >=3";

$result_new12 = $conn3->query($sqlIA1i2);

$sqlIA1i3 = "select count(TotalQ3)*100  as a3 from SE5_IA_1 where TotalQ3 >=3";

$result_new13 = $conn3->query($sqlIA1i3);

$sqlIA2i1 = "select count(Total_Q3_ADJ)*100 as a4 from SE5_IA_2 where Total_Q1_ADJ >=3";

$result_new21 = $conn3->query($sqlIA2i1);

$sqlIA2i2 = "select count(TotalQ2)*100  as a5 from SE5_IA_2 where TotalQ2 >=3";

$result_new22 = $conn3->query($sqlIA2i2);

$sqlIA2i3 = "select count(TotalQ3)*100  as a6 from SE5_IA_2 where TotalQ3 >=3";

$result_new23 = $conn3->query($sqlIA2i3);                                                

$sqlavg = "select count(*) as c from SE5_IA_1";

$result_newavg = $conn3->query($sqlavg);
  
    $row1=mysqli_fetch_array($result_new11);
    $row2=mysqli_fetch_array($result_new12);
    $row3=mysqli_fetch_array($result_new13);
    $row4=mysqli_fetch_array($result_new21);
    $row5=mysqli_fetch_array($result_new22);
    $row6=mysqli_fetch_array($result_new23);
    $row7=mysqli_fetch_array($result_newavg);
     $ttl=$row7['c'];
    ?>

    <tr>
      <td colspan="3">% of Students getting equal or more than 60%</td>
    <?php 
    echo "<td>";$a1=$row1['a1']/$ttl; echo "$a1";  echo "</td>";
    echo "<td>";$a2=$row2['a2']/$ttl; echo "$a2";  echo "</td>";
    echo "<td>";$a3=$row3['a3']/$ttl; echo "$a3";  echo "</td>";
    echo "<td>";$a4=$row4['a4']/$ttl; echo "$a4";  echo "</td>";
    echo "<td>";$a5=$row5['a5']/$ttl; echo "$a5";  echo "</td>";
    echo "<td>";$a6=$row6['a6']/$ttl; echo "$a6";  echo "</td>";


    $percen26[1]=$a1;
    $percen26[2]=$a2;
    $percen26[3]=$a3;
    $percen26[4]=$a4;
    $percen26[5]=$a5;
    $percen26[6]=$a6;
      ?>
      <td></td>
    </tr>
    <tr><td colspan="3">OUT OF 10</td>
      <?php  
      $sum=0;
      for ($i=1; $i < 7; $i++) { 
      $ten26[$i]=$percen26[$i]*$wtg26[$i]/1000;      
             $sum=$sum+$ten26[$i];
      echo "<td>";
      echo $ten26[$i];
      echo"</td> ";} ;

      ?>
    </tr>
    <tr>
      <td colspan="3">Attainment Level</td>
      <?php $no=count($wtg26);
        $v=1;
      while ($v<=$no) {
              if($percen26[$v]>=70)
              { $l=3;
                $att26[$v]=$l;
                echo "<td>";echo $l; echo "</td>";
              }elseif ($percen26[$v]>=65) {
                $l=2;$att26[$v]=$l;
                echo "<td>";echo $l; echo "</td>";
              }elseif ($percen26[$v]>=60) {
                $l=1;$att26[$v]=$l;
                echo "<td>";echo $l; echo "</td>";
              }else{$l=round(($percen26[$v])/60);
                $att26[$v]=$l;
                echo "<td>";echo $l; echo "</td>";}
              
            $v++;
            }?><td></td>
          </tr>

           <tr>
          <td colspan="3">Attainment Level for Performance Indicator</td>
          <?php 
          $z=1;
          $sum1=0;
          while ($z<$no) { 
            $sum1=$sum1+($att26[$z]*$wtg26[$z]);
            $z++;

          }$fnlatt=$sum1/100;?>
   
           <td colspan="11" align="center"><?php echo "$fnlatt"; ?></td>
     </tr>


      </body>

    </html>

​