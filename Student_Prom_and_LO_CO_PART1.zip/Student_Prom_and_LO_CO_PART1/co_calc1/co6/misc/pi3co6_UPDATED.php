<?php

include_once('dbConfig.php');
include_once 'db.php';
include_once 'db2.php';
include_once 'db3.php';
/*session_start();*/
?>

<!DOCTYPE html>

<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI3 CO3

    </title>

  </head>

  <body>

    <table class="table table-hover"> 

      

      <?php

$query1 = mysqli_query($conn3,"SELECT CQ1.Course_Outcome_Number,CQ1.Roll_no,CQ1.Q1_Fin_Marks,CQ2.Q2_Fin_Marks,CQ3.Q3_Fin_Marks,CQ4.Q4_Fin_Marks,CQ5.Q5_Fin_Marks,CT.T1,CT.T2,CT.T3,CT.T4,CT.T5,CT.T6,CT.T7,CT.T8,CT.T9,CT.T10 FROM CO_SE5_QUIZ_1 as CQ1 JOIN CO_SE5_QUIZ_2 as CQ2 ON CQ1.Roll_no = CQ2.Roll_no JOIN CO_SE5_QUIZ_3 as CQ3 ON CQ1.Roll_no = CQ3.Roll_no JOIN CO_SE5_QUIZ_4 as CQ4 ON CQ1.Roll_no = CQ4.Roll_no JOIN CO_SE5_QUIZ_5 as CQ5 ON CQ1.Roll_no = CQ5.Roll_no JOIN Page_Tutorial as CT ON CQ1.Roll_no = CT.Roll_no");

$sql_new = "SELECT * FROM Page_Tutorial WHERE Course_Outcome_Number= 6";

$result_new = $conn3->query($sql_new);

$sqlxnew = "SELECT * FROM CO_QUIZ_TUT WHERE Course_Outcome_Number=6";
$result_newxnew = $conn3->query($sqlxnew);

if (($result_new->num_rows > 0) && ($result_newxnew->num_rows > 0)) {

while(($row = $result_new->fetch_assoc()) && ($row1 = $query1->fetch_assoc()) && ($rownew = $result_newxnew->fetch_assoc())) 

{

?>  

      
        
        
      <?php

}

}

else{

echo "not working";

} 

?>

    

    <?php 

$string=NULL;

$sum = 0;

$query = mysqli_query($conn3,"SELECT CQ1.Course_Outcome_Number,CQ1.Roll_no,CQ1.Q1_Fin_Marks,CQ2.Q2_Fin_Marks,CQ3.Q3_Fin_Marks,CQ4.Q4_Fin_Marks,CQ5.Q5_Fin_Marks,CT.T1,CT.T2,CT.T3,CT.T4,CT.T5,CT.T6,CT.T7,CT.T8,CT.T9,CT.T10 FROM CO_SE5_QUIZ_1 as CQ1 JOIN CO_SE5_QUIZ_2 as CQ2 ON CQ1.Roll_no = CQ2.Roll_no JOIN CO_SE5_QUIZ_3 as CQ3 ON CQ1.Roll_no = CQ3.Roll_no JOIN CO_SE5_QUIZ_4 as CQ4 ON CQ1.Roll_no = CQ4.Roll_no JOIN CO_SE5_QUIZ_5 as CQ5 ON CQ1.Roll_no = CQ5.Roll_no JOIN Page_Tutorial as CT ON CQ1.Roll_no = CT.Roll_no");

$sqlx = "select count(Q1_Fin_Marks)/100  as count\n"."from CO_SE5_QUIZ_1\n"."where Q1_Fin_Marks > 4";

$result_new = $conn3->query($sqlx);

$sqlx1 = "select count(Q2_Fin_Marks)/100 as count1\n"."from CO_SE5_QUIZ_2\n"."where Q2_Fin_Marks > 4";

$result_new1 = $conn3->query($sqlx1);

$sqlx2 = "select count(Q3_Fin_Marks)/100 as count2\n"."from CO_SE5_QUIZ_3\n"."where Q3_Fin_Marks > 4";

$result_new2 = $conn3->query($sqlx2);    

$sqlx3 = "select count(Q4_Fin_Marks)/100 as count3\n"."from CO_SE5_QUIZ_4\n"."where Q4_Fin_Marks > 4";

$result_new3 = $conn3->query($sqlx3);    

$sqlx4 = "select count(Q5_Fin_Marks)/100 as count4\n"."from CO_SE5_QUIZ_5\n"."where Q5_Fin_Marks > 4";

$result_new4 = $conn3->query($sqlx4);    

$sqlt1 = "select count(T1)/100 as countt1 from CO_Quiz_Tutorial where T1 > 4";

$sqlt2 = "select count(T2)/100 as countt2 from CO_Quiz_Tutorial where T2 > 4";

$sqlt3 = "select count(T3)/100 as countt3 from CO_Quiz_Tutorial where T3 > 4";

$sqlt4 = "select count(T4)/100 as countt4 from CO_Quiz_Tutorial where T4 > 4";

$sqlt5 = "select count(T5)/100 as countt5 from CO_Quiz_Tutorial where T5 > 4";

$sqlt6 = "select count(T6)/100 as countt6 from CO_Quiz_Tutorial where T6 > 4";

$sqlt7 = "select count(T7)/100 as countt7 from CO_Quiz_Tutorial where T7 > 4";

$sqlt8 = "select count(T8)/100 as countt8 from CO_Quiz_Tutorial where T8 > 4";

$sqlt9 = "select count(T9)/100 as countt9 from CO_Quiz_Tutorial where T9 > 4";

$sqlt10 = "select count(T10)/100 as countt10 from CO_Quiz_Tutorial where T10 > 4";

$result_newt1 = $conn3->query($sqlt1);

$result_newt2 = $conn3->query($sqlt2);

$result_newt3 = $conn3->query($sqlt3);

$result_newt4 = $conn3->query($sqlt4);

$result_newt5 = $conn3->query($sqlt5);

$result_newt6 = $conn3->query($sqlt6);

$result_newt7 = $conn3->query($sqlt7);

$result_newt8 = $conn3->query($sqlt8);

$result_newt9 = $conn3->query($sqlt9);

$result_newt10 = $conn3->query($sqlt10);

$sqlavg = "select count(*) as c from CO_SE5_QUIZ_1";

$result_newavg = $conn3->query($sqlavg);

$total=0;

?>

    

      <?php
$ttlm3=array();
$jx=1;
while ($row = $query->fetch_assoc())

{ 

$array[] = $row;

$Course_Outcome_Number = "{$row['Course_Outcome_Number']}";

$Roll_no = "{$row['Roll_no']}";

$Q1_Fin_Marks = "{$row['Q1_Fin_Marks']}";

$Q2_Fin_Marks = "{$row['Q2_Fin_Marks']}";

$Q3_Fin_Marks = "{$row['Q3_Fin_Marks']}";

$Q4_Fin_Marks = "{$row['Q4_Fin_Marks']}";

$Q5_Fin_Marks = "{$row['Q5_Fin_Marks']}";

$T1 = "{$row['T1']}";

$T2 = "{$row['T2']}";

$T3 = "{$row['T3']}";

$T4 = "{$row['T4']}";

$T5 = "{$row['T5']}";

$T6 = "{$row['T6']}";

$T7 = "{$row['T7']}";

$T8 = "{$row['T8']}";

$T9 = "{$row['T9']}";

$T10 = "{$row['T10']}";

$total=$T1+$T2+$T3+$T4+$T5+$T6+$T7+$T8+$T9+$T10+$Q1_Fin_Marks+$Q2_Fin_Marks+$Q3_Fin_Marks+$Q4_Fin_Marks+$Q5_Fin_Marks;

$ttlm3[$jx]=$total;
$jx++;

}

/*$ttlm3=array();
$j1=1;
*/
while (($rowx = $result_new->fetch_assoc()) && ($rowx1 = $result_new1->fetch_assoc()) && ($rowx2 = $result_new2->fetch_assoc()) && ($rowx3 = $result_new3->fetch_assoc()) && ($rowx4 = $result_new4->fetch_assoc()) && ($rowt1 = $result_newt1->fetch_assoc()) && ($rowt2 = $result_newt2->fetch_assoc()) && ($rowt3 = $result_newt3->fetch_assoc()) && ($rowt4 = $result_newt4->fetch_assoc()) && ($rowt5 = $result_newt5->fetch_assoc()) && ($rowt6 = $result_newt6->fetch_assoc()) && ($rowt7 = $result_newt7->fetch_assoc()) && ($rowt8 = $result_newt8->fetch_assoc()) && ($rowt9 = $result_newt9->fetch_assoc()) && ($rowt10 = $result_newt10->fetch_assoc())&& ($rowavg = $result_newavg->fetch_assoc()))

{ 


$divavg = "{$rowavg['c']}";

$avg = "{$rowx['count']}";

$avgf0 = $avg * $divavg; 

$avg1 = "{$rowx1['count1']}";

$avg1f = $avg1 * $divavg;

$avg2 = "{$rowx2['count2']}";

$avg2f = $avg2 * $divavg;

$avg3 = "{$rowx3['count3']}";

$avg3f = $avg3 * $divavg;

$avg4 = "{$rowx4['count4']}";

$avg4f = $avg4 * $divavg;

$avgt1 = "{$rowt1['countt1']}";

$avgt1f = $avgt1 * $divavg;

$avgt2 = "{$rowt2['countt2']}";

$avgt2f = $avgt2 * $divavg;

$avgt3 = "{$rowt3['countt3']}";

$avgt3f = $avgt3 * $divavg;

$avgt4 = "{$rowt4['countt4']}";

$avgt4f = $avgt4 * $divavg;

$avgt5 = "{$rowt5['countt5']}";

$avgt5f = $avgt5 * $divavg;

$avgt6 = "{$rowt6['countt6']}";

$avgt6f = $avgt6 * $divavg;

$avgt7 = "{$rowt7['countt7']}";

$avgt7f = $avgt7 * $divavg;

$avgt8 = "{$rowt8['countt8']}";

$avgt8f = $avgt8 * $divavg;

$avgt9 = "{$rowt9['countt9']}";

$avgt9f = $avgt9 * $divavg;

$avgt10 = "{$rowt10['countt10']}";

$avgt10f = $avgt10 * $divavg;


///////////////////////////////////////////////////////////////////////////////////////////

$a=$avgf0/100;

$b=$avg1f/100;

$c=$avg2f/100;

$d=$avg3f/100;

$e=$avg4f/100;

$f=$avgt1f/100;

$g=$avgt2f/100;

$h=$avgt3f/100;

$g=$avgt4f/100;

$h=$avgt5f/100;

$i=$avgt6f/100;

$j=$avgt7f/100;

$k=$avgt8f/100;

$l=$avgt9f/100;


$m=$avgt10f/100;


$total = $avgf0+$avg1f+$avg2f=$avg3f+$avg4f+$avgt1f+$avgt2f+$avgt3f+$avgt4f+$avgt5f+$avgt6f+$avgt7f+$avgt8f+$avgt9f+$avgt10f;

$x=round($total);
/*$ttlm3[$j1]=$x;
$j1++;
*/

if($avgf0 > 70){ 
$x1=3.0;

}elseif ($avgf0 > 65) 

{
$x1=2.0;


}

else 

{
$x1=1.0;


}

/*++++++++++++++++*/

if($avg1f > 70){ 
$x2=3.0;


}elseif ($avg1f > 65) 

{
$x2=2.0;


}

else 

{
$x2=1.0;


}

/*++++++++++++++++*/

if($avg2f > 70){ 
$x3=3.0;


}elseif ($avg2f > 65) 

{
$x3=2.0;

}

else 

{
$x3=1.0;


}

/*++++++++++++++++*/

if($avg3f > 70){ 
$x4=3.0;


}elseif ($avg3f > 65) 

{
$x4=2.0;


}

else 

{
$x4=1.0;


}
/*++++++++++++++++*/

if($avg4f > 70){ 
$x5=3.0;


}elseif ($avg4f > 65) 

{
$x5=2.0;


}

else 

{
$x5=1.0;


}

/*++++++++++++++++*/

if($avgt1f > 70){ 
$x6=3.0;


}elseif ($avgt1f > 65) 

{
$x6=2.0;


}

else 

{
$x6=1.0;


}

/*++++++++++++++++*/

if($avgt2f > 70){ 
$x7=3.0;


}elseif ($avgt2f > 65) 

{
$x7=2.0;


}

else 

{
$x7=1.0;


}

/*++++++++++++++++*/

if($avgt3f > 70){ 
$x8=3.0;


}elseif ($avgt3f > 65) 

{
$x8=2.0;


}

else 

{
$x8=1.0;


}

/*++++++++++++++++*/

if($avgt4f > 70){ 

$x9=3.0;


}elseif ($avgt4f > 65) 

{
$x9=2.0;


}

else 

{
$x9=1.0;


}

/*++++++++++++++++*/

if($avgt5f > 70){ 

$x10=3.0;


}elseif ($avgt5f > 65) 

{
$x10=2.0;

}

else 

{
$x10=1.0;


}

/*++++++++++++++++*/

if($avgt6f > 70){ 
$x11=3.0;


}elseif ($avgt6f > 65) 

{
$x11=2.0;

}

else 

{
$x11=1.0;


}

/*++++++++++++++++*/

if($avgt7f > 70){ 
$x12=3.0;


}elseif ($avgt7f > 65) 

{
$x12=2.0;


}

else 

{
$x12=1.0;


}


/*++++++++++++++++*/

if($avgt8f > 70){ 
$x13=3.0;


}elseif ($avgt8f > 65) 

{
$x13=2.0;


}

else 

{
$x13=1.0;


}


/*++++++++++++++++*/

if($avgt9f > 70){ 
$x114=3.0;


}elseif ($avgt9f > 65) 

{
$x14=2.0;


}

else 

{
$x14=1.0;


}



}
$ATP=$avgf0*$x1+$avg1f*$x2+$avg2f*$x3+$avg3f*$x4+$avg4f*$x5+$avgt1f*$x6+$avgt2f*$x7+$avgt3f*$x8+$avgt4f*$x9+$avgt5f*$x10+$avgt6f*$x11+$avgt7f*$x12+$avgt8f*$x13+$avgt9f*$x14;
$ATPF3=$ATP/100;
/*
$_SESSION['pi3co1_ttl'] = $x;*/
?>
    </table>
  </body>
</html>