<?php 
/*include 'db2.php';*/
include_once('db.php');

/*session_start()*/;
$wtg46=array();
$percen46=array();
$ten46=array();
$att46=array();
$sum=0;
$sum1=0;
$n=1;
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>PI4-CO3</title>
<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">

 </head>


 	
 	
 	
 	<?php $sql9="SELECT * FROM 4pg_coothers WHERE CO=6"; 
 		  $result10=mysqli_query($conn3,$sql9);
 		  $row10=mysqli_fetch_array($result10);
 		  
 		  $ttl=$row10[1]+$row10[2]+$row10[3]+$row10[4]+$row10[5]+$row10[6]+$row10[7]+$row10[8]+$row10[9];
 		  for ($i=0; $i <9 ; $i++) { 
							$wtg46[$i]=$row10[$i+1];

							}
 	?>
 
 		<?php 
 		$m=1;
 				$sql_new = "SELECT * FROM se_5_others";
			$result_new = mysqli_query($conn3,$sql_new);
			while ($row=mysqli_fetch_assoc($result_new))
			{
				?>
				
				<?php $t=$wtg46[0]*$row['S1'];?>
<?php $t1=$wtg46[1]*$row['S2'];?>
<?php $t2=$wtg46[2]*$row['CT1'];?>
<?php $t3=$wtg46[3]*$row['CT1'];?>
<?php $t4=$wtg46[4]*$row['P1'];?>
<?php $t5=$wtg46[5]*$row['P2'];?>
<?php $t6=$wtg46[6]*$row['CS1'];?>
<?php $t7=$wtg46[7]*$row['CS2'];?>
<?php $t8=$wtg46[8]*$row['CS2'];?>

				
				<?php 	$tt=$t+$t2+$t3+$t4+$t5+$t6+$t7+$t8;
					$ttlm46[$m]=$tt;
					$m++;
						?>
					
				<?php
			}

 		 ?>
 		
 		 <?php 
 		 	$sql0= "SELECT COUNT(*)AS total FROM se_5_others";
 			 		$result0=mysqli_query($conn3,$sql0);
 			 		$row0=mysqli_fetch_array($result0);
 			 		$ttl=$row0[0];
 			 		//echo($ttl);

 			 $sql = "SELECT COUNT(S1)AS per FROM se_5_others WHERE S1>=3";
 			 $sql1 = "SELECT COUNT(S2)AS per FROM se_5_others WHERE S2>=3";
 			 $sql2 = "SELECT COUNT(CT1)AS per FROM se_5_others WHERE CT1>=3";
 			 $sql3 = "SELECT COUNT(CT2)AS per FROM se_5_others WHERE CT2>=3";
 			 $sql4 = "SELECT COUNT(P1)AS per FROM se_5_others WHERE P1>=3";
 			 $sql5 = "SELECT COUNT(P2)AS per FROM se_5_others WHERE P2>=3";
 			 $sql6 = "SELECT COUNT(CS1)AS per FROM se_5_others WHERE CS1>=3";
 			 $sql7 = "SELECT COUNT(CS2)AS per FROM se_5_others WHERE CS2>=3";
 			 $sql8 = "SELECT COUNT(CS3)AS per FROM se_5_others WHERE CS3>=3";

 			 		$result= mysqli_query($conn3,$sql);
 			 		$result1=mysqli_query($conn3,$sql1);
 			 		$result2=mysqli_query($conn3,$sql2);
 			 		$result3=mysqli_query($conn3,$sql3);
 			 		$result4=mysqli_query($conn3,$sql4);
 			 		$result5=mysqli_query($conn3,$sql5);
 			 		$result6=mysqli_query($conn3,$sql6);
 			 		$result7=mysqli_query($conn3,$sql7);
 			 		$result8=mysqli_query($conn3,$sql8);

			 		$row =mysqli_fetch_array($result);
					$row1=mysqli_fetch_array($result1);
					$row2=mysqli_fetch_array($result2);
					$row3=mysqli_fetch_array($result3);
					$row4=mysqli_fetch_array($result4);
					$row5=mysqli_fetch_array($result5);
					$row6=mysqli_fetch_array($result6);
					$row7=mysqli_fetch_array($result7);
					$row8=mysqli_fetch_array($result8);

					// echo "$row[0]";
					// echo "$row1[0]";
					// echo "$row2[0]";
					// echo "$row3[0]";
					// echo "$row4[0]";
					// echo "$row5[0]";
					// echo "$row6[0]";
					// echo "$row7[0]";
					// echo "$row8[0]";


						$S1=($row[0]/$ttl)*100;
						$S2=($row1[0]/$ttl)*100;
						$CT1=($row2[0]/$ttl)*100;
						$CT2=($row3[0]/$ttl)*100;
						$P1=($row4[0]/$ttl)*100;
						$P2=($row5[0]/$ttl)*100;
						$CS1=($row6[0]/$ttl)*100;
						$CS2=($row7[0]/$ttl)*100;
						$CS3=($row8[0]/$ttl)*100;

						

						
							$percen46[0]=$S1;
							$percen46[1]=$S2;
							$percen46[2]=$CT1;
							$percen46[3]=$CT2;
							$percen46[4]=$P1;
							$percen46[5]=$P2;
							$percen46[6]=$CS1;
							$percen46[7]=$CS2;
							$percen46[8]=$CS3;

						for ($i=0; $i <9 ; $i++) { 
							$wtg46[$i]=$row10[$i+1];

							}
							// print_r($percen46);
							// print_r($wtg46);
 		  ?>
 		 
 		  		<?php 
 		  		for ($i=0; $i < 9; $i++) { 
 		  			$ten46[$i]=($percen46[$i]*$wtg46[$i])/1000;
 		  			$sum=$sum+$ten46[$i];
			
			
			} ?>
 		  
 		  
 		  	<?php $no=count($wtg46);
 		  	$v=0;
 		  while ($v<$no) {
 			 	 			if($percen46[$v]>=70)
 			 	 			{	$l=3;
 			 	 				$att46[$v]=$l;
 			 	 				
 			 	 			}elseif ($percen46[$v]>=65) {
 			 	 				$l=2;$att46[$v]=$l;
 			 	 				
 			 	 			}elseif ($percen46[$v]>=60) {
 			 	 				$l=1;$att46[$v]=$l;
 			 	 				
 			 	 			}else{$l=round(($percen46[$v])/60);
 			 	 				$att46[$v]=$l;
 			 	 				}
 			 	 			
 			 	 		$v++;
 			 	 		}?>
 			 	 	
 			 	 	<?php 
 			 	 	$z=0;
 			 	 	while ($z<$no) {
 			 	 		$sum1=$sum1+($att46[$z]*$wtg46[$z]);
 			 	 		$z++;
 			 	 	}$fnlatt46=$sum1/100;
 			 	 	//$_SESSION['pi4co1_ttl'] = $ttlm46;
 			 	 	 ?>
 			 	 	
 		
 </table>
 </body>
 </html>
 