 <?php

include_once('db.php');

$wtg36=array();
$ttlm36=array();
$percen36=array();
$ten36=array();

/*session_start();*/
?>

<!DOCTYPE html>
 
<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI3 CO2

    </title>

  </head>

  <body>

    <table border='1' class='table table-bordered' class='table table-hover'>
    

    


  <?php 
  $sql1="SELECT * FROM co_quiz_tut WHERE Course_Outcome_Number=6";
  $result1=mysqli_query($conn3,$sql1);
  $rownew=mysqli_fetch_assoc($result1)
   ?>

         

        

          <?php  $wtg36[1]=$rownew['QZ1']; ?>

        

          <?php $wtg36[2]=$rownew['QZ2']; ?>

        

          <?php  $wtg36[3]=$rownew['QZ3']; ?>


          <?php  $wtg36[4]=$rownew['QZ4']; ?>

       

          <?php  $wtg36[5]=$rownew['QZ5']; ?>

        

          <?php  $wtg36[6]=$rownew['T1']; ?>

      

          <?php  $wtg36[7]=$rownew['T2']; ?>

        

        

          <?php  $wtg36[8]=$rownew['T3']; ?>

        

          <?php  $wtg36[9]=$rownew['T4']; ?>

      

          <?php  $wtg36[10]=$rownew['T5']; ?>

      

          <?php  $wtg36[11]=$rownew['T6']; ?>

        

          <?php  $wtg36[12]=$rownew['T7']; ?>

        

          <?php  $wtg36[13]=$rownew['T8']; ?>

        

          <?php  $wtg36[14]=$rownew['T9']; ?>

        

          <?php $wtg36[15]=$rownew['T10']; ?>


        

        <?php
          $total= $rownew['QZ1']+$rownew['QZ2']+$rownew['QZ3']+$rownew['QZ4']+$rownew['QZ5']+$rownew['T1']+$rownew['T2']+$rownew['T3']+$rownew['T4']+$rownew['T5']+$rownew['T6']+$rownew['T7']+$rownew['T8']+$rownew['T9']+$rownew['T10'];
            ?>


       

      <?php

$j=1;

$sql="SELECT B.Roll_No,A.Name,B.Q1,B.Q2,B.Q3,B.Q4,B.Q5,B.T1,B.T2,B.T3,B.T4,B.T5,B.T6,B.T7,B.T8,B.T9,B.T10 FROM students as A,co_quiz_tutorial as B where A.Roll_No=B.Roll_NO";
$result=mysqli_query($conn3,$sql);
// if ($result) {
//   echo "1";
// }

// if ($result2) {
//   echo "2";
// }


?>
<?php
$j=1;
while ($row=mysqli_fetch_assoc($result) )

{ 


$ttl=0;
$ttl=(($row['Q1']*$wtg36[1])+($row['Q2']*$wtg36[2])+($row['Q3']*$wtg36[3])+($row['Q4']*$wtg36[4])+($row['Q5']*$wtg36[5])+($row['T1']*$wtg36[6])+($row['T2']*$wtg36[7])+($row['T3']*$wtg36[8])+($row['T4']*$wtg36[9])+($row['T5']*$wtg36[10])+($row['T6']*$wtg36[11])+($row['T7']*$wtg36[12])+($row['T8']*$wtg36[13])+($row['T9']*$wtg36[14])+($row['T10']*$wtg36[15]))/5;

$ttlm36[$j]=$ttl;
$j++;
}
?> 

   
   <?php 
      $k=1;
      $l=1;
     // $j--;
      $m=1;

      $sqlavg="SELECT COUNT(*) as cn FROM co_quiz_tutorial";
      $resultavg=mysqli_query($conn3,$sqlavg);
      $rowavg=mysqli_fetch_assoc($resultavg);


      $no=1;

      while ($m<$j) {
        while ( $k<= 5) {
          $data='Q'.$k;
         $sql2="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
         $result2=mysqli_query($conn3,$sql2);
         $row4=mysqli_fetch_assoc($result2);

         
         // $main=($row4['per']*$rowavg['cn'])/1000;
         // $percen36[$no]=$main;
         // $no++;
         $main=($row4['per']/$rowavg['cn'])*100;
         $percen36[$no]=$main;
          $no++;
         
         $k++;
        }
        while ( $l<= 10) {
          $data='T'.$l;
          $sql3="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
          $result2=mysqli_query($conn3,$sql3);
         $row5=mysqli_fetch_assoc($result2);

         
         // $main=($row5['per']*$rowavg['cn'])/1000;
         // $percen36[$no]=$main;
         // $no++;
         $main=($row5['per']/$rowavg['cn'])*100;
         $percen36[$no]=$main;
          $no++;
         
         $l++;
        }
        $m++;
      }
      // echo"$no";
      // print_r($percen36);
    ?>
    

          <?php 
          $sum=0;
          for ($i=1; $i < 16; $i++) { 
            $ten36[$i]=($percen36[$i]*$wtg36[$i])/1000;
            $sum=$sum+$ten36[$i];
      } 
      ?>


      <!-- ````````````````````````````````````````````````````````````````````````````````````````````````````` -->
 
      
        <?php $no=count($wtg36);
        $v=1;
      while ($v<=$no) {
              if($percen36[$v]>=70)
              { $l=3;
                $att31[$v]=$l;
                
              }elseif ($percen36[$v]>=65) {
                $l=2;$att31[$v]=$l;
                
              }elseif ($percen36[$v]>=60) {
                $l=1;$att31[$v]=$l;
                
              }else{$l=round(($percen36[$v])/60);
                $att31[$v]=$l;
               }
              
            $v++;
            }?>
          
         
          <?php 
          $z=1;
          $sum1=0;
          while ($z<=$no) {
            $sum1=$sum1+($att31[$z]*$wtg36[$z]);
            $z++;
          }$fnlatt36=$sum1/100;
          //$_SESSION['pi4co1_ttl'] = $ttlm;
           ?>
           
</table>
  </body>
</html>