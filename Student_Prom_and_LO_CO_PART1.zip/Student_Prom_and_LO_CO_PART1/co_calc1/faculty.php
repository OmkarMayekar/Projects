<?php 
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<link rel="stylesheet" type="text/css" href="../bootstrap4/css/bootstrap.css">
 </head>
 <body><center>
 <a href="../co_calc1/co1/Assignments/coAssign.php">Weightage for Assignments(PI1)</a><h1></h1><br>
 <a href="../co_calc1/co1/Assignments/studentmarks.php">Students marks for Assignments(PI1)</a><h1></h1>

 </body>
 </html>