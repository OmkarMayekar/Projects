<html>
<head>
	<title></title>
<link rel="stylesheet" href="../bootstrap4/css/bootstrap.css">

</head>
<body>

</body>
</html>
<body>
	<form action="domainselectback1.php" method="post">
<?php 
include('db1.php');
ini_set('max_execution_time', 300);

// $sql1="Select * FROM reason_pim LIMIT 6";
// $result1=mysqli_query($conn1,$sql1);


?><table class="table table-striped">
		<thead thead-dark>
			<tr><th>Course Outcome Number</th>
				<th>Unique Course Outcome Number</th>
				<th>Assignment Number </th>
				<th> Assignment Questions</th>
				<th>Marks / Grades Allotted to each Question</th>
				<th>Percentage Weightage*</th>
			</tr>
		</thead>
		<?php $c=1;
			while ($c<=15) {
						$sql="SELECT DISTINCT CourseOutcomeNumber,UniqueCourseOutcomeNumber FROM reason_pim LIMIT 6";
						$result=mysqli_query($conn1,$sql);
			?>
	
			<tbody>
				<tr>
				<td><select name="co[]">
					<?php //$i=1; 
					while ($row=mysqli_fetch_assoc($result)) {
						

						echo"<option>";
						$var1=$row['CourseOutcomeNumber'];
				 		echo $var1; 
				 		echo"</option>"; 
				 		//$i++;
				 	}?>
				 			
				 		</select></td>

				 		<?php 
				 			$sql="SELECT DISTINCT CourseOutcomeNumber,UniqueCourseOutcomeNumber FROM reason_pim LIMIT 6";
							$result=mysqli_query($conn1,$sql);
				 		 ?>

				 <td><select name="uc[]">
				 		<?php  
				 		while ($row=mysqli_fetch_assoc($result)) {
						
				 			//ini_set('max_execution_time', 300);
						echo"<option>";
						$var1=$row['UniqueCourseOutcomeNumber'];
				 		echo $var1; 
				 		echo"</option>"; 
				 		
				 	}?>

				 </select></td>


				 <td><input type="text" name="asno[]"></td>
				 <td><input type="text" name="asqs[]"></td>
				 
				 <td><input type="text" name="marks[]"></td>
				 <td><input type="text" name="per[]"></td>

			</tr>
		</tbody>
	<?php $c++;	
}

?></table><center>
<input type="text" name="choice" value="assign" hidden="true">
<input type="submit" name="save" class="btn btn-success" value="Save">
</form>
</body>
