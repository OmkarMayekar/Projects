<?php
include_once 'db.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/CO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co2/CO2_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co3/CO3_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co4/CO4_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co5/CO5_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co6/CO6_UPDATED.php';
$wtgsub=array();
$ttlmcof=array();
$var=array();

			
			$sql="SELECT * FROM courseoutcome_weightage";
			$result=mysqli_query($conn3,$sql);
			while ($row=mysqli_fetch_assoc($result)) 
			{
				$wtgsub[1]=$row['co1'];
				$wtgsub[2]=$row['co2'];
				$wtgsub[3]=$row['co3'];
				$wtgsub[4]=$row['co4'];
				$wtgsub[5]=$row['co5'];
				$wtgsub[6]=$row['co6'];
				 $wtgsub[7]=$row['Total'];

			}
		$counts=count($roll);
		$c=1;

			?>

			<?php $i=1;
			while ($i<=$counts) {
				$var[1]=$ttlmco1[$i]/20;
				$var[2]=$ttlmco2[$i]/20;
				$var[3]=$ttlmco3[$i]/20;
				$var[4]=$ttlmco4[$i]/20;
				$var[5]=$ttlmco5[$i]/20;
				$var[6]=$ttlmco6[$i]/20;
			
				$ttlmcof[$i]=(($var[1]*$wtgsub[1])+($var[2]*$wtgsub[2])+($var[3]*$wtgsub[3])+($var[4]*$wtgsub[4])+($var[5]*$wtgsub[5])+($var[6]*$wtgsub[6]))/5;
				 

			$sql="INSERT INTO `studentsco`(`Roll_NO`, `Name`, `CO1`, `CO2`, `CO3`, `CO4`, `CO5`, `CO6`) VALUES ($roll[$i],'$name[$i]',$var[1],$var[2],$var[3],$var[4],$var[5],$var[6])";
			$result=mysqli_query($conn,$sql);
				if ($result)
				{
					$c++;
					}
					
					$i++;
			}


			
			// print_r($wtgsub);
			//   "<pre>";
			// print_r($ttlmco1);
			// print_r($ttlmco2);
			// print_r($ttlmco3);
			// print_r($ttlmco4);
			// print_r($ttlmco5);
			// print_r($ttlmco6);
			//  "<pre>";
			if ($c==$i) {
				echo "<center> <h1>";echo "Sucess";
			
			}
			else{
				echo "<center> <h1>";echo "Failed";
			} ?>
		
 <br>
			<a href="subject.php"><button type="button" class="btn btn-success"> Previous</button></a>

</body>
</html>