<?php 
include 'C:/xampp/htdocs/project/co_calc1/final_co/subject_UPDATED.php';
include'C:/xampp/htdocs/project/co_calc1/final_co/university_UPDATED.php'; 
$attIA=array();
$attDM=array();
$attCES=array();
$coatt=array();
$wtgatt=array();
 ?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
</head>


	

	
	
		
		<?php $wtgatt[1]=48; ;?>
		<?php  $attIA[1]=$fnlttlco1?>
		<?php  $attIA[2]=$fnlttlco2?>
		<?php  $attIA[3]=$fnlttlco3?>
		<?php  $attIA[4]=$fnlttlco4?>
		<?php  $attIA[5]=$fnlttlco5?>
		<?php  $attIA[6]=$fnlttlco6?>

	
	
		
		<?php $wtgatt[2]=32;?>

		<?php 
		$i=1;
		while ($i<7) {
			
		
		$attDM[$i]=$attuni[1];
		
		$i++;
	}

		 ?>
		<?php $wtgatt[3]=20; ?>

		 	<?php 
		 	$sql4="SELECT * FROM final_att";
		 	$result4=mysqli_query($conn,$sql4);
		 	$count=mysqli_num_rows($result4);
		 	$i=1;
		 	while ($row4=mysqli_fetch_array($result4)) {
		 		
		 		$attCES[$i]=$row4[3];
		 		
		 		$i++;
		 		 	
		 	}

		 	 ?>
		 
	
		
		<?php $i=1;
		while ($i<7) {
			$coatt[$i]=round((($attIA[$i]*$wtgatt[1])+($attCES[$i]*$wtgatt[2])+($attDM[$i]*$wtgatt[3]))/100,2);
			
		 	
		 	$i++;
		 }
		 	// echo "<pre>";
		 	// print_r($attIA);
		 	// print_r($attCES);
		 	// print_r($attDM);
		 	// echo "</pre>"; 
		
		 $overallcoatt=0;
		 $i=1;
		 while ($i<7) {
		 	$cal=$wtgsub[$i]*$coatt[$i];
		 	$overallcoatt=$overallcoatt+$cal;
		 	# code...
		 $i++;
		}$overallcoatt=round($overallcoatt/100,3);
		
