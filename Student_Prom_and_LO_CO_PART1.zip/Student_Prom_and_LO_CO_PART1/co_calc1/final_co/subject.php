<?php
include_once 'db.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/CO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co2/CO2_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co3/CO3_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co4/CO4_UPDATED.php'; 
include_once 'C:/xampp/htdocs/project/co_calc1/co5/CO5_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co6/CO6_UPDATED.php';
$wtgsub=array();
$ttlmcof=array();
$percencof=array();
$tencof=array();
$var=array();

			?>
<!DOCTYPE html>
<html>
<head>
	<title>Subject</title>
</head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<body>
<form action="subjectinsert.php" method="POST">
<table class="table table-bordered">
	<thead>
	<!-- 	<tr><td colspan ="6"></td></tr>
		<tr><td colspan ="6"></td></tr> -->
		<tr><th colspan="2">Course Outcome Number</th>
			<th>CO1</th>
			<th>CO2</th>
			<th>CO3</th>
			<th>CO4</th><th>CO5</th><th>CO6</th><th>Total</th></tr>
		<tr><th colspan="2">Weightage</th>
			<?php
			$sql="SELECT * FROM courseoutcome_weightage";
			$result=mysqli_query($conn3,$sql);
			while ($row=mysqli_fetch_assoc($result)) 
			{
				echo "<td>"; $wtgsub[1]=$row['co1'];echo $row['co1'];echo "</td>";
				echo "<td>"; $wtgsub[2]=$row['co2'];echo $row['co2'];echo "</td>";
				echo "<td>"; $wtgsub[3]=$row['co3'];echo $row['co3'];echo "</td>";
				echo "<td>"; $wtgsub[4]=$row['co4'];echo $row['co4'];echo "</td>";
				echo "<td>"; $wtgsub[5]=$row['co5'];echo $row['co5'];echo "</td>";
				echo "<td>"; $wtgsub[6]=$row['co6'];echo $row['co6'];echo "</td>";
				echo "<td>"; $wtgsub[7]=$row['Total'];echo $row['Total'];echo "</td>";

			}
		$counts=count($roll);

			?>

		</tr>
		<tr>
			<th width="10%">Roll Number</th>
			<th colspan="7">Name</th></tr>
			<?php $i=1;
			while ($i<=$counts) {
				echo "<tr>";
				echo "<td>";
				echo $roll[$i];
				echo "</td>";
				echo "<td width='15%'>";
				echo $name[$i];
				echo "</td>";

				echo "<td>";
				$var[1]=$ttlmco1[$i]/20;
				echo $var[1];
				echo "</td>";

				echo "<td>";
				$var[2]=$ttlmco2[$i]/20;
				echo $var[2];
				echo "</td>";

				echo "<td>";
				$var[3]=$ttlmco3[$i]/20;
				echo $var[3];
				echo "</td>";

				echo "<td>";
				$var[4]=$ttlmco4[$i]/20;
				echo $var[4];
				echo "</td>";

				echo "<td>";
				$var[5]=$ttlmco5[$i]/20;
				echo $var[5];
				echo "</td>";

				echo "<td>";
				$var[6]=$ttlmco6[$i]/20;
				echo $var[6];
				echo "</td>";


				echo "<td>";
				$ttlmcof[$i]=(($var[1]*$wtgsub[1])+($var[2]*$wtgsub[2])+($var[3]*$wtgsub[3])+($var[4]*$wtgsub[4])+($var[5]*$wtgsub[5])+($var[6]*$wtgsub[6]))/5;
				echo $ttlmcof[$i];
				echo "</td>";




				# code...
				echo "</tr>";
				$i++;
			}
			// print_r($wtgsub);
			//  echo "<pre>";
			// print_r($ttlmco1);
			// print_r($ttlmco2);
			// print_r($ttlmco3);
			// print_r($ttlmco4);
			// print_r($ttlmco5);
			// print_r($ttlmco6);
			// echo "<pre>";
				$sqlr="SELECT * FROM studentsco";
				$resultr=mysqli_query($conn,$sqlr);
				$rowc=mysqli_num_rows($resultr);


						$sql1="SELECT count(*) FROM studentsco  WHERE CO1>=3";
						$result1=mysqli_query($conn,$sql1);
						$row1=mysqli_fetch_array($result1);
						$ttlno=$row1[0];

				if ($rowc<=0) {
					echo "<center><h3>No Records in Database.Please insert the students Cos value in database and then refresh</center></h1>";
					# code...
				}else
				{


						$sql2="select count(CO1) FROM studentsco  WHERE CO1>=3";
						$sql3="select count(CO2) FROM studentsco  WHERE CO2>=3";
						$sql4="select count(CO3) FROM studentsco  WHERE CO3>=3";
						$sql5="select count(CO4) FROM studentsco  WHERE CO4>=3";
						$sql6="select count(CO5) FROM studentsco  WHERE CO5>=3";
						$sql7="select count(CO6) FROM studentsco  WHERE CO6>=3";

						$result2=mysqli_query($conn,$sql2);
						$result3=mysqli_query($conn,$sql3);
						$result4=mysqli_query($conn,$sql4);
						$result5=mysqli_query($conn,$sql5);
						$result6=mysqli_query($conn,$sql6);
						$result7=mysqli_query($conn,$sql7);


						$row2=mysqli_fetch_array($result2);
						$row3=mysqli_fetch_array($result3);
						$row4=mysqli_fetch_array($result4);
						$row5=mysqli_fetch_array($result5);
						$row6=mysqli_fetch_array($result3);
						$row7=mysqli_fetch_array($result7);

						?>
						<tr>
							<td colspan="2">% of Students getting equal or more</td>
						
						<?php
						$i=1; 
						while ($i<=6) {
							echo "<td>";
							$percencof[$i]=($row2[0]/$ttlno)*100;
							echo $percencof[$i];
							echo "</td>";
							# code...
							$i++;
						}
						echo "</tr>";
						?>
						<tr><th colspan="2">OUT OF 10</th>
						<?php 
						$i=1; 
						while ($i<=6) {
						echo"<td>";
						$tencof[$i]=($percencof[$i]*$wtgsub[$i])/1000;
						echo "$tencof[$i]";


						echo "</td>";
						$i++;
							}
							echo "</tr>";
							?>
							<tr><th colspan="2">TOTAL</th>
							<td colspan="6" align="center">
							<?php 
							$finnalattcof=array_sum($tencof);
							echo "$finnalattcof";
							echo "</td></tr>";

				}
				
			 ?>
			
		</tr>
</thead>
</table>

<center><input type="submit" name="insert" value="Insert" class="btn btn-success"></form>
</body>
</html>