<?php 
include'C:/xampp/htdocs/project/co_calc1/final_co/subject_UPDATED.php';
include'C:/xampp/htdocs/project/co_calc1/final_co/university_UPDATED.php'; 
$attIA=array();
$attDM=array();
$attCES=array();
$coatt=array();
$wtgatt=array();
 ?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
</head>
<body>
<table class="table table-bordered">
		<tr><th></th>
			<th width="20%" > Weightage in %</th>
		</tr>
	<tr><th width="20%"> Course Outcome Number</th>
		<th rowspan ="3"></th>
	<th>CO1</th>
	<th>CO2</th>
	<th>CO3</th>
	<th>CO4</th>
	<th>CO5</th>
	<th>CO6</th>
<th> Total</th>
</tr>
	<tr><th  width="20%">Unique Course Outocme Number</th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>

	</tr>
	<tr><th  width="20%">Weightage in %</th>
		<?php $i=1;
		while ($i<8) {
			# code...
		
		echo "<td>";
		echo $wtgsub[$i];
		echo "</td>";
		$i++;
	} 
	// echo "<td>";
	// $sum=array_sum($wtgsub);
	// echo $sum;
	// echo "</td>";
		 ?>


	</tr>
	<tr>
		<th>Attainment level by Internal Assessment	 </th>
		<?php $wtgatt[1]=48; echo"<td>";echo $wtgatt[1]; echo"</td>";?>
		<td><?php echo $fnlttlco1;  $attIA[1]=$fnlttlco1?></td>
		<td><?php echo $fnlttlco2;  $attIA[2]=$fnlttlco2?></td>
		<td><?php echo $fnlttlco3;  $attIA[3]=$fnlttlco3?></td>
		<td><?php echo $fnlttlco4;  $attIA[4]=$fnlttlco4?></td>
		<td><?php echo $fnlttlco5;  $attIA[5]=$fnlttlco5?></td>
		<td><?php echo $fnlttlco6;  $attIA[6]=$fnlttlco6?></td>

	</tr>
	<tr>
		<th colspan="1">Attainment Level by University Direct Method</th>
		<?php $wtgatt[2]=32; echo"<td>";echo $wtgatt[2]; echo"</td>";?>

		<?php 
		$i=1;
		while ($i<7) {
			
		echo "<td>";
		$attDM[$i]=$attuni[1];
		echo $attuni[1];

		echo "</td>";
		$i++;
	}

		 ?><tr><th colspan="1">Attainment by Course Exit Survey	 </th>
		<?php $wtgatt[3]=20; echo"<td>";echo $wtgatt[3]; echo"</td>";?>

		 	<?php 
		 	$sql4="SELECT * FROM final_att";
		 	$result4=mysqli_query($conn,$sql4);
		 	$count=mysqli_num_rows($result4);
		 	$i=1;
		 	while ($row4=mysqli_fetch_array($result4)) {
		 		echo "<td>";
		 		$attCES[$i]=$row4[3];
		 		echo $row4[3];
		 		echo "</td>";
		 		$i++;
		 		 	
		 	}

		 	 ?>
		 </tr>
	<tr>
		<th colspan="2">Attainment Level for each Course Outcome</th>
		<?php $i=1;
		while ($i<7) {
			$coatt[$i]=round((($attIA[$i]*$wtgatt[1])+($attCES[$i]*$wtgatt[2])+($attDM[$i]*$wtgatt[3]))/100,2);
			echo "<td>";
			echo $coatt[$i];
			echo "</td>";
		 	
		 	$i++;
		 }
		 	// echo "<pre>";
		 	// print_r($attIA);
		 	// print_r($attCES);
		 	// print_r($attDM);
		 	// echo "</pre>"; 
		 echo "<td>";
		 $overallcoatt=0;
		 $i=1;
		 while ($i<7) {
		 	$cal=$wtgsub[$i]*$coatt[$i];
		 	$overallcoatt=$overallcoatt+$cal;
		 	# code...
		 $i++;
		}$overallcoatt=round($overallcoatt/100,3);
		 echo $overallcoatt;
		 echo "</td>";
		 	?>
	</tr>
	
	

</table>
</body>
</html>