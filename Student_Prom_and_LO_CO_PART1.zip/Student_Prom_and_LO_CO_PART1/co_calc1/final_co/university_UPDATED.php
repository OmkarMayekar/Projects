
<?php 
include 'db.php';
$wtguni=array();
$percenuni=array();
$attuni=array();
$tenuni=array();
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
 </head>
 <body>
 
		<?php $wtguni[1]=40; ?>
		<?php $wtguni[2]=60; ?>
		<?php $wtguni[3]=100; ?>
 	
 	
 		<?php 
 			
 	// 		$sql1="SELECT * FROM university";
		// $result1=mysqli_query($conn,$sql1);
		// while ($row1=mysqli_fetch_array($result1)) {
		// 	echo "<tr>";
		// 	echo "<td>";
		// 	echo $row1[0];//srno
		// 	echo "</td>";

		// 	echo "<td>";
		// 	echo $row1[1];//roll
		// 	echo "</td>";

		// 	echo "<td>";
		// 	echo $row1[2];//name
		// 	echo "</td>";

		// 	echo "<td>";
		// 	echo $row1[3];//theory
		// 	echo "</td>";

		// 	echo "<td>";
		// 	echo $row1[4];//pracs
		// 	echo "</td>";

		// 	echo "<td>";
		// 	echo $row1[5];//total
		// 	echo "</td>";

		// 	echo "</tr>";
		// }
 		 ?>

 		 	<?php 
 		 	$sql2="SELECT count(*) FROM university";
 		 	$result2=mysqli_query($conn,$sql2);
 		 	$row2=mysqli_fetch_array($result2);
 		 	$count=$row2[0];

 		 	$sql3="SELECT count(Theory) FROM university WHERE THEORY >2";
 		 	$result3=mysqli_query($conn,$sql3);
 		 	$row3=mysqli_fetch_array($result3);


 		 	$sql4="SELECT count(Practical) FROM university WHERE THEORY >2";
 		 	$result4=mysqli_query($conn,$sql4);
 		 	$row4=mysqli_fetch_array($result4);

 		 
 		 	$var=($row3[0]/$count)*100; 
 		 	$percenuni[1]=$var;
 		 	
 		 	$var=($row4[0]/$count)*100; 
 		 	$percenuni[2]=$var;
 		 	

 		 	 ?>
 	
		<?php
		 $tenuni[1]=($percenuni[1]*$wtguni[1])/1000; 
		 $tenuni[2]=($percenuni[2]*$wtguni[2])/1000;
		 ?>

 			<?php $ttluni=$tenuni[1]+$tenuni[2]; 
 			?>
 			
 			<?php $i=1;
 			while($i<3)
 			{
 			if($percenuni[$i]>=70)
 			{
 				$attuni[$i]=3;
 			}elseif ($percenuni[$i]>=65 and $percenuni[$i]<70) {
 				$attuni[$i]=2;
 			}elseif ($percenuni[$i]>=60 and $percenuni[$i]<65) {
 				$attuni[$i]=3;
 			}else {
 				$attuni[$i]=$percenuni[$i]/60;
 			}
 			
 			 $i++;
 			}?>
 		

 		<?php 
 			
 				$fnlattuni=(($attuni[1]*$wtguni[1])+($attuni[2]*$wtguni[2]))/100;
 				
 			
 		 ?>
 	</tr>
 </table>
 </body>
 </html>