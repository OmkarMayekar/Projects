<?php 
include_once 'db.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co5/pi1co5_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co5/pi2co5_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co5/pi3co5_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co5/pi4co5_UPDATED.php';
// session_start();
?>
 <!DOCTYPE html>
 <html>
 <head>	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
 	<title>CO1</title>
 </head>
 <body>
<table class="table table-bordered">
	<tr><th colspan="2">Performance Indicator Number</th>
		<td>P1</td>
		<td>P2</td>
		<td>P3</td>
		<td>P4</td>
		<th width="10%">Total</th>
	</tr>



		<?php
		$sqlwght ="SELECT * FROM courseoutcome5 WHERE co5_id=1";
		$result_newwght = $conn3->query($sqlwght);
		if ($result_newwght) {
$wtg5=array();

while(($rowwght = $result_newwght->fetch_assoc())) 

{
?>
	<tr><th colspan="2">Weightage</th>
<td><?php $w1=$rowwght['co5pi1'];echo $w1; $wtg5[1]=$w1;?></td>
<td><?php $w2=$rowwght['co5pi2']; echo $w2;$wtg5[2]=$w2;?></td>
<td><?php $w3=$rowwght['co5pi3']; echo $w3;$wtg5[3]=$w3;?></td>
<td><?php $w4=$rowwght['co5pi4']; echo $w4;$wtg5[4]=$w4;?></td>
<?php
}
}
else{

} 
?>

<td><?php $tot=$w1+$w2+$w3+$w4;  echo $tot;?></td></tr>
<tr><th width="10%">Roll no</th><th width="10%">Name</th></tr>

<?php

$i=0;
$a=1;
$c=count($roll);

$c=$c-1;
$a1=array();//P1 MARKS
$a2=array();
$a3=array();
$a4=array();
$ttlmco5=array();

while($i<=$c) 
{
	?><tr><td><?php echo $roll[$a];?></td>
		<td><?php echo $name[$a];?></td>
		<td><?php $x1=$ttlm15[$a]/20;echo $x1;?></td>
		<td><?php $x2=$ttlm25[$a]/20;echo $x2;?></td>
		<td><?php $x3=$ttlm35[$a]/20;echo $x3;?></td>
		<td><?php $x4=$ttlm45[$a]/20;echo $x4;?></td>
		






<?php

$z1=$x1*$wtg5[1];
$z2=$x2*$wtg5[2];
$z3=$x3*$wtg5[3];
$z4=$x4*$wtg5[4];

$ttlv=($z1+$z2+$z3+$z4)/5;
echo "<td>"; echo $ttlv;echo"</td></tr>";
$ttlmco1[$a]=$ttlv;
$a1[$a]=$x1;
$a2[$a]=$x2;
$a3[$a]=$x3;
$a4[$a]=$x4;
$i++;
$a++;
}
$ab=1;
$s1=1;
?>
	<tr>
		<td colspan="2">% of Students getting equal or more than 60%</td>
		<?php 
		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a1[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var1 = ($sum/$c)*100; echo "$var1"; echo "</td>";
		$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a2[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var2 = ($sum/$c)*100; echo "$var2"; echo "</td>";
		

			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a3[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var3 = ($sum/$c)*100; echo "$var3"; echo "</td>";
		
			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a4[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var4 = ($sum/$c)*100; echo "$var4"; echo "</td>";
		?>
	</tr>

	<tr>

		<td colspan="2">OUT OF 10</td>

		<?php
		$q1=0;
		$q2=0;
		$q3=0;
		$q4=0;

		$q1=($var1*$wtg5[1])/1000;
		$q2=($var2*$wtg5[2])/1000;
		$q3=($var3*$wtg5[3])/1000;
		$q4=($var4*$wtg5[4])/1000;

		echo "<td>"; echo $q1."</td>";
		echo "<td>"; echo $q2."</td>";
		echo "<td>"; echo $q3."</td>";
		echo "<td>"; echo $q4."</td>";

		$qtotal = $q1+$q2+$q3+$q4;	


		?>

	</tr>
	
	<tr>
		<td colspan="2">TOTAL</td>
		<?php echo "<td colspan='4' align='center'>"; echo $qtotal."</td>";
		?>
	</tr>

	<tr>
		<th colspan="2">
			Attainment Level from Performance Indicator
		</th>
		<?php 
		echo "<td>"; echo $fnlatt15."</td>";
		echo "<td>"; echo $fnlatt25."</td>";
		echo "<td>"; echo $fnlatt35."</td>";
		echo "<td>"; echo $fnlatt45."</td>";

?>
	</tr>
	<tr>
		<th colspan="2">
			Attainment Level for Course Outcome
		</th>
		<td align="center">
			<?php 
					$qx1=($fnlatt15*$wtg5[1])/100;
		$qx2=($fnlatt25*$wtg5[2])/100;
		$qx3=($fnlatt35*$wtg5[3])/100;
		$qx4=($fnlatt45*$wtg5[4])/100;
		$add=$qx1+$qx2+$qx3+$qx4;
		echo "<td colspan='4'>"; echo $add."</td>";

			?>

		</td>

	</tr>


</table> 
 </body>
 </html>
