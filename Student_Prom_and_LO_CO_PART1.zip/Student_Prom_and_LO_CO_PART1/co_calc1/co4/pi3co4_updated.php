 <?php

include_once('db.php');

$wtg34=array();
$ttlm34=array();
$percen34=array();
$ten34=array();

/*session_start();*/
?>

<!DOCTYPE html>
 
<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI3 CO2

    </title>

  </head>

  <body>

    <table border='1' class='table table-bordered' class='table table-hover'>
    

    

         

      

  <?php 
  $sql1="SELECT * FROM co_quiz_tut WHERE Course_Outcome_Number=4";
  $result1=mysqli_query($conn3,$sql1);
  $rownew=mysqli_fetch_assoc($result1)
   ?>

         

        

          <?php  $wtg34[1]=$rownew['QZ1']; ?>

        
          <?php  $wtg34[2]=$rownew['QZ2']; ?>


          <?php  $wtg34[3]=$rownew['QZ3']; ?>


          <?php  $wtg34[4]=$rownew['QZ4']; ?>

     

          <?php  $wtg34[5]=$rownew['QZ5']; ?>

      

          <?php  $wtg34[6]=$rownew['T1']; ?>

      

          <?php  $wtg34[7]=$rownew['T2']; ?>

        

          <?php  $wtg34[8]=$rownew['T3']; ?>

       

          <?php  $wtg34[9]=$rownew['T4']; ?>

        

          <?php  $wtg34[10]=$rownew['T5']; ?>

        

          <?php  $wtg34[11]=$rownew['T6']; ?>

        

          <?php  $wtg34[12]=$rownew['T7']; ?>

        

          <?php  $wtg34[13]=$rownew['T8']; ?>

        

          <?php  $wtg34[14]=$rownew['T9']; ?>

        

          <?php $wtg34[15]=$rownew['T10']; ?>


        <?php
          $total= $rownew['QZ1']+$rownew['QZ2']+$rownew['QZ3']+$rownew['QZ4']+$rownew['QZ5']+$rownew['T1']+$rownew['T2']+$rownew['T3']+$rownew['T4']+$rownew['T5']+$rownew['T6']+$rownew['T7']+$rownew['T8']+$rownew['T9']+$rownew['T10'];
            ?>


       

    
      
      

      <?php

$j=1;

$sql="SELECT B.Roll_No,A.Name,B.Q1,B.Q2,B.Q3,B.Q4,B.Q5,B.T1,B.T2,B.T3,B.T4,B.T5,B.T6,B.T7,B.T8,B.T9,B.T10 FROM students as A,co_quiz_tutorial as B where A.Roll_No=B.Roll_NO";
$result=mysqli_query($conn3,$sql);
// if ($result) {
//   echo "1";
// }

// if ($result2) {
//   echo "2";
// }


?>
<?php
$j=1;
while ($row=mysqli_fetch_assoc($result) )

{ 

$ttl=0;
$ttl=(($row['Q1']*$wtg34[1])+($row['Q2']*$wtg34[2])+($row['Q3']*$wtg34[3])+($row['Q4']*$wtg34[4])+($row['Q5']*$wtg34[5])+($row['T1']*$wtg34[6])+($row['T2']*$wtg34[7])+($row['T3']*$wtg34[8])+($row['T4']*$wtg34[9])+($row['T5']*$wtg34[10])+($row['T6']*$wtg34[11])+($row['T7']*$wtg34[12])+($row['T8']*$wtg34[13])+($row['T9']*$wtg34[14])+($row['T10']*$wtg34[15]))/5;


$ttlm34[$j]=$ttl;
$j++;
}
?> 

    
   <?php 
      $k=1;
      $l=1;
     // $j--;
      $m=1;

      $sqlavg="SELECT COUNT(*) as cn FROM co_quiz_tutorial";
      $resultavg=mysqli_query($conn3,$sqlavg);
      $rowavg=mysqli_fetch_assoc($resultavg);


      $no=1;

      while ($m<$j) {
        while ( $k<= 5) {
          $data='Q'.$k;
         $sql2="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
         $result2=mysqli_query($conn3,$sql2);
         $row4=mysqli_fetch_assoc($result2);

         
         // $main=($row4['per']*$rowavg['cn'])/1000;
         // $percen34[$no]=$main;
         // $no++;
         $main=($row4['per']/$rowavg['cn'])*100;
         $percen34[$no]=$main;
          $no++;
         
         $k++;
        }
        while ( $l<= 10) {
          $data='T'.$l;
          $sql3="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
          $result2=mysqli_query($conn3,$sql3);
         $row5=mysqli_fetch_assoc($result2);

         
         // $main=($row5['per']*$rowavg['cn'])/1000;
         // $percen34[$no]=$main;
         // $no++;
         $main=($row5['per']/$rowavg['cn'])*100;
         $percen34[$no]=$main;
          $no++;
         
         $l++;
        }
        $m++;
      }
      // echo"$no";
      // print_r($percen34);
    ?>
    
 
          <?php 
          $sum=0;
          for ($i=1; $i < 16; $i++) { 
            $ten34[$i]=($percen34[$i]*$wtg34[$i])/1000;
            $sum=$sum+$ten34[$i];
      } 
      ?>


      <!-- ````````````````````````````````````````````````````````````````````````````````````````````````````` -->
   
         
        <?php $no=count($wtg34);
        $v=1;
      while ($v<=$no) {
              if($percen34[$v]>=70)
              { $l=3;
                $att31[$v]=$l;
                
              }elseif ($percen34[$v]>=65) {
                $l=2;$att31[$v]=$l;
                
              }elseif ($percen34[$v]>=60) {
                $l=1;$att31[$v]=$l;
                
              }else{$l=round(($percen34[$v])/60);
                $att31[$v]=$l;
                }
              
            $v++;
            }?>
            

            
          <?php 
          $z=1;
          $sum1=0;
          while ($z<=$no) {
            $sum1=$sum1+($att31[$z]*$wtg34[$z]);
            $z++;
          }$fnlatt34=$sum1/100;
          //$_SESSION['pi4co1_ttl'] = $ttlm;
           ?>
           
         
</table>
  </body>
</html>