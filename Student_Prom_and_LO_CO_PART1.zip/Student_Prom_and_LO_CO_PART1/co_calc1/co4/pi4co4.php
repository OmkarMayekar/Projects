<?php 
/*include 'db2.php';*/
include_once('db.php');

/*session_start()*/;
$wtg=array();
$percen=array();
$ten=array();
$att=array();
$sum=0;
$sum1=0;
$n=1;
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>PI4-CO4</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">


 </head>
 <body>
 <table class="table table-bordered">
 	<thead>
 		<tr><td colspan="10">Domain Number: </td><td colspan="13">Domain Name:																						
</td></tr>
 		<tr><td colspan="10">Theory Course Number:</td><td colspan="13">  Theory Course Name:																						
</td></tr>
</table>
<table class="table table-bordered">
 	<thead>
 	<tr>
 		<td colspan="2">Performance Indicator Name</td>
 		<td width="10%">Seminar 1</td>
 		<td width="10%">Seminar 2</td>
 		<td width="10%">Class Test 1</td>
 		<td width="10%">Class Test 2</td>
 		<td width="10%">Presentation 1</td>
 		<td width="10%">Presentation 2</td>
 		<td width="10%">Case Study 1</td>
 		<td width="10%">Case Study 2</td>
 		<td width="10%">Case Study 3</td>
 		<td width="10%">Total</td>
 	</tr>
 	<tr><td colspan="2">Weightage</td>
 	<?php $sql9="SELECT * FROM 4pg_coothers WHERE CO=4"; 
 		  $result10=mysqli_query($conn3,$sql9);
 		  $row10=mysqli_fetch_array($result10);
 		  echo "<td>";echo $row10[1]; 
 		  echo "</td>";
 		  echo "<td>";echo $row10[2];
 		  echo "</td>";
 		  echo "<td>";echo $row10[3];
 		  echo "</td>";
 		  echo "<td>";echo $row10[4];
 		  echo "</td>";
 		  echo "<td>";echo $row10[5];
 		  echo "</td>";
 		  echo "<td>";echo $row10[6];
 		  echo "</td>";
 		  echo "<td>";echo $row10[7];
 		  echo "</td>";
 		  echo "<td>";echo $row10[8];
 		  echo "</td>";
 		  echo "<td>";echo $row10[9];
 		  echo "</td>";
 		  $ttl=$row10[1]+$row10[2]+$row10[3]+$row10[4]+$row10[5]+$row10[6]+$row10[7]+$row10[8]+$row10[9];
 		  for ($i=0; $i <9 ; $i++) { 
							$wtg[$i]=$row10[$i+1];

							}
 	?><td><?php echo "$ttl"; ?></td>
 </tr>
 		<tr>
 		<td width="5%">Roll No.</td>
 		<td width="10%">Name</td>
 		
 		

 	</tr>
 		<?php 
 		$m=1;
 				$sql_new = "SELECT * FROM se_5_others";
			$result_new = mysqli_query($conn3,$sql_new);
			while ($row=mysqli_fetch_assoc($result_new))
			{
				?><tr>
				<td><?php echo $row['Roll_No']; ?></td>
					<td width="5%"><?php  echo $row['Name_of_Student']; ?></td>
					<td width="5%"><?php $t=$wtg[0]*$row['S1']; echo $row['S1'];?></td>
					<td width="5%"><?php $t1=$wtg[1]*$row['S2']; echo $row['S2'];?></td>
					<td width="5%"><?php $t2=$wtg[2]*$row['CT1']; echo $row['CT1'];?></td>
					<td width="5%"><?php $t3=$wtg[3]*$row['CT1']; echo $row['CT2'];?></td>
					<td width="5%"><?php $t4=$wtg[4]*$row['P1']; echo $row['P1'];?></td>
					<td width="5%"><?php $t5=$wtg[5]*$row['P2']; echo $row['P2'];?></td>
					<td width="5%"><?php $t6=$wtg[6]*$row['CS1'];echo $row['CS1'];?></td>
					<td width="5%"><?php $t7=$wtg[7]*$row['CS2']; echo $row['CS2'];?></td>
					<td width="5%"><?php $t8=$wtg[8]*$row['CS2']; echo $row['CS3'];?></td>
				<?php 	$tt=$t+$t2+$t3+$t4+$t5+$t6+$t7+$t8;
					$ttlm[$m]=$tt;
					$m++;
					echo "<td>"; echo($tt); echo "</td>";	?>
					</tr>
				<?php
			}

 		 ?>
 		 <td colspan="2">% of Students getting equal or more than 60%</td>
 		 <?php 
 		 	$sql0= "SELECT COUNT(*)AS total FROM se_5_others";
 			 		$result0=mysqli_query($conn3,$sql0);
 			 		$row0=mysqli_fetch_array($result0);
 			 		$ttl=$row0[0];
 			 		//echo($ttl);

 			 $sql = "SELECT COUNT(S1)AS per FROM se_5_others WHERE S1>=3";
 			 $sql1 = "SELECT COUNT(S2)AS per FROM se_5_others WHERE S2>=3";
 			 $sql2 = "SELECT COUNT(CT1)AS per FROM se_5_others WHERE CT1>=3";
 			 $sql3 = "SELECT COUNT(CT2)AS per FROM se_5_others WHERE CT2>=3";
 			 $sql4 = "SELECT COUNT(P1)AS per FROM se_5_others WHERE P1>=3";
 			 $sql5 = "SELECT COUNT(P2)AS per FROM se_5_others WHERE P2>=3";
 			 $sql6 = "SELECT COUNT(CS1)AS per FROM se_5_others WHERE CS1>=3";
 			 $sql7 = "SELECT COUNT(CS2)AS per FROM se_5_others WHERE CS2>=3";
 			 $sql8 = "SELECT COUNT(CS3)AS per FROM se_5_others WHERE CS3>=3";

 			 		$result= mysqli_query($conn3,$sql);
 			 		$result1=mysqli_query($conn3,$sql1);
 			 		$result2=mysqli_query($conn3,$sql2);
 			 		$result3=mysqli_query($conn3,$sql3);
 			 		$result4=mysqli_query($conn3,$sql4);
 			 		$result5=mysqli_query($conn3,$sql5);
 			 		$result6=mysqli_query($conn3,$sql6);
 			 		$result7=mysqli_query($conn3,$sql7);
 			 		$result8=mysqli_query($conn3,$sql8);

			 		$row =mysqli_fetch_array($result);
					$row1=mysqli_fetch_array($result1);
					$row2=mysqli_fetch_array($result2);
					$row3=mysqli_fetch_array($result3);
					$row4=mysqli_fetch_array($result4);
					$row5=mysqli_fetch_array($result5);
					$row6=mysqli_fetch_array($result6);
					$row7=mysqli_fetch_array($result7);
					$row8=mysqli_fetch_array($result8);

					// echo "$row[0]";
					// echo "$row1[0]";
					// echo "$row2[0]";
					// echo "$row3[0]";
					// echo "$row4[0]";
					// echo "$row5[0]";
					// echo "$row6[0]";
					// echo "$row7[0]";
					// echo "$row8[0]";


						$S1=($row[0]/$ttl)*100;
						$S2=($row1[0]/$ttl)*100;
						$CT1=($row2[0]/$ttl)*100;
						$CT2=($row3[0]/$ttl)*100;
						$P1=($row4[0]/$ttl)*100;
						$P2=($row5[0]/$ttl)*100;
						$CS1=($row6[0]/$ttl)*100;
						$CS2=($row7[0]/$ttl)*100;
						$CS3=($row8[0]/$ttl)*100;

						echo "<td>";echo$S1; echo "</td>";
						echo "<td>";echo$S2; echo "</td>";
						echo "<td>";echo$CT1; echo "</td>";
						echo "<td>";echo$CT2; echo "</td>";
						echo "<td>";echo$P1; echo "</td>";
						echo "<td>";echo$P2; echo "</td>";
						echo "<td>";echo$CS1; echo "</td>";
						echo "<td>";echo$CS2; echo "</td>";
						echo "<td>";echo$CS3; echo "</td>";

						
							$percen[0]=$S1;
							$percen[1]=$S2;
							$percen[2]=$CT1;
							$percen[3]=$CT2;
							$percen[4]=$P1;
							$percen[5]=$P2;
							$percen[6]=$CS1;
							$percen[7]=$CS2;
							$percen[8]=$CS3;

						for ($i=0; $i <9 ; $i++) { 
							$wtg[$i]=$row10[$i+1];

							}
							// print_r($percen);
							// print_r($wtg);
 		  ?>
 		  <tr><td colspan="2">OUT OF 10</td>
 		  		<?php 
 		  		for ($i=0; $i < 9; $i++) { 
 		  			$ten[$i]=($percen[$i]*$wtg[$i])/1000;
 		  			$sum=$sum+$ten[$i];
			echo "<td>";
			echo $ten[$i];
			echo"</td> ";} ?>
 		  </tr>
 		  <tr><td colspan="2">TOTAL</td>
 		  	<td colspan="9" align="center"><?php echo "$sum"; ?></td>
 		  </tr>
 		  <tr><td colspan="2">Attainment Level</td>
 		  	<?php $no=count($wtg);
 		  	$v=0;
 		  while ($v<$no) {
 			 	 			if($percen[$v]>=70)
 			 	 			{	$l=3;
 			 	 				$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";
 			 	 			}elseif ($percen[$v]>=65) {
 			 	 				$l=2;$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";
 			 	 			}elseif ($percen[$v]>=60) {
 			 	 				$l=1;$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";
 			 	 			}else{$l=round(($percen[$v])/60);
 			 	 				$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";}
 			 	 			
 			 	 		$v++;
 			 	 		}?>
 			 	 	</tr>

 			 	 	 <tr>
 			 	 	<td colspan="2">Attainment Level for Performance Indicator</td>
 			 	 	<?php 
 			 	 	$z=0;
 			 	 	while ($z<$no) {
 			 	 		$sum1=$sum1+($att[$z]*$wtg[$z]);
 			 	 		$z++;
 			 	 	}$fnlatt=$sum1/100;
 			 	 	$_SESSION['pi4co1_ttl'] = $ttlm;
 			 	 	 ?>
 			 	 	 <td colspan="11" align="center"><?php echo "$fnlatt"; ?></td>
 			 	 </tr>
 		</tbody>
 </table>
 </body>
 </html>
 