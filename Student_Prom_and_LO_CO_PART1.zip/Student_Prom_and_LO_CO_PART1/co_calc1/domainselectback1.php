<?php 
include("db1.php");
if ($_POST['choice']=='a') {

if($_POST['submit'])
		{	
			ini_set('max_execution_time', 300);
			$i=1;
			while ( $i<= 6) {
				$co=$_POST['co'.$i]; 
				$uc=$_POST['uc'.$i];
				$pi=$_POST['pi'.$i];
				$comment=$_POST['comment'.$i];
				echo "$co";
				echo "$uc";
				echo "$pi";
				echo "$comment";
				$i++;
 					$sql="INSERT INTO reason_pim VALUES('$co','$uc','$pi','$comment')";
				$result=mysqli_query($conn1,$sql);
				if ($result) {
					echo "sucessssssss";
					
				}
			}
			header('Location:assign.php');
		}
	}

		elseif ($_POST['choice']=='assign') { //echo "ssup";
			$a=$_POST['co'];
			$b=$_POST['uc'];
			$c=$_POST['asno'];
			$d=$_POST['asqs'];
			$e=$_POST['marks'];
			$f=$_POST['per'];
			$count=count($a);
			//echo "$count";
			$i=0;
			
			

			while ($i<$count) {
				
			
					
				
			 $sql="INSERT INTO `assign_pim`(`CourseOutcomeNumber`, `UniqueCourseOutcomeNumber`, `AssignmentNumber`, `AssignmentQuestions`, `Marks`, `percentage`) VALUES('$a[$i]','$b[$i]',$c[$i],'$d[$i]',$e[$i],$f[$i])";
			 $result=mysqli_query($conn1,$sql);
			 // if ($result) {
			 // 	echo "success";
			 // 	# code...
			 // }echo "unsuccess";
			 $i++;
		}

			header('Location:assign.php');
				
		}
		elseif ($_POST['choice']=='ia') { //echo "ssup";
			$a=$_POST['co'];
			$b=$_POST['uc'];
			$c=$_POST['isno'];
			$d=$_POST['isqs'];
			$e=$_POST['marks'];
			$f=$_POST['per'];
			$count=count($a);
			//echo "$count";
			$i=0;
			
			

			while ($i<$count) {
				
			
					
				
			 $sql="INSERT INTO `ia_pim`(`CourseOutcomeNumber`, `UniqueCourseOutcomeNumber`, `IANumber`, `IAQuestions`, `Marks`, `percentage`) VALUES('$a[$i]','$b[$i]',$c[$i],'$d[$i]',$e[$i],$f[$i])";
			 $result=mysqli_query($conn1,$sql);
			 // if ($result) {
			 // 	echo "success";
			 // 	# code...
			 // }echo "unsuccess";
			 $i++;
		}

			header('Location:tutorial.php');
				
		}

		elseif ($_POST['choice']=='tutorial') { //echo "ssup";
			$a=$_POST['co'];
			$b=$_POST['uc'];
			$c=$_POST['tno'];
			$d=$_POST['tqs'];
			$e=$_POST['marks'];
			$f=$_POST['per'];
			$count=count($a);
			//echo "$count";
			$i=0;
			
			

			while ($i<$count) {
				
			
					
				
			 $sql="INSERT INTO `tutorial_pim`(`CourseOutcomeNumber`, `UniqueCourseOutcomeNumber`, `TutorialNumber`, `TutorialQuestions`, `Marks`, `percentage`) VALUES('$a[$i]','$b[$i]',$c[$i],'$d[$i]',$e[$i],$f[$i])";
			 $result=mysqli_query($conn1,$sql);
			 if ($result) {
			 	echo "success";
			 	# code...
			 }echo "unsuccess";
			 $i++;
		}

			header('Location:quiz.php');
				
		}

		elseif ($_POST['choice']=='quiz') { //echo "ssup";
			$a=$_POST['co'];
			$b=$_POST['uc'];
			$c=$_POST['qno'];
			$d=$_POST['qqs'];
			$e=$_POST['marks'];
			$f=$_POST['per'];
			$count=count($a);
			//echo "$count";
			$i=0;
			
			

			while ($i<$count) {
				
			
					
				
			 $sql="INSERT INTO `quiz_pim`(`CourseOutcomeNumber`, `UniqueCourseOutcomeNumber`, `QuizNumber`, `QuizQuestions`, `Marks`, `percentage`) VALUES('$a[$i]','$b[$i]',$c[$i],'$d[$i]',$e[$i],$f[$i])";
			 $result=mysqli_query($conn1,$sql);
			 // if ($result) {
			 // 	echo "success";
			 // 	# code...
			 // }echo "unsuccess";
			 $i++;
		}
			echo "<center><h1>";
			echo "success";
				
		}
	
 ?>	