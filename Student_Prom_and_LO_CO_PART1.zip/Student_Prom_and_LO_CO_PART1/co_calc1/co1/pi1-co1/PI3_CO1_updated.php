 <?php

include_once 'db.php';

$wtg31=array();
$ttlm31=array();
$percen31=array();
$ten31=array();

/*session_start();*/
?>

<!DOCTYPE html>
 
<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI3 CO2

    </title>

  </head>

  <body>


      


  <?php 
  $sql1="SELECT * FROM co_quiz_tut WHERE Course_Outcome_Number=1";
  $result1=mysqli_query($conn3,$sql1);
  $rownew=mysqli_fetch_assoc($result1)
   ?>


       

          <?php  $wtg31[1]=$rownew['QZ1']; ?>

       

          <?php  $wtg31[2]=$rownew['QZ2']; ?>

       

          <?php  $wtg31[3]=$rownew['QZ3']; ?>

        

          <?php  $wtg31[4]=$rownew['QZ4']; ?>

       

          <?php  $wtg31[5]=$rownew['QZ5']; ?>

        

          <?php  $wtg31[6]=$rownew['T1']; ?>

        

          <?php $wtg31[7]=$rownew['T2']; ?>

       

          <?php  $wtg31[8]=$rownew['T3']; ?>

        

          <?php $wtg31[9]=$rownew['T4']; ?>

        

          <?php  $wtg31[10]=$rownew['T5']; ?>

        

          <?php  $wtg31[11]=$rownew['T6']; ?>

        

          <?php  $wtg31[12]=$rownew['T7']; ?>

        
          <?php  $wtg31[13]=$rownew['T8']; ?>

       

          <?php  $wtg31[14]=$rownew['T9']; ?>

       

          <?php  $wtg31[15]=$rownew['T10']; ?>


        <?php
          $total= $rownew['QZ1']+$rownew['QZ2']+$rownew['QZ3']+$rownew['QZ4']+$rownew['QZ5']+$rownew['T1']+$rownew['T2']+$rownew['T3']+$rownew['T4']+$rownew['T5']+$rownew['T6']+$rownew['T7']+$rownew['T8']+$rownew['T9']+$rownew['T10'];
            ?>


       

    
      

      <?php

$j=1;

$sql="SELECT B.Roll_No,A.Name,B.Q1,B.Q2,B.Q3,B.Q4,B.Q5,B.T1,B.T2,B.T3,B.T4,B.T5,B.T6,B.T7,B.T8,B.T9,B.T10 FROM students as A,co_quiz_tutorial as B where A.Roll_No=B.Roll_NO";
$result=mysqli_query($conn3,$sql);
// if ($result) {
//   echo "1";
// }

// if ($result2) {
//   echo "2";
// }


?>
<?php
$j=1;
while ($row=mysqli_fetch_assoc($result) )

{ 


$ttl=0;
$ttl=(($row['Q1']*$wtg31[1])+($row['Q2']*$wtg31[2])+($row['Q3']*$wtg31[3])+($row['Q4']*$wtg31[4])+($row['Q5']*$wtg31[5])+($row['T1']*$wtg31[6])+($row['T2']*$wtg31[7])+($row['T3']*$wtg31[8])+($row['T4']*$wtg31[9])+($row['T5']*$wtg31[10])+($row['T6']*$wtg31[11])+($row['T7']*$wtg31[12])+($row['T8']*$wtg31[13])+($row['T9']*$wtg31[14])+($row['T10']*$wtg31[15]))/5;

$ttlm31[$j]=$ttl;
$j++;
}
?> 
   <?php 
      $k=1;
      $l=1;
     // $j--;
      $m=1;

      $sqlavg="SELECT COUNT(*) as cn FROM co_quiz_tutorial";
      $resultavg=mysqli_query($conn3,$sqlavg);
      $rowavg=mysqli_fetch_assoc($resultavg);


      $no=1;

      while ($m<$j) {
        while ( $k<= 5) {
          $data='Q'.$k;
         $sql2="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
         $result2=mysqli_query($conn3,$sql2);
         $row4=mysqli_fetch_assoc($result2);

         
         // $main=($row4['per']*$rowavg['cn'])/1000;
         // $percen31[$no]=$main;
         // $no++;
         $main=($row4['per']/$rowavg['cn'])*100;
         $percen31[$no]=$main;
          $no++;
         
         $k++;
        }
        while ( $l<= 10) {
          $data='T'.$l;
          $sql3="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
          $result2=mysqli_query($conn3,$sql3);
         $row5=mysqli_fetch_assoc($result2);

         
         // $main=($row5['per']*$rowavg['cn'])/1000;
         // $percen31[$no]=$main;
         // $no++;
         $main=($row5['per']/$rowavg['cn'])*100;
         $percen31[$no]=$main;
          $no++;
         
         $l++;
        }
        $m++;
      }
      // echo"$no";
      // print_r($percen31);
    ?>
    
          <?php 
          $sum=0;
          for ($i=1; $i < 16; $i++) { 
            $ten31[$i]=($percen31[$i]*$wtg31[$i])/1000;
            $sum=$sum+$ten31[$i];
          }
      
      ?>


      <!-- ````````````````````````````````````````````````````````````````````````````````````````````````````` -->
  
        <?php $no=count($wtg31);
        $v=1;
      while ($v<=$no) {
              if($percen31[$v]>=70)
              { $l=3;
                $att31[$v]=$l;
                
              }elseif ($percen31[$v]>=65) {
                $l=2;$att31[$v]=$l;
                
              }elseif ($percen31[$v]>=60) {
                $l=1;$att31[$v]=$l;
                
              }else{$l=round(($percen31[$v])/60);
                $att31[$v]=$l;
                }
              
            $v++;
            }?>
           
          <?php 
          $z=1;
          $sum1=0;
          while ($z<=$no) {
            $sum1=$sum1+($att31[$z]*$wtg31[$z]);
            $z++;
          }$fnlatt31=$sum1/100;
          //$_SESSION['pi4co1_ttl'] = $ttlm;
           ?>
          
</table>
  </body>
</html>