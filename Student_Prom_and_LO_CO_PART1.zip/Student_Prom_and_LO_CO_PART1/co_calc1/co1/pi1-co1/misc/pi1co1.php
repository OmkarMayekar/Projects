<?php 
include 'dbConfig.php';
include 'db.php';
$sql="SELECT * FROM 4pg_coassign WHERE CO=1";
$result=mysqli_query($conn,$sql);
$assg=array();
$percen=array();
$ten=array();
$att=array();
$sum=0;
$n=1;
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>PI1-CO1</title>
<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">

 </head>
 <body>
 <table class="table table-bordered">
 	<thead>
 		<tr><td colspan="10">Domain Number: </td><td colspan="13">Domain Name:																						
</td></tr>
 		<tr><td colspan="10">Theory Course Number:</td><td colspan="13">  Theory Course Name:																						
</td></tr>
 		<tr>
 		<td width="25%" colspan="3">Assignment Number</td>
 		<td colspan="5">Assignment 1</td>
 		<td colspan="5">Assignment 2</td>
 		<td colspan="5">Assignment 3</td>
 		<td colspan="5">Assignment 4</td>
 	</tr>
 	<tr> <td colspan="3" width="25%">Question Number</td>
 		<?php
 		 $i=1; 
 		 while ( $i<=4) {
 		 ?>
 		
 		<td width="3%">1</td>
 		<td width="3%">2</td>
 		<td width="3%">3</td>
 		<td width="3%">4</td>
 		<td width="3%">5</td>
 		<?php $i++; }?>
 	</tr>
 </thead>
 	<tbody>
 		<tr>
 		<td colspan="3">Weightage</td>
 		<?php 
 		while ($row=mysqli_fetch_assoc($result)) {
 			# code...
 			$assg[$n]=$row['Q1'];$n++;
 			$assg[$n]=$row['Q2'];$n++;
 			$assg[$n]=$row['Q3'];$n++;
 			$assg[$n]=$row['Q4'];$n++;
 			$assg[$n]=$row['Q5'];$n++;


 			echo "<td>";echo $row['Q1'];echo "</td>";
 			echo "<td>";echo $row['Q2'];echo "</td>";
 			echo "<td>";echo $row['Q3'];echo "</td>";
 			echo "<td>";echo $row['Q4'];echo "</td>";
 			echo "<td>";echo $row['Q5'];echo "</td>";

 		}
 		 ?>
 		</tr>
 		<tr><td width="5%">Sr No.</td>
 		<td width="5%">Roll No.</td>
 		<td>Name</td></tr>
 		
 			<?php 
 				$sql_new = "SELECT * FROM se_5_co_assignment_1";
 				$sql_new2 = "SELECT * FROM se_5_co_assignment_2";
 				$sql_new3= "SELECT * FROM se_5_co_assignment_3";
 				$sql_new4= "SELECT * FROM se_5_co_assignment_4";

			$result_new = mysqli_query($conn1,$sql_new);
			$result_new2= mysqli_query($conn1,$sql_new2);
			$result_new3= mysqli_query($conn1,$sql_new3);
			$result_new4= mysqli_query($conn1,$sql_new4);

			while ($row=mysqli_fetch_assoc($result_new) and $row2=mysqli_fetch_assoc($result_new2) and $row3=mysqli_fetch_assoc($result_new3) and $row4=mysqli_fetch_assoc($result_new4) ) {
				?><tr>
					<td><?php echo $row['Sr_no']; ?></td>
					<td><?php echo $row['Roll_no']; ?></td>
					<td><?php echo $row['Name_of_Student']; ?></td>
					<td><?php echo $row['Question_no_1']; ?></td>
					<td><?php echo $row['Question_no_2']; ?></td>
					<td><?php echo $row['Question_no_3']; ?></td>
					<td><?php echo $row['Question_no_4']; ?></td>
					<td><?php echo $row['Question_no_5']; ?></td>

					<td><?php echo $row2['Question_no_1']; ?></td>
					<td><?php echo $row2['Question_no_2']; ?></td>
					<td><?php echo $row2['Question_no_3']; ?></td>
					<td><?php echo $row2['Question_no_4']; ?></td>
					<td><?php echo $row2['Question_no_5']; ?></td>

					<td><?php echo $row3['Question_no_1']; ?></td>
					<td><?php echo $row3['Question_no_2']; ?></td>
					<td><?php echo $row3['Question_no_3']; ?></td>
					<td><?php echo $row3['Question_no_4']; ?></td>
					<td><?php echo $row3['Question_no_5']; ?></td>

					<td><?php echo $row4['Question_no_1']; ?></td>
					<td><?php echo $row4['Question_no_2']; ?></td>
					<td><?php echo $row4['Question_no_3']; ?></td>
					<td><?php echo $row4['Question_no_4']; ?></td>
					<td><?php echo $row4['Question_no_5']; ?></td>

					</tr>
				<?php
			}
 			 ?>
 			 <tr>
 			 	<td colspan="3">% of Students getting equal or more than 60%</td>
 			 	<?php 

 			 	
 			 	
 			 	$j=1;
 			 	$c=1;
 			 	
 			 	while ($j<=4) {
 			 		# code...
 			 	$i=1;
 			 	while ($i<=5) {
 			 		# code...
 			 		$sql0= "SELECT COUNT(*)AS total FROM se_5_co_assignment_$j";
 			 		$result0=mysqli_query($conn1,$sql0);
 			 		// if ($result0) {
 			 		// 	echo "Success";
 			 		// }else echo "a";
 			 		$row0=mysqli_fetch_array($result0);
 			 		$ttl=$row0[0];
 			 		//echo "$ttl<br>";
 			 	
 			 		$sql = "SELECT COUNT(Question_no_$i)AS per FROM se_5_co_assignment_$j WHERE Question_no_$i>=3";
 			 		$result=mysqli_query($conn1,$sql);
 			 		$row=mysqli_fetch_assoc($result);
 			 		// if ($result) {
 			 		// 	echo "string";
 			 		// }else echo "b";
 			 		$per=($row['per']/$ttl)*100;
 			 		$percen[$c]=$per;
 			 		$c++;
 			 		echo "<td>";echo "$per";echo "</td>";
 	
 			 		$i++;

 			 	} 
 			 	$j++;}
  			 	
 			 		// print_r($assg);
 			 		// print_r($percen);
 			 	 $no=count($assg);

 			 	 ?>
 			 	 <tr>
 			 	 	<td colspan="3">OUT OF 10</td>

 			 	 	<?php $a=1;
 			 	 		while ($a<=$no) {
 			 	 			$ten[$a]=($assg[$a]*$percen[$a])/1000;
 			 	 			echo "<td>";echo "$ten[$a]";echo "</td>";
 			 	 		$a++;}
 			 	 	 ?>

 			 	 </tr>
 			 	 <tr><td colspan="3">Attainment Level</td>
 			 	 	<?php $v=1;
 			 	 		while ($v<=$no) {
 			 	 			if($percen[$v]>=70)
 			 	 			{	$l=3;
 			 	 				$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";
 			 	 			}elseif ($percen[$v]>=65) {
 			 	 				$l=2;$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";
 			 	 			}elseif ($percen[$v]>=60) {
 			 	 				$l=1;$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";
 			 	 			}else{$l=round(($percen[$v])/60);
 			 	 				$att[$v]=$l;
 			 	 				echo "<td>";echo $l; echo "</td>";}
 			 	 			
 			 	 		$v++;
 			 	 		}
 			 	 		//print_r($att);
 			 	 	 ?>
 			 	 </tr>
 			 	 <tr>
 			 	 	<td colspan="3">Attainment Level for Performance Indicator</td>
 			 	 	<?php 
 			 	 	$z=1;
 			 	 	while ($z<=$no) {
 			 	 		$sum=$sum+($att[$z]*$assg[$z]);
 			 	 		$z++;
 			 	 	}$fnlatt=$sum/100;

 			 	 	 ?>
 			 	 	 <td colspan="20" align="center"><?php echo "$fnlatt"; ?></td>
 			 	 </tr>

 		</tr>
 	</tbody>
 </table>
 </body>
 </html>