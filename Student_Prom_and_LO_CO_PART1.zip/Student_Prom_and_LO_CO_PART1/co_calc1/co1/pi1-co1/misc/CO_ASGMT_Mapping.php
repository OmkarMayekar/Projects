<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">
	<TITLE> CO ASSIGNMENT Mapping </TITLE>
	<SCRIPT language="javascript">
		function addRow(tableID_CO_Asgmt_Mapping) {
			
			var table = document.getElementById(tableID_CO_Asgmt_Mapping);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Course_Outcome_Number[]'/>";

			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  name='Assignment1_Q_No_1[]'/>";

			var cell4 = row.insertCell(3);
			cell4.innerHTML =  "<input type='text'  name='Assignment1_Q_No_2[]' />";

			var cell5 = row.insertCell(4);
			cell5.innerHTML = "<input type='text' name='Assignment1_Q_No_3[]'/>";

			var cell6 = row.insertCell(5);
			cell6.innerHTML = "<input type='text' name='Assignment1_Q_No_4[]'/>";

			var cell7 = row.insertCell(6);
			cell7.innerHTML = "<input type='text' name='Assignment1_Q_No_5[]'/>";

			var cell8 = row.insertCell(7);
			cell8.innerHTML = "<input type='text' name='Assignment2_Q_No_1[]'/>";

			var cell9 = row.insertCell(8);
			cell9.innerHTML = "<input type='text' name='Assignment2_Q_No_2[]'/>";

			var cell10 = row.insertCell(9);
			cell10.innerHTML = "<input type='text' name='Assignment2_Q_No_3[]'/>";

			var cell11 = row.insertCell(10);
			cell11.innerHTML = "<input type='text' name='Assignment2_Q_No_4[]'/>";

			var cell12 = row.insertCell(11);
			cell12.innerHTML = "<input type='text' name='Assignment2_Q_No_5[]'/>";

			var cell13 = row.insertCell(12);
			cell13.innerHTML = "<input type='text' name='Assignment3_Q_No_1[]'/>";

			var cell14 = row.insertCell(13);
			cell14.innerHTML = "<input type='text' name='Assignment3_Q_No_2[]'/>";

			var cell15 = row.insertCell(14);
			cell15.innerHTML = "<input type='text' name='Assignment3_Q_No_3[]'/>";

			var cell16 = row.insertCell(15);
			cell16.innerHTML = "<input type='text' name='Assignment3_Q_No_4[]'/>";

			var cell17 = row.insertCell(16);
			cell17.innerHTML = "<input type='text' name='Assignment3_Q_No_5[]'/>";

			var cell18 = row.insertCell(17);
			cell18.innerHTML = "<input type='text' name='Assignment4_Q_No_1[]'/>";

			var cell19 = row.insertCell(18);
			cell19.innerHTML = "<input type='text' name='Assignment4_Q_No_2[]'/>";

			var cell20 = row.insertCell(19);
			cell20.innerHTML = "<input type='text' name='Assignment4_Q_No_3[]'/>";

			var cell21 = row.insertCell(20);
			cell21.innerHTML = "<input type='text' name='Assignment4_Q_No_4[]'/>";

			var cell22 = row.insertCell(21);
			cell22.innerHTML = "<input type='text' name='Assignment4_Q_No_5[]'/>";

			var cell23 = row.insertCell(22);
			cell23.innerHTML = "<input type='text' name='Assignment5_Q_No_1[]'/>";

			var cell24 = row.insertCell(23);
			cell24.innerHTML = "<input type='text' name='Assignment5_Q_No_2[]'/>";

			var cell25 = row.insertCell(24);
			cell25.innerHTML = "<input type='text' name='Assignment5_Q_No_3[]'/>";

			var cell26 = row.insertCell(25);
			cell26.innerHTML = "<input type='text' name='Assignment5_Q_No_4[]'/>";

			var cell27 = row.insertCell(26);
			cell27.innerHTML = "<input type='text' name='Assignment5_Q_No_5[]'/>";



		}

		function deleteRow(tableID_CO_Asgmt_Mapping) {

			try {
				var table = document.getElementById(tableID_CO_Asgmt_Mapping);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY><!-- 
	========================================================================================================== -->

	<table class="table table-hover">
		<t>
			<th>Course_Outcome_Number</th>
			<th>Assignment1_Q_No_1</th>
			<th>Assignment1_Q_No_2</th>
			<th>Assignment1_Q_No_3</th>
			<th>Assignment1_Q_No_4</th>
			<th>Assignment1_Q_No_5</th>

			<th>Assignment2_Q_No_1</th>
			<th>Assignment2_Q_No_2</th>
			<th>Assignment2_Q_No_3</th>
			<th>Assignment2_Q_No_4</th>
			<th>Assignment2_Q_No_5</th>

			<th>Assignment3_Q_No_1</th>
			<th>Assignment3_Q_No_2</th>
			<th>Assignment3_Q_No_3</th>
			<th>Assignment3_Q_No_4</th>
			<th>Assignment3_Q_No_5</th>

			<th>Assignment4_Q_No_1</th>
			<th>Assignment4_Q_No_2</th>
			<th>Assignment4_Q_No_3</th>
			<th>Assignment4_Q_No_4</th>
			<th>Assignment4_Q_No_5</th>

			<th>Assignment5_Q_No_1</th>
			<th>Assignment5_Q_No_2</th>
			<th>Assignment5_Q_No_3</th>
			<th>Assignment5_Q_No_4</th>
			<th>Assignment5_Q_No_5</th>
		</t>
		
		<?php
		if(isset($_POST['print_CO_ASGMT_Mapping']))
		{
			$sql_new = "SELECT Course_Outcome_Number, Assignment1_Q_No_1, Assignment1_Q_No_2, Assignment1_Q_No_3, Assignment1_Q_No_4, Assignment1_Q_No_5, Assignment2_Q_No_1, Assignment2_Q_No_2, Assignment2_Q_No_3, Assignment2_Q_No_4, Assignment2_Q_No_5, Assignment3_Q_No_1, Assignment3_Q_No_2, Assignment3_Q_No_3, Assignment3_Q_No_4, Assignment3_Q_No_5, Assignment4_Q_No_1, Assignment4_Q_No_2, Assignment4_Q_No_3, Assignment4_Q_No_4, Assignment4_Q_No_5, Assignment5_Q_No_1, Assignment5_Q_No_2, Assignment5_Q_No_3, Assignment5_Q_No_4, Assignment5_Q_No_5 FROM CO_Assignment_Mapping";
			
				$result_new = $conn->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
   <!--  /*echo "<table><tr><td>" . $row["Course_Outcome_Number"]. "</td><td>" . $row["Assignment1_Q_No_1"] . "</td><td>"
. $row["Assignment1_Q_No_2"]. "</td><td>" . $row["Assignment1_Q_No_3"]. "</td><td>" . $row["Assignment1_Q_No_4"]. "</td></tr>";*/
-->
<tr>
	<td><?php echo $row['Course_Outcome_Number']; ?></td>
	<td><?php echo $row['Assignment1_Q_No_1']; ?></td>
	<td><?php echo $row['Assignment1_Q_No_2']; ?></td>
	<td><?php echo $row['Assignment1_Q_No_3']; ?></td>
	<td><?php echo $row['Assignment1_Q_No_4']; ?></td>
	<td><?php echo $row['Assignment1_Q_No_5']; ?></td>

	<td><?php echo $row['Assignment2_Q_No_1']; ?></td>
	<td><?php echo $row['Assignment2_Q_No_2']; ?></td>
	<td><?php echo $row['Assignment2_Q_No_3']; ?></td>
	<td><?php echo $row['Assignment2_Q_No_4']; ?></td>
	<td><?php echo $row['Assignment2_Q_No_5']; ?></td>

	<td><?php echo $row['Assignment3_Q_No_1']; ?></td>
	<td><?php echo $row['Assignment3_Q_No_2']; ?></td>
	<td><?php echo $row['Assignment3_Q_No_3']; ?></td>
	<td><?php echo $row['Assignment3_Q_No_4']; ?></td>
	<td><?php echo $row['Assignment3_Q_No_5']; ?></td>

	<td><?php echo $row['Assignment4_Q_No_1']; ?></td>
	<td><?php echo $row['Assignment4_Q_No_2']; ?></td>
	<td><?php echo $row['Assignment4_Q_No_3']; ?></td>
	<td><?php echo $row['Assignment4_Q_No_4']; ?></td>
	<td><?php echo $row['Assignment4_Q_No_5']; ?></td>

	<td><?php echo $row['Assignment5_Q_No_1']; ?></td>
	<td><?php echo $row['Assignment5_Q_No_2']; ?></td>
	<td><?php echo $row['Assignment5_Q_No_3']; ?></td>
	<td><?php echo $row['Assignment5_Q_No_4']; ?></td>
	<td><?php echo $row['Assignment5_Q_No_5']; ?></td>

</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>






<!-- 
	========================================================================================================== -->
	<?php
	if(isset($_POST['submit_CO_ASGMT_Mapping']))
	{
		
		foreach ($_POST['Course_Outcome_Number'] as $key => $value) 
			
			{          $Course_Outcome_Number = $_POST["Course_Outcome_Number"][$key];
		$Assignment1_Q_No_1 = $_POST["Assignment1_Q_No_1"][$key];
		$Assignment1_Q_No_2 = $_POST["Assignment1_Q_No_2"][$key];
		$Assignment1_Q_No_3 = $_POST["Assignment1_Q_No_3"][$key];
		$Assignment1_Q_No_4 = $_POST["Assignment1_Q_No_4"][$key];
		$Assignment1_Q_No_5 = $_POST["Assignment1_Q_No_5"][$key];
		
		$Assignment2_Q_No_1 = $_POST["Assignment2_Q_No_1"][$key];
		$Assignment2_Q_No_2 = $_POST["Assignment2_Q_No_2"][$key];
		$Assignment2_Q_No_3 = $_POST["Assignment2_Q_No_3"][$key];
		$Assignment2_Q_No_4 = $_POST["Assignment2_Q_No_4"][$key];
		$Assignment2_Q_No_5 = $_POST["Assignment2_Q_No_5"][$key];

		$Assignment3_Q_No_1 = $_POST["Assignment3_Q_No_1"][$key];
		$Assignment3_Q_No_2 = $_POST["Assignment3_Q_No_2"][$key];
		$Assignment3_Q_No_3 = $_POST["Assignment3_Q_No_3"][$key];
		$Assignment3_Q_No_4 = $_POST["Assignment3_Q_No_4"][$key];
		$Assignment3_Q_No_5 = $_POST["Assignment3_Q_No_5"][$key];

		$Assignment4_Q_No_1 = $_POST["Assignment4_Q_No_1"][$key];
		$Assignment4_Q_No_2 = $_POST["Assignment4_Q_No_2"][$key];
		$Assignment4_Q_No_3 = $_POST["Assignment4_Q_No_3"][$key];
		$Assignment4_Q_No_4 = $_POST["Assignment4_Q_No_4"][$key];
		$Assignment4_Q_No_5 = $_POST["Assignment4_Q_No_5"][$key];

		$Assignment5_Q_No_1 = $_POST["Assignment5_Q_No_1"][$key];
		$Assignment5_Q_No_2 = $_POST["Assignment5_Q_No_2"][$key];
		$Assignment5_Q_No_3 = $_POST["Assignment5_Q_No_3"][$key];
		$Assignment5_Q_No_4 = $_POST["Assignment5_Q_No_4"][$key];
		$Assignment5_Q_No_5 = $_POST["Assignment5_Q_No_5"][$key];

            /*$sql = mysql_query("insert into your_table_name values ('','$Course_Outcome_Number', '$Assignment1_Q_No_1', '$Assignment1_Q_No_2')");   
*/
            $sql = "INSERT INTO CO_Assignment_Mapping (Course_Outcome_Number, Assignment1_Q_No_1, Assignment1_Q_No_2, Assignment1_Q_No_3, Assignment1_Q_No_4, Assignment1_Q_No_5, Assignment2_Q_No_1, Assignment2_Q_No_2, Assignment2_Q_No_3, Assignment2_Q_No_4, Assignment2_Q_No_5, Assignment3_Q_No_1, Assignment3_Q_No_2, Assignment3_Q_No_3, Assignment3_Q_No_4, Assignment3_Q_No_5, Assignment4_Q_No_1, Assignment4_Q_No_2, Assignment4_Q_No_3, Assignment4_Q_No_4, Assignment4_Q_No_5, Assignment5_Q_No_1, Assignment5_Q_No_2, Assignment5_Q_No_3, Assignment5_Q_No_4, Assignment5_Q_No_5) VALUES ('$Course_Outcome_Number','$Assignment1_Q_No_1','$Assignment1_Q_No_2','$Assignment1_Q_No_3','$Assignment1_Q_No_4','$Assignment1_Q_No_5','$Assignment2_Q_No_1','$Assignment2_Q_No_2','$Assignment2_Q_No_3','$Assignment2_Q_No_4','$Assignment2_Q_No_5','$Assignment3_Q_No_1','$Assignment3_Q_No_2','$Assignment3_Q_No_3','$Assignment3_Q_No_4','$Assignment3_Q_No_5','$Assignment4_Q_No_1','$Assignment4_Q_No_2','$Assignment4_Q_No_3','$Assignment4_Q_No_4','$Assignment4_Q_No_5','$Assignment5_Q_No_1','$Assignment5_Q_No_2','$Assignment5_Q_No_3','$Assignment5_Q_No_4','$Assignment5_Q_No_5')";
            
            	$result = mysqli_query($conn,$sql);

        }
        
    } 
    ?> 
    <INPUT type="button" value="Add Row" onClick="addRow('dataTable_CO_ASGMT_Mapping')" class="btn btn-secondary"/>

    <INPUT type="button" value="Delete Row" onClick="deleteRow('dataTable_CO_ASGMT_Mapping')" class="btn btn-secondary"/>

    <form action="" method="post" name="f">  

    	<TABLE width="425" border="1" class="table table-hover">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<th width="94" name ="Course_Outcome_Number">Course_Outcome_Number</th>
    				<th width="121" name ="Assignment1_Q_No_1">Assignment1_Q_No_1</th>
    				<th width="84" name ="Assignment1_Q_No_2">Assignment1_Q_No_2</th>
    				<th width="84" name ="Assignment1_Q_No_3">Assignment1_Q_No_3</th>
    				<th width="99" name ="Assignment1_Q_No_4">Assignment1_Q_No_4</th>
    				<th width="84" name ="Assignment1_Q_No_5">Assignment1_Q_No_5</th>
    				<th width="84" name ="Assignment2_Q_No_1">Assignment2_Q_No_1</th>
    				<th width="84" name ="Assignment2_Q_No_2">Assignment2_Q_No_2</th>
    				<th width="84" name ="Assignment2_Q_No_3">Assignment2_Q_No_3</th>
    				<th width="99" name ="Assignment2_Q_No_4">Assignment2_Q_No_4</th>
    				<th width="84" name ="Assignment2_Q_No_5">Assignment2_Q_No_5</th>
					<th width="84" name ="Assignment3_Q_No_1">Assignment3_Q_No_1</th>
    				<th width="84" name ="Assignment3_Q_No_2">Assignment3_Q_No_2</th>
    				<th width="84" name ="Assignment3_Q_No_3">Assignment3_Q_No_3</th>
    				<th width="99" name ="Assignment3_Q_No_4">Assignment3_Q_No_4</th>
    				<th width="84" name ="Assignment3_Q_No_5">Assignment3_Q_No_5</th>
					<th width="84" name ="Assignment4_Q_No_1">Assignment4_Q_No_1</th>
    				<th width="84" name ="Assignment4_Q_No_2">Assignment4_Q_No_2</th>
    				<th width="84" name ="Assignment4_Q_No_3">Assignment4_Q_No_3</th>
    				<th width="99" name ="Assignment4_Q_No_4">Assignment4_Q_No_4</th>
    				<th width="84" name ="Assignment4_Q_No_5">Assignment4_Q_No_5</th>
    				<th width="84" name ="Assignment5_Q_No_1">Assignment5_Q_No_1</th>
    				<th width="84" name ="Assignment5_Q_No_2">Assignment5_Q_No_2</th>
    				<th width="84" name ="Assignment5_Q_No_3">Assignment5_Q_No_3</th>
    				<th width="99" name ="Assignment5_Q_No_4">Assignment5_Q_No_4</th>
    				<th width="84" name ="Assignment5_Q_No_5">Assignment5_Q_No_5</th>
    			</tr>
    		</thead>

    		<tbody id="dataTable_CO_ASGMT_Mapping">

    		</tbody>
    	</TABLE>

    	<INPUT type="submit" value="Insert" name="submit_CO_ASGMT_Mapping" class="btn btn-secondary"/>

    	<INPUT type="submit" value="print" name="print_CO_ASGMT_Mapping" class="btn btn-secondary"/>
    </form>
</BODY>
</HTML>