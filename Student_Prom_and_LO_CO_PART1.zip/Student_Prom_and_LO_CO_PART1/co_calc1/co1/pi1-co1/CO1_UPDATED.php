<?php 
include_once 'db.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/pi1co1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/PI2_CO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/PI3_CO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/pi4co1_UPDATED.php';
?>
 <!DOCTYPE html>
 <html>
 <head>	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
 	<title>CO1</title>
 </head>
 <body>
		<?php
		$sqlwght ="SELECT * FROM courseoutcome1 WHERE co1_id=1";
		$result_newwght = $conn3->query($sqlwght);
		//print_r($result_newwght);
		if ($result_newwght) {
$wtg1=array();

while(($rowwght = $result_newwght->fetch_assoc())) 

{
 $w1=$rowwght['co1pi1'];$wtg1[1]=$w1;
 $w2=$rowwght['co1pi2'];$wtg1[2]=$w2;
 $w3=$rowwght['co1pi3'];$wtg1[3]=$w3;
 $w4=$rowwght['co1pi4'];$wtg1[4]=$w4;

}
// print_r($wtg1);
}
else{
	echo "hello";
} 

 $tot=$w1+$w2+$w3+$w4;  



$i=0;
$a=1;
$c=count($roll);
// print_r($name);
$c=$c-1;
$a1=array();//P1 MARKS
$a2=array();
$a3=array();
$a4=array();
$ttlmco1=array();

while($i<=$c) 
{ 
	?>
	<?php $x1=($ttlm11[$a]/20);?>
	<?php $x2=($ttlm21[$a]/20);?>
	<?php $x3=($ttlm31[$a]/20);?>
	<?php $x4=($ttlm41[$a]/20);?>
<?php

$z1=$x1*$wtg1[1];
$z2=$x2*$wtg1[2];
$z3=$x3*$wtg1[3];
$z4=$x4*$wtg1[4];

$ttlvco1=($z1+$z2+$z3+$z4)/5;

$ttlmco1[$a]=$ttlvco1;
$a1[$a]=$x1;
$a2[$a]=$x2;
$a3[$a]=$x3;
$a4[$a]=$x4;
$i++;
$a++;
}
$ab=1;
$s1=1;
?>
	
		<?php 
		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a1[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


 $var1 = ($sum/$c)*100; 
		$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a2[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


 $var2 = ($sum/$c)*100; 
		

			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a3[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


 $var3 = ($sum/$c)*100;
		
			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a4[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


 $var4 = ($sum/$c)*100;
		?>
	

		<?php
		$q1=0;
		$q2=0;
		$q3=0;
		$q4=0;

		$q1=($var1*$wtg1[1])/1000;
		$q2=($var2*$wtg1[2])/1000;
		$q3=($var3*$wtg1[3])/1000;
		$q4=($var4*$wtg1[4])/1000;

	
		$qtotal = $q1+$q2+$q3+$q4;	


		 
					$qx1=($fnlatt11*$wtg1[1])/100;
		$qx2=($fnlatt21*$wtg1[2])/100;
		$qx3=($fnlatt31*$wtg1[3])/100;
		$qx4=($fnlatt41*$wtg1[4])/100;
		$fnlttlco1=$qx1+$qx2+$qx3+$qx4;

			?>



</table> 
 </body>
 </html>
