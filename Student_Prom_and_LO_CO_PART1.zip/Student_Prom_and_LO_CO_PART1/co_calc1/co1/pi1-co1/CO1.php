<?php 

include_once 'db.php';



include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/pi1co1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/PI2_CO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/PI3_CO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co1/pi1-co1/pi4co1_UPDATED.php';

?>
 <!DOCTYPE html>
 <html>
 <head>	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
 	<title>CO1</title>
 </head>
 <body>
<table class="table table-bordered">
	<tr><th colspan="3">Performance Indicator Number</th>
		<td>P1</td>
		<td>P2</td>
		<td>P3</td>
		<td>P4</td>
		<th width="10%">Total</th>
	</tr>



		<?php
		$sqlwght ="SELECT * FROM courseoutcome1 WHERE co1_id=1";
		$result_newwght = $conn3->query($sqlwght);
		//print_r($result_newwght);
		if ($result_newwght) {
$wtg1=array();

while(($rowwght = $result_newwght->fetch_assoc())) 

{
?>
	<tr><th colspan="3">Weightage</th>
<td><?php $w1=$rowwght['co1pi1'];echo $w1; $wtg1[1]=$w1;?></td>
<td><?php $w2=$rowwght['co1pi2']; echo $w2;$wtg1[2]=$w2;?></td>
<td><?php $w3=$rowwght['co1pi3']; echo $w3;$wtg1[3]=$w3;?></td>
<td><?php $w4=$rowwght['co1pi4']; echo $w4;$wtg1[4]=$w4;?></td>
<?php
}
// print_r($wtg1);
}
else{
	echo "hello";
} 
?>

<td><?php $tot=$w1+$w2+$w3+$w4;  echo $tot;?></td></tr>
<tr><th>Sr_No.</th><th width="10%">Roll no</th><th width="10%">Name</th></tr>

<?php

$i=0;
$a=1;
$c=count($roll);

$c=$c-1;
$a1=array();//P1 MARKS
$a2=array();
$a3=array();
$a4=array();
$ttlmco1=array();

while($i<=$c) 
{ 
	?><tr>
		<td><?php echo "$a"; ?></td>
		<td><?php echo $roll[$a];?></td>
		<td><?php echo $name[$a];?></td>
		<td><?php $x1=($ttlm11[$a]/20);echo $x1;?></td>
		<td><?php $x2=($ttlm21[$a]/20);echo $x2;?></td>
		<td><?php $x3=($ttlm31[$a]/20);echo $x3;?></td>
		<td><?php $x4=($ttlm41[$a]/20);echo $x4;?></td>
		






<?php

$z1=$x1*$wtg1[1];
$z2=$x2*$wtg1[2];
$z3=$x3*$wtg1[3];
$z4=$x4*$wtg1[4];

$ttlv=($z1+$z2+$z3+$z4)/5;
echo "<td>"; echo $ttlv;echo"</td></tr>";
$ttlmco1[$a]=$ttlv;
$a1[$a]=$x1;
$a2[$a]=$x2;
$a3[$a]=$x3;
$a4[$a]=$x4;
$i++;
$a++;
}
$ab=1;
$s1=1;
?>
	<tr>
		<td colspan="3">% of Students getting equal or more than 60%</td>
		<?php 
		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a1[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var1 = ($sum/$c)*100; echo "$var1"; echo "</td>";
		$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a2[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var2 = ($sum/$c)*100; echo "$var2"; echo "</td>";
		

			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a3[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var3 = ($sum/$c)*100; echo "$var3"; echo "</td>";
		
			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a4[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var4 = ($sum/$c)*100; echo "$var4"; echo "</td>";
		?>
	</tr>

	<tr>

		<td colspan="3">OUT OF 10</td>

		<?php
		$q1=0;
		$q2=0;
		$q3=0;
		$q4=0;

		$q1=($var1*$wtg1[1])/1000;
		$q2=($var2*$wtg1[2])/1000;
		$q3=($var3*$wtg1[3])/1000;
		$q4=($var4*$wtg1[4])/1000;

		echo "<td>"; echo $q1."</td>";
		echo "<td>"; echo $q2."</td>";
		echo "<td>"; echo $q3."</td>";
		echo "<td>"; echo $q4."</td>";

		$qtotal = $q1+$q2+$q3+$q4;	


		?><td></td>

	</tr>
	
	<tr>
		<td colspan="3">TOTAL</td>
		<?php echo "<td colspan='4' align='center'>"; echo $qtotal."</td>";
		?><td></td>
	</tr>

	<tr>
		<th colspan="3">
			Attainment Level from Performance Indicator
		</th>
		<?php 
		echo "<td>"; echo $fnlatt11."</td>";
		echo "<td>"; echo $fnlatt21."</td>";
		echo "<td>"; echo $fnlatt31."</td>";
		echo "<td>"; echo $fnlatt41."</td>";

?><td></td>
	</tr>
	<tr>
		<th colspan="3">
			Attainment Level for Course Outcome
		</th>
		<td colspan="5" align="center">
			<?php 
					$qx1=($fnlatt11*$wtg1[1])/100;
		$qx2=($fnlatt21*$wtg1[2])/100;
		$qx3=($fnlatt31*$wtg1[3])/100;
		$qx4=($fnlatt41*$wtg1[4])/100;
		$fnlttlco1=$qx1+$qx2+$qx3+$qx4;
		 echo $fnlttlco1."</td>";

			?>

		</td>

	</tr>


</table> 
 </body>
 </html>
