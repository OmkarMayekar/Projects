<?php 
include_once 'db.php';


/*include 'db.php';*/
$sql="SELECT * FROM 4pg_coassign WHERE CO=1";
$result=mysqli_query($conn,$sql);
$assg11=array();
$percen11=array();
$ten11=array();
$att11=array();
$roll=array();
$name=array();
$ttlm1111=array();
$wtg11=array();

$sum=0;
$n=1;
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

 </head>
 <body>
 
 		<?php
 		 $i=1; 
 		 while ( $i<=4) {
 		 ?>
 		
 		
 		<?php $i++; }?>
 	
 
 		<?php 
 		while ($row=mysqli_fetch_assoc($result)) {
 			# code...
 			if ($n==21) {
 				break;
 			}
 			$wtg11[$n]=$row['Q1'];$n++;
 			$wtg11[$n]=$row['Q2'];$n++;
 			$wtg11[$n]=$row['Q3'];$n++;
 			$wtg11[$n]=$row['Q4'];$n++;
 			$wtg11[$n]=$row['Q5'];$n++;


 		} 
 		 ?>

 		 
 		
 			<?php 
 				$sql_new = "SELECT * FROM se_5_co_assignment_1";
 				$sql_new2 = "SELECT * FROM se_5_co_assignment_2";
 				$sql_new3= "SELECT * FROM se_5_co_assignment_3";
 				$sql_new4= "SELECT * FROM se_5_co_assignment_4";

			$result_new = mysqli_query($conn1,$sql_new);
			$result_new2= mysqli_query($conn1,$sql_new2);
			$result_new3= mysqli_query($conn1,$sql_new3);
			$result_new4= mysqli_query($conn1,$sql_new4);
			$j=1;
			while ($row=mysqli_fetch_assoc($result_new) and $row2=mysqli_fetch_assoc($result_new2) and $row3=mysqli_fetch_assoc($result_new3) and $row4=mysqli_fetch_assoc($result_new4) ) {
				?>
					<!--  -->
					<?php   $roll[$j]=$row['Roll_no']; ?>
					<?php  $name[$j]=$row['Name_of_Student']; ?>
					<?php  $a1=$row['Question_no_1']*$wtg11[1]; ?>
					<?php  $a2=$row['Question_no_2']*$wtg11[2]; ?>
					<?php  $a3=$row['Question_no_3']*$wtg11[3]; ?>
					<?php  $a4=$row['Question_no_4']*$wtg11[4]; ?>
					<?php  $a5=$row['Question_no_5']*$wtg11[5]; ?>

					<?php  $a6=$row2['Question_no_1']*$wtg11[6]; ?>
					<?php  $a7=$row2['Question_no_2']*$wtg11[7]; ?>
					<?php  $a8=$row2['Question_no_3']*$wtg11[8]; ?>
					<?php  $a9=$row2['Question_no_4']*$wtg11[9]; ?>
					<?php  $a10=$row2['Question_no_5']*$wtg11[10]; ?>

					<?php  $a11=$row3['Question_no_1']*$wtg11[11]; ?>
					<?php  $a12=$row3['Question_no_2']*$wtg11[12]; ?>
					<?php  $a13=$row3['Question_no_3']*$wtg11[13]; ?>
					<?php  $a14=$row3['Question_no_4']*$wtg11[14]; ?>
					<?php  $a15=$row3['Question_no_5']*$wtg11[15]; ?>

					<?php  $a16=$row4['Question_no_1']*$wtg11[16]; ?>
					<?php  $a17=$row4['Question_no_2']*$wtg11[17]; ?>
					<?php  $a18=$row4['Question_no_3']*$wtg11[18]; ?>
					<?php  $a19=$row4['Question_no_4']*$wtg11[19]; ?>
					<?php  $a20=$row4['Question_no_5']*$wtg11[20]; ?>
				<?php $ttlm11[$j]=($a1+$a2+$a3+$a4+$a5+$a6+$a7+$a8+$a9+$a10+$a11+$a12+$a13+$a14+$a15+$a16+$a17+$a18+$a19+$a20)/5;?>
				
				<?php
				$j++;			}
 			 ?>
 			
 			 	<?php 
 			 	//print_r($wtg11);
 			 	
 			 	
 			 	$j=1;
 			 	$c=1;
 			 	
 			 	while ($j<=4) {
 			 		# code...
 			 	$i=1;
 			 	while ($i<=5) {
 			 		# code...
 			 		$sql0= "SELECT COUNT(*)AS total FROM se_5_co_assignment_$j";
 			 		$result0=mysqli_query($conn1,$sql0);
 			 		// if ($result0) {
 			 		// 	echo "Success";
 			 		// }else echo "a";
 			 		$row0=mysqli_fetch_array($result0);
 			 		$ttl=$row0[0];
 			 		//echo "$ttl<br>";
 			 	
 			 		$sql = "SELECT COUNT(Question_no_$i)AS per FROM se_5_co_assignment_$j WHERE Question_no_$i>=3";
 			 		$result=mysqli_query($conn1,$sql);
 			 		$row=mysqli_fetch_assoc($result);
 			 		// if ($result) {
 			 		// 	echo "string";
 			 		// }else echo "b";
 			 		$per=($row['per']/$ttl)*100;
 			 		$percen11[$c]=$per;
 			 		$c++;
 	
 			 		$i++;

 			 	} 
 			 	$j++;}
  			 	
 			 		// print_r($assg11);
 			 		// print_r($percen11);
 			 	 $no=count($wtg11);
 			 	 //echo "$no";
 			 	 ?>

 			 	 	<?php $a=1;
 			 	 	//print_r($percen11);
 			 	 		while ($a<=$no) {
 			 	 			$ten11[$a]=($wtg11[$a]*$percen11[$a])/1000;
 			 	 		$a++;}
 			 	 	 ?>

 			 	 
 			 	 	<?php $v=1;
 			 	 		while ($v<=$no) {
 			 	 			if($percen11[$v]>=70)
 			 	 			{	$l=3;
 			 	 				$att11[$v]=$l;
 			 	 			}elseif ($percen11[$v]>=65) {
 			 	 				$l=2;$att11[$v]=$l;
 			 	 			}elseif ($percen11[$v]>=60) {
 			 	 				$l=1;$att11[$v]=$l;
 			 	 			}else{$l=round(($percen11[$v])/60);
 			 	 				$att11[$v]=$l;
 			 	 			}	
 			 	 		$v++;
 			 	 		}
 			 	 		//print_r($att11);
 			 	 	 ?>
 			 	 
 			 	 	<?php 
 			 	 	$z=1;
 			 	 	while ($z<=$no) {
 			 	 		$sum=$sum+($att11[$z]*$wtg11[$z]);
 			 	 		$z++;
 			 	 	}$fnlatt11=$sum/100;

 			 	 	 ?>
 			 	 	 

 		</tr>
 	</tbody>
 </table>
 </body>
 </html>