<?php

include_once 'db.php';

$wtg31=array();
$ttlm31=array();
$percen31=array();
$ten31=array();

/*session_start();*/
?>

<!DOCTYPE html>
 
<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI3 CO2

    </title>

  </head>

  <body>

    <table border='1' class='table table-bordered' class='table table-hover'>
    

    

        <th colspan="2">Quiz/Tutorial Number

        </th>

        <th>Q1

        </th>

        <th>Q2

        </th>

        <th>Q3

        </th>

        <th>Q4

        </th>

        <th>Q5

        </th>

        <th>T1

        </th>

        <th>T2

        </th>

        <th>T3

        </th>

        <th>T4

        </th>

        <th>T5

        </th>

        <th>T6

        </th>

        <th>T7

        </th>

        <th>T8

        </th>

        <th>T9

        </th>
        
        <th>T10

        </th>
        <th>Total</th>

      </tr>

<tr>
  <?php 
  $sql1="SELECT * FROM co_quiz_tut WHERE Course_Outcome_Number=1";
  $result1=mysqli_query($conn3,$sql1);
  $rownew=mysqli_fetch_assoc($result1)
   ?>

        <th colspan="2">Weightage

        </th>

        <td>

          <?php echo $rownew['QZ1']; $wtg31[1]=$rownew['QZ1']; ?>

        </td>

        <td>

          <?php echo $rownew['QZ2']; $wtg31[2]=$rownew['QZ2']; ?>

        </td>

        <td>

          <?php echo $rownew['QZ3']; $wtg31[3]=$rownew['QZ3']; ?>

        </td>

        <td>

          <?php echo $rownew['QZ4']; $wtg31[4]=$rownew['QZ4']; ?>

        </td>

        <td>

          <?php echo $rownew['QZ5']; $wtg31[5]=$rownew['QZ5']; ?>

        </td>

        <td>

          <?php echo $rownew['T1']; $wtg31[6]=$rownew['T1']; ?>

        </td>

        <td>

          <?php echo $rownew['T2']; $wtg31[7]=$rownew['T2']; ?>

        </td>

        <td>

          <?php echo $rownew['T3']; $wtg31[8]=$rownew['T3']; ?>

        </td>

        <td>

          <?php echo $rownew['T4']; $wtg31[9]=$rownew['T4']; ?>

        </td>

        <td>

          <?php echo $rownew['T5']; $wtg31[10]=$rownew['T5']; ?>

        </td>

        <td>

          <?php echo $rownew['T6']; $wtg31[11]=$rownew['T6']; ?>

        </td>

        <td>

          <?php echo $rownew['T7']; $wtg31[12]=$rownew['T7']; ?>

        </td>

        <td>

          <?php echo $rownew['T8']; $wtg31[13]=$rownew['T8']; ?>

        </td>

        <td>

          <?php echo $rownew['T9']; $wtg31[14]=$rownew['T9']; ?>

        </td>

        <td>

          <?php echo $rownew['T10']; $wtg31[15]=$rownew['T10']; ?>


        </td>

        <td><?php
          $total= $rownew['QZ1']+$rownew['QZ2']+$rownew['QZ3']+$rownew['QZ4']+$rownew['QZ5']+$rownew['T1']+$rownew['T2']+$rownew['T3']+$rownew['T4']+$rownew['T5']+$rownew['T6']+$rownew['T7']+$rownew['T8']+$rownew['T9']+$rownew['T10'];
           echo $total; ?>


        </td>
      </tr>

      <tr>

    
        <th>Name
        </th>

        <th>Roll no

        </th>

    
 <td colspan="15"></td>
      </tr>

      <?php

$j=1;

$sql="SELECT B.Roll_No,A.Name,B.Q1,B.Q2,B.Q3,B.Q4,B.Q5,B.T1,B.T2,B.T3,B.T4,B.T5,B.T6,B.T7,B.T8,B.T9,B.T10 FROM students as A,co_quiz_tutorial as B where A.Roll_No=B.Roll_NO";
$result=mysqli_query($conn3,$sql);
// if ($result) {
//   echo "1";
// }

// if ($result2) {
//   echo "2";
// }


?>
<tr><?php
$j=1;
while ($row=mysqli_fetch_assoc($result) )

{ 
echo "<td>";
echo $row['Roll_No'];
echo "</td>";

echo "<td>";
echo $row['Name'];
echo "</td>";

echo "<td>";
echo $row['Q1'];
echo "</td>";

echo "<td>";
echo $row['Q2'];
echo "</td>";

echo "<td>";
echo $row['Q3'];
echo "</td>";

echo "<td>";
echo $row['Q4'];
echo "</td>";

echo "<td>";
echo $row['Q5'];
echo "</td>";

echo "<td>";
echo $row['T1'];
echo "</td>";

echo "<td>";
echo $row['T2'];
echo "</td>";

echo "<td>";
echo $row['T3'];
echo "</td>";

echo "<td>";
echo $row['T4'];
echo "</td>";

echo "<td>";
echo $row['T5'];
echo "</td>";

echo "<td>";
echo $row['T6'];
echo "</td>";

echo "<td>";
echo $row['T7'];
echo "</td>";

echo "<td>";
echo $row['T8'];
echo "</td>";

echo "<td>";
echo $row['T9'];
echo "</td>";

echo "<td>";
echo $row['T10'];
echo "</td>";

$ttl=0;
$ttl=(($row['Q1']*$wtg31[1])+($row['Q2']*$wtg31[2])+($row['Q3']*$wtg31[3])+($row['Q4']*$wtg31[4])+($row['Q5']*$wtg31[5])+($row['T1']*$wtg31[6])+($row['T2']*$wtg31[7])+($row['T3']*$wtg31[8])+($row['T4']*$wtg31[9])+($row['T5']*$wtg31[10])+($row['T6']*$wtg31[11])+($row['T7']*$wtg31[12])+($row['T8']*$wtg31[13])+($row['T9']*$wtg31[14])+($row['T10']*$wtg31[15]))/5;
echo "<td>";
echo $ttl;
echo "</td>";
$ttlm31[$j]=$ttl;
$j++;
echo"</tr>";}
?> 
<tr>
   <td colspan="2">% of Students getting equal or more than 60%</td>
   <?php 
      $k=1;
      $l=1;
     // $j--;
      $m=1;

      $sqlavg="SELECT COUNT(*) as cn FROM co_quiz_tutorial";
      $resultavg=mysqli_query($conn3,$sqlavg);
      $rowavg=mysqli_fetch_assoc($resultavg);


      $no=1;

      while ($m<$j) {
        while ( $k<= 5) {
          $data='Q'.$k;
         $sql2="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
         $result2=mysqli_query($conn3,$sql2);
         $row4=mysqli_fetch_assoc($result2);

         echo "<td>";
         // $main=($row4['per']*$rowavg['cn'])/1000;
         // $percen31[$no]=$main;
         // $no++;
         $main=($row4['per']/$rowavg['cn'])*100;
         $percen31[$no]=$main;
          $no++;
         echo $main;
         echo "</td>";
         $k++;
        }
        while ( $l<= 10) {
          $data='T'.$l;
          $sql3="SELECT COUNT($data)AS per FROM co_quiz_tutorial WHERE $data>=3";
          $result2=mysqli_query($conn3,$sql3);
         $row5=mysqli_fetch_assoc($result2);

         echo "<td>";
         // $main=($row5['per']*$rowavg['cn'])/1000;
         // $percen31[$no]=$main;
         // $no++;
         $main=($row5['per']/$rowavg['cn'])*100;
         $percen31[$no]=$main;
          $no++;
         echo $main;
         echo "</td>";
         $l++;
        }
        $m++;
      }
      // echo"$no";
      // print_r($percen31);
    ?>
    
</tr>
<tr><td colspan="2">OUT OF 10</td>
          <?php 
          $sum=0;
          for ($i=1; $i < 16; $i++) { 
            $ten31[$i]=($percen31[$i]*$wtg31[$i])/1000;
            $sum=$sum+$ten31[$i];
      echo "<td>";
      echo $ten31[$i];
      echo"</td> ";} 
      ?><td></td>
      </tr>


      <!-- ````````````````````````````````````````````````````````````````````````````````````````````````````` -->
  <tr><td colspan="2">TOTAL</td>
        <td colspan="14" align="center"><?php echo "$sum"; ?></td>
      </tr>
      <tr><td colspan="2">Attainment Level</td>
        <?php $no=count($wtg31);
        $v=1;
      while ($v<=$no) {
              if($percen31[$v]>=70)
              { $l=3;
                $att31[$v]=$l;
                echo "<td>";echo $l; echo "</td>";
              }elseif ($percen31[$v]>=65) {
                $l=2;$att31[$v]=$l;
                echo "<td>";echo $l; echo "</td>";
              }elseif ($percen31[$v]>=60) {
                $l=1;$att31[$v]=$l;
                echo "<td>";echo $l; echo "</td>";
              }else{$l=round(($percen31[$v])/60);
                $att31[$v]=$l;
                echo "<td>";echo $l; echo "</td>";}
              
            $v++;
            }?>
            <td></td>
          </tr>

           <tr>
          <td colspan="2">Attainment Level for Performance Indicator</td>
          <?php 
          $z=1;
          $sum1=0;
          while ($z<=$no) {
            $sum1=$sum1+($att31[$z]*$wtg31[$z]);
            $z++;
          }$fnlatt=$sum1/100;
          //$_SESSION['pi4co1_ttl'] = $ttlm;
           ?>
           <td colspan="16" align="center"><?php echo "$fnlatt"; ?></td>
         </tr>
</table>
  </body>
</html>