<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
	<TITLE> CO QUIZ TUT</TITLE>
	<SCRIPT language="javascript">
		function addRow(tableID) {
			
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Course_Outcome_Number[]'/>";
			
			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  name='QZ1[]'/>";

			var cell4 = row.insertCell(3);
			cell4.innerHTML =  "<input type='text'  name='QZ2[]' />";

			var cell5 = row.insertCell(4);
			cell5.innerHTML = "<input type='text' name='QZ3[]'/>";

			var cell6 = row.insertCell(5);
			cell6.innerHTML = "<input type='text' name='QZ4[]'/>";

			var cell7 = row.insertCell(6);
			cell7.innerHTML = "<input type='text' name='QZ5[]'/>";

			var cell8 = row.insertCell(7);
			cell8.innerHTML = "<input type='text' name='T1[]'/>";

			var cell9 = row.insertCell(8);
			cell9.innerHTML = "<input type='text' name='T2[]'/>";
			
			var cell10 = row.insertCell(9);
			cell10.innerHTML = "<input type='text' name='T3[]'/>";

			var cell11 = row.insertCell(10);
			cell11.innerHTML = "<input type='text' name='T4[]'/>";

			var cell12 = row.insertCell(11);
			cell12.innerHTML = "<input type='text' name='T5[]'/>";

			var cell13 = row.insertCell(12);
			cell13.innerHTML = "<input type='text' name='T6[]'/>";

			var cell14 = row.insertCell(13);
			cell14.innerHTML = "<input type='text' name='T7[]'/>";

			var cell15 = row.insertCell(14);
			cell15.innerHTML = "<input type='text' name='T8[]'/>";

			var cell16 = row.insertCell(15);
			cell16.innerHTML = "<input type='text' name='T9[]'/>";

			var cell17 = row.insertCell(16);
			cell17.innerHTML = "<input type='text' name='T10[]'/>";

			



		}

		function deleteRow(tableID) {

			try {
				var table = document.getElementById(tableID);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY><!-- 
	========================================================================================================== -->

	<table>
		<tr>
			<th>Course_Outcome_Number</th>
			<th>QZ1</th>
			<th>QZ2</th>
			<th>QZ3</th>
			<th>QZ4</th>
			<th>QZ5</th>
			<th>T1</th>
			<th>T2</th>
			<th>T3</th>
			<th>T4</th>
			<th>T5</th>
			<th>T6</th>
			<th>T7</th>
			<th>T8</th>
			<th>T9</th>
			<th>T10</th>
		</tr>
		
		<?php
		if(isset($_POST['print']))
		{
			$sql_new = "SELECT Course_Outcome_Number, QZ1, QZ2, QZ3, QZ4, QZ5, T1, T2, T3, T4, T5, T6 ,T7, T8, T9, T10 FROM CO_QUIZ_TUT";
			$result_new = $conn->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
  
<tr>
	
	<td><?php echo $row['Course_Outcome_Number']; ?></td>
	<td><?php echo $row['QZ1']; ?></td>
	<td><?php echo $row['QZ2']; ?></td>
	<td><?php echo $row['QZ3']; ?></td>
	<td><?php echo $row['QZ4']; ?></td>
	<td><?php echo $row['QZ5']; ?></td>
	<td><?php echo $row['T1']; ?></td>
	<td><?php echo $row['T2']; ?></td>
	<td><?php echo $row['T3']; ?></td>
	<td><?php echo $row['T4']; ?></td>
	<td><?php echo $row['T5']; ?></td>
	<td><?php echo $row['T6']; ?></td>
	<td><?php echo $row['T7']; ?></td>
	<td><?php echo $row['T8']; ?></td>
	<td><?php echo $row['T9']; ?></td>
	<td><?php echo $row['T10']; ?></td>
</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>






<!-- 
	========================================================================================================== -->
	<?php
	if(isset($_POST['submit']))
	{
		
		foreach ($_POST['Course_Outcome_Number'] as $key => $value) 
			
			{
		$Course_Outcome_Number = $_POST["Course_Outcome_Number"][$key];
		$QZ1 = $_POST["QZ1"][$key];
		$QZ2 = $_POST["QZ2"][$key];
		$QZ3 = $_POST["QZ3"][$key];
		$QZ4 = $_POST["QZ4"][$key];
		$QZ5 = $_POST["QZ5"][$key];
		$T1 = $_POST["T1"][$key];
		$T2 = $_POST["T2"][$key];
		$T3 = $_POST["T3"][$key];
		$T4 = $_POST["T4"][$key];
		$T5 = $_POST["T5"][$key];
		$T6 = $_POST["T6"][$key];
		$T7 = $_POST["T7"][$key];
		$T8 = $_POST["T8"][$key];
		$T9 = $_POST["T9"][$key];
		$T10 = $_POST["T10"][$key];


            /*$sql = mysql_query("insert into your_table_name values ('','$Course_Outcome_Number', '$QZ1', '$QZ2')");   
*/
            $sql = "INSERT INTO CO_QUIZ_TUT (Course_Outcome_Number, QZ1, QZ2, QZ3, QZ4, QZ5, T1, T2, T3, T4, T5, T6 ,T7, T8, T9, T10) VALUES ('$Course_Outcome_Number','$QZ1','$QZ2','$QZ3','$QZ4','$QZ5','$T1','$T2','$T3','$T4','$T5','$T6','$T7','$T8','$T9','$T10')";
            $result = mysqli_query($conn,$sql);

        }
        
    } 
    ?> 
    <INPUT type="button" value="Add Row" onClick="addRow('dataTable')" />

    <INPUT type="button" value="Delete Row" onClick="deleteRow('dataTable')" />

    <form action="" method="post" name="f">  

    	<TABLE width="425" border="1">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<th width="94" name ="Course_Outcome_Number">Course_Outcome_Number</th>
    				<th width="121" name ="QZ1">QZ1</th>
    				<th width="84" name ="QZ2">QZ2</th>
    				<th width="84" name ="QZ3">QZ3</th>
    				<th width="100" name ="QZ4">QZ4</th>
    				<th width="84" name ="QZ5">QZ5</th>
    				<th width="84" name ="T1">T1</th>
    				<th width="84" name ="T2">T2</th>
    				<th width="84" name ="T3">T3</th>
    				<th width="84" name ="T4">T4</th>
    				<th width="84" name ="T5">T5</th>
    				<th width="84" name ="T6">T6</th>
    				<th width="84" name ="T7">T7</th>
    				<th width="84" name ="T8">T8</th>
    				<th width="84" name ="T9">T9</th>
    				<th width="84" name ="T10">T10</th>
    			</tr>
    		</thead>

    		<tbody id="dataTable">

    		</tbody>
    	</TABLE>

    	<INPUT type="submit" value="Insert" name="submit" />

    	<INPUT type="submit" value="print" name="print" />
    </form>
</BODY>
</HTML>