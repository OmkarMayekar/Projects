<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<TITLE> CO QUIZ AND TUTORIAL PAGE 4 </TITLE>
	<SCRIPT language="javascript">
		function addRow(tableID_CO_QUIZ_AND_TUTORIAL) {
			
			var table = document.getElementById(tableID_CO_QUIZ_AND_TUTORIAL);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			// var cell2 = row.insertCell(1);
			// cell2.innerHTML = "<input type='text' name='Course_Outcome_Number[]'/>";

			var cell3 = row.insertCell(1);
			cell3.innerHTML = "<input type='text' name='Roll_no[]'/>";

			var cell4 = row.insertCell(2);
			cell4.innerHTML = "<input type='text'  name='Q1[]'/>";

			var cell5 = row.insertCell(3);
			cell5.innerHTML =  "<input type='text'  name='Q2[]' />";

			var cell6 = row.insertCell(4);
			cell6.innerHTML = "<input type='text' name='Q3[]'/>";

			var cell7 = row.insertCell(5);
			cell7.innerHTML = "<input type='text' name='Q4[]'/>";

			var cell8 = row.insertCell(6);
			cell8.innerHTML = "<input type='text' name='Q5[]'/>";

			var cell9 = row.insertCell(7);
			cell9.innerHTML = "<input type='text' name='Q6[]'/>";

			var cell10 = row.insertCell(8);
			cell10.innerHTML = "<input type='text' name='T1[]'/>";

			var cell11 = row.insertCell(9);
			cell11.innerHTML = "<input type='text' name='T2[]'/>";

			var cell12 = row.insertCell(10);
			cell12.innerHTML = "<input type='text' name='T3[]'/>";

			var cell13 = row.insertCell(11);
			cell13.innerHTML = "<input type='text' name='T4[]'/>";

			var cell14 = row.insertCell(12);
			cell14.innerHTML = "<input type='text' name='T5[]'/>";

			var cell15 = row.insertCell(13);
			cell15.innerHTML = "<input type='text' name='T6[]'/>";

			var cell16 = row.insertCell(14);
			cell16.innerHTML = "<input type='text' name='T7[]'/>";

			var cell17 = row.insertCell(15);
			cell17.innerHTML = "<input type='text' name='T8[]'/>";

			var cell17 = row.insertCell(16);
			cell17.innerHTML = "<input type='text' name='T9[]'/>";
					
			var cell18 = row.insertCell(17);
			cell18.innerHTML = "<input type='text' name='T10[]'/>";
		}

		function deleteRow(tableID_CO_QUIZ_AND_TUTORIAL) {

			try {
				var table = document.getElementById(tableID_CO_QUIZ_AND_TUTORIAL);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY><!-- 
	========================================================================================================== -->

	<table class="table table-hover">
		<t>
			<!-- <th>Course_Outcome_Number</th> -->
			<th>Roll No</th>
			<th>Q1</th>
			<th>Q2</th>
			<th>Q3</th>
			<th>Q4</th>
			<th>Q5</th>
			<th>Q6</th>
			<th>T1</th>
			<th>T2</th>
			<th>T3</th>
			<th>T4</th>
			<th>T5</th>
			<th>T6</th>
			<th>T7</th>
			<th>T8</th>
			<th>T9</th>
			<th>T10</th>
			</t>
		
		<?php
		if(isset($_POST['print_CO_QT']))
		{
			$sql_new = "SELECT  Roll_no, Q1, Q2, Q3, Q4, Q5, Q6, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10 FROM CO_Quiz_Tutorial";
		
				$result_new = $conn->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
   <!--  /*echo "<table><tr><td>" . $row["Course_Outcome_Number"]. "</td><td>" . $row["Q1"] . "</td><td>"
. $row["Q2"]. "</td><td>" . $row["Q3"]. "</td><td>" . $row["Q4"]. "</td></tr>";*/
-->
<tr>
	<td><?php echo $row['Roll_no']; ?></td>
	<td><?php echo $row['Q1']; ?></td>
	<td><?php echo $row['Q2']; ?></td>
	<td><?php echo $row['Q3']; ?></td>
	<td><?php echo $row['Q4']; ?></td>
	<td><?php echo $row['Q5']; ?></td>

	<td><?php echo $row['Q6']; ?></td>
	<td><?php echo $row['T1']; ?></td>
	<td><?php echo $row['T2']; ?></td>
	<td><?php echo $row['T3']; ?></td>
	<td><?php echo $row['T4']; ?></td>

	<td><?php echo $row['T5']; ?></td>
	<td><?php echo $row['T6']; ?></td>
	<td><?php echo $row['T7']; ?></td>
	<td><?php echo $row['T8']; ?></td>
	<td><?php echo $row['T9']; ?></td>
	<td><?php echo $row['T10']; ?></td>

</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>






<!-- 
	========================================================================================================== -->
	<?php
	if(isset($_POST['submit_CO_QT']))
	{
		
		foreach ($_POST['Roll_no'] as $key => $value) 
			
			 {          //$Course_Outcome_Number = $_POST["Course_Outcome_Number"][$key];
		$Roll_no = $_POST["Roll_no"][$key];
		$Q1 = $_POST["Q1"][$key];
		$Q2 = $_POST["Q2"][$key];
		$Q3 = $_POST["Q3"][$key];
		$Q4 = $_POST["Q4"][$key];
		$Q5 = $_POST["Q5"][$key];
		
		$Q6 = $_POST["Q6"][$key];
		$T1 = $_POST["T1"][$key];
		$T2 = $_POST["T2"][$key];
		$T3 = $_POST["T3"][$key];
		$T4 = $_POST["T4"][$key];

		$T5 = $_POST["T5"][$key];
		$T6 = $_POST["T6"][$key];
		$T7 = $_POST["T7"][$key];
		$T8 = $_POST["T8"][$key];
		$T9 = $_POST["T9"][$key];
		$T10 = $_POST["T10"][$key];


            /*$sql = mysql_query("insert into your_table_name values ('','$Course_Outcome_Number', '$Q1', '$Q2')");   
*/
            $sql = "INSERT INTO CO_Quiz_Tutorial (Roll_no, Q1, Q2, Q3, Q4, Q5, Q6, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10) VALUES ('$Roll_no','$Q1','$Q2','$Q3','$Q4','$Q5','$Q6','$T1','$T2','$T3','$T4','$T5','$T6','$T7','$T8','$T9','$T10')";
            
            	$result = mysqli_query($conn,$sql);

        }
        
    } 
    ?> 
    <INPUT type="button" value="Add Row" onClick="addRow('dataTable_CO_QT')" class="btn btn-secondary"/>

    <INPUT type="button" value="Delete Row" onClick="deleteRow('dataTable_CO_QT')" class="btn btn-secondary"/>

    <form action="" method="post" name="f">  

    	<TABLE width="425" border="1" class="table table-hover">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<!-- <th width="94" name ="Course_Outcome_Number">Course_Outcome_Number</th> -->
    				<th width="94" name ="Roll_no">Roll no</th>
    				<th width="121" name ="Q1">Q1</th>
    				<th width="84" name ="Q2">Q2</th>
    				<th width="84" name ="Q3">Q3</th>
    				<th width="99" name ="Q4">Q4</th>
    				<th width="84" name ="Q5">Q5</th>
    				<th width="84" name ="Q6">Q6</th>
    				<th width="84" name ="T1">T1</th>
    				<th width="84" name ="T2">T2</th>
    				<th width="99" name ="T3">T3</th>
    				<th width="84" name ="T4">T4</th>
					<th width="84" name ="T5">T5</th>
    				<th width="84" name ="T6">T6</th>
    				<th width="84" name ="T7">T7</th>
    				<th width="99" name ="T8">T8</th>
    				<th width="84" name ="T9">T9</th>
    				<th width="84" name ="T10">T10</th>
    			</tr>
    		</thead>

    		<tbody id="dataTable_CO_QT">

    		</tbody>
    	</TABLE>

    	<INPUT type="submit" value="Insert" name="submit_CO_QT" class="btn btn-secondary"/>

    	<INPUT type="submit" value="print" name="print_CO_QT" class="btn btn-secondary"/>
    </form>
</BODY>
</HTML>