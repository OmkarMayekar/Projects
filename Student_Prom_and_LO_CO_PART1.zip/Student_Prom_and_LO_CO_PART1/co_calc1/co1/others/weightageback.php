<?php 
include 'db.php';
if (isset($_POST['submit'])) {
	$i=1;
	$C=1;
	$n=0;
	$S1=$_POST['t1'];
	$S2=$_POST['t2'];
	$CT1=$_POST['t3'];
	$CT2=$_POST['t4'];
	$P1=$_POST['t5'];
	$P2=$_POST['t6'];
	$CS1=$_POST['t7'];
	$CS2=$_POST['t8'];
	$CS3=$_POST['t9'];
	$CS=$_POST['t10'];

	while ($i<7) {
		# code...
	
	$sql="INSERT INTO `4pg_cotuts`(`CO`,`T1`,`T2`,`T3`,`T4`,`T5`,`T6`,`T7`,`T8`,`T9`,`T10`) VALUES ($i,$S1[$n],$S2[$n],$CT1[$n],$CT2[$n],$P1[$n],$P2[$n],$CS1[$n],$CS2[$n],$CS3[$n],$CS[$n])";
	$result=mysqli_query($conn,$sql);
	if (!$result) {
		echo "not success<br>";
	}else{$C++;}
	$i++;
	$n++;
}
	if($C==7){
	header("Location:weightage.php?success");}
	else{
	header("Location:weightage.php?Unsuccess");}

	}



elseif (isset($_POST['submit1'])) {
	$i=1;
	$n=0;
	$C=1;
	$S1=$_POST['S1'];
	$S2=$_POST['S2'];
	$CT1=$_POST['CT1'];
	$CT2=$_POST['CT2'];
	$P1=$_POST['P1'];
	$P2=$_POST['P2'];
	$CS1=$_POST['CS1'];
	$CS2=$_POST['CS2'];
	$CS3=$_POST['CS3'];
	while ($i<7) {
		# code...
	
	$sql="INSERT INTO `4pg_coothers`(`CO`,`S1`,`S2`,`CT1`,`CT2`,`P1`,`P2`,`CS1`,`CS2`,`CS3`) VALUES ($i,$S1[$n],$S2[$n],$CT1[$n],$CT2[$n],$P1[$n],$P2[$n],$CS1[$n],$CS2[$n],$CS3[$n])";
	$result=mysqli_query($conn,$sql);
	if (!$result) {
		echo "not success<br>";
	}else{$C++;}
	$i++;
	$n++;
}
	if($C==7){echo "success";}
		else{
echo "Unsuccess";
	}
}
 ?>