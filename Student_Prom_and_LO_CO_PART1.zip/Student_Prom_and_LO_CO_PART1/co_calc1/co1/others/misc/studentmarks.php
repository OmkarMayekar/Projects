
<!Doctype html>
<HTML>
<HEAD>
	<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">
	<TITLE> Assignment </TITLE>
	<SCRIPT language="javascript">
		// function addRow(tableID) {
		// 	// for (var i = 0; i <5; i++) {
				
			
			
		// 	var table = document.getElementById(tableID);

		// 	var rowCount = table.rows.length;
		// 	var row = table.insertRow(rowCount);

		// 	var cell1 = row.insertCell(0);
		// 	cell1.innerHTML = "<input type='text' name='Roll_no[]'/>";

		// 	var cell2 = row.insertCell(1);
		// 	cell2.innerHTML = "<input type='text' name='Name_of_Student[]'/>";

		// 	var cell3 = row.insertCell(2);
		// 	cell3.innerHTML = "<input type='text'  value='0' name='t1[]'/>";

		// 	var cell4 = row.insertCell(3);
		// 	cell4.innerHTML =  "<input type='text'  value='0' name='t2[]' />";

		// 	var cell5 = row.insertCell(4);
		// 	cell5.innerHTML = "<input type='text'  value='0'name='t3[]'/>";

		// 	var cell6 = row.insertCell(5);
		// 	cell6.innerHTML = "<input type='text' value='0' name='t4[]'/>";

		// 	var cell7 = row.insertCell(6);
		// 	cell7.innerHTML = "<input type='text' value='0' name='t5[]'/>";

		// 	var cell8 = row.insertCell(7);
		// 	cell8.innerHTML = "<input type='text' value='0' name='t6[]'/>";
			
		// 	var cell9 = row.insertCell(8);
		// 	cell9.innerHTML = "<input type='text' value='0' name='t7[]'/>";
			
		// 	var cell10 = row.insertCell(9);
		// 	cell10.innerHTML = "<input type='text' value='0' name='t8[]'/>";
			
		// 	var cell11 = row.insertCell(10);
		// 	cell11.innerHTML = "<input type='text' value='0' name='t9[]'/>";

		// 	var cell12 = row.insertCell(11);
		// 	cell12.innerHTML = "<input type='text' name='t10[]'/>";
		// }

		//}
// -------------------------------------------------------------------------------------------

		function addRow1(tableID) {
			// for (var i = 0; i <5; i++) {
				
			
			
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			cell1.innerHTML = "<input type='text' name='Roll_no1[]'/>";

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Name_of_Student1[]'/>";

			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  value='0' name='S11[]'/>";

			var cell4 = row.insertCell(3);
			cell4.innerHTML = "<input type='text' value='0' name='S21[]'/>";

			var cell5 = row.insertCell(4);
			cell5.innerHTML = "<input type='text'  value='0' name='CT11[]'/>";

			var cell6 = row.insertCell(5);
			cell6.innerHTML =  "<input type='text'  value='0' name='CT21[]' />";

			var cell7 = row.insertCell(6);
			cell7.innerHTML = "<input type='text' value='0' name='P11[]'/>";

			var cell8 = row.insertCell(7);
			cell8.innerHTML = "<input type='text'  value='0'name='P21[]'/>";

			var cell9 = row.insertCell(8);
			cell9.innerHTML = "<input type='text' value='0' name='CS11[]'/>";

			var cell10 = row.insertCell(9);
			cell10.innerHTML = "<input type='text' value='0' name='CS21[]'/>";
			
			var cell11 = row.insertCell(10);
			cell11.innerHTML = "<input type='text' value='0' name='CS31[]'/>";
			
	
		}

		//}

	
	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY>

    <form action="insert_others.php" method="post">  
    	<!-- <center><h4><b>Select Assignment Number</b></h4> -->
	
	<!-- <form action="studentmarks.php" method="post">
			<select name="asno"><option value="se_5_co_assignment_1">Assignment 1</option>
			<option value="se_5_co_assignment_2">Assignment 2</option>
			<option value="se_5_co_assignment_3">Assignment 3</option>
			<option value="se_5_co_assignment_4">Assignment 4</option>
	</select></center><br> -->
    	<!-- <TABLE class="table table-bordered" width="425" border="1">
    		<thead>
    			<tr>
    				
    				
    				<th width="10%">Roll_no</th>
    				<th width="84">Name_of_Student</th>
    				<th width="84">T1</th>
    				<th width="84">T2</th>
    				<th width="84">T3</th>
    				<th width="84">T4</th>
    				<th width="84">T5</th>
    				<th width="84">T6</th>
    				<th width="84">T7</th>
    				<th width="84">T8</th>
    				<th width="84">T9</th>
    				<th width="84">T10</th>

				
    			</tr>
    		</thead>

    		<tbody id="dataTable">
    		
    		</tbody>
    	</TABLE>

<center>
    <INPUT type="button" value="Add Row" class="btn btn-success" onClick="addRow('dataTable')" />


		<INPUT type="submit" value="Submit" class="btn btn-success" name="submit" /> -->
<!-- ------------------------------------------------------------------------------------------------------------- -->
	
    	<TABLE class="table table-bordered" width="425" border="1">
    		<thead>
    			<tr>
    				
    				
    				<th width="10%">Roll_no</th>
    				<th width="84">Name_of_Student</th>
    				<th width="84">S1</th>
    				<th width="84">S2</th>
    				<th width="84">CT1</th>
    				<th width="84">CT2</th>
    				<th width="84">P1</th>
    				<th width="84">P2</th>
    				<th width="84">CS1</th>
    				<th width="84">CS2</th>
    				<th width="84">CS3</th>
    				

				
    			</tr>
    		</thead>

    		<tbody id="dTable">
    		
    		</tbody>
    	</TABLE>

<center>
    <INPUT type="button" value="Add Row" class="btn btn-success" onClick="addRow1('dTable')" />


		<INPUT type="submit" value="Submit" class="btn btn-success" name="submit1" />
    		
    	
    </form>
    <a href="print_assign.php"><button type="button" class="btn btn-success">Print</button></a>
</BODY>
</HTML>