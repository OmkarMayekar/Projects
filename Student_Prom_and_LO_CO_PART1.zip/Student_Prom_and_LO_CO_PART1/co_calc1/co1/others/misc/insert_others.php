<?php 
include ('dbConfig.php');
// 	if(isset($_POST['submit']))
// 	{
// 		$i=0;

		
		
// 		$Roll_no = $_POST["Roll_no"];
// 		$Name_of_Student = $_POST["Name_of_Student"];
// 		$T1=$_POST['t1'];
// 		$T2=$_POST['t2'];
// 		$T3=$_POST['t3'];
// 		$T4=$_POST['t4'];
// 		$T5=$_POST['t5'];
// 		$T6=$_POST['t6'];
// 		$T7=$_POST['t7'];
// 		$T8=$_POST['t8'];
// 		$T9=$_POST['t9'];
// 		$T10=$_POST['t10'];
		
// 		$count=count($Roll_no);
// 		// echo "$Roll_no[0]";
// 		// echo "$Name_of_Student[0]";
// 		// echo $T1[0];
// 		// echo $T2[0];
// 		// echo $T3[0];
// 		// echo $T4[0];
// 		// echo $T5[0];
// 		// echo $T6[0];
// 		// echo $T7[0];
// 		// echo $T8[0];
// 		// echo $T9[0];
// 		// echo $T10[0];

// 		echo "$count<br>";
// 		while ($i<$count) {
		

//             $sql = "INSERT INTO `se_5_tutorials`(`Roll_No`, `Name_of_Student`, `T1`, `T2`, `T3`, `T4`, `T5`, `T6`, `T7`, `T8`, `T9`, `T10`) VALUES ($Roll_no[$i],'$Name_of_Student[$i]',$T1[$i]),$T2[$i]),$T3[$i]),$T4[$i]),$T5[$i]),$T6[$i]),$T7[$i]),$T8[$i]),$T9[$i]),$T10[$i]))";

//             $result = mysqli_query($conn1,$sql);
//             if (!$result) {
//             	echo "Unsuccess";
//             }else{echo "Sucess";}

//        $i++; }
    
        
//   //header("Location:studentmarks.php?success");
// }
  if (isset($_POST['submit1'])) {
  	$i=0;
  	$Roll_no = $_POST["Roll_no1"];
		$Name_of_Student = $_POST["Name_of_Student1"];
		$S1=$_POST['S11'];
		$S2=$_POST['S21'];
		$CT1=$_POST['CT11'];
		$CT2=$_POST['CT21'];
		$P1=$_POST['P11'];
		$P2=$_POST['P21'];
		$CS1=$_POST['CS11'];
		$CS2=$_POST['CS21'];
		$CS3=$_POST['CS31'];
		
		$count=count($Roll_no);
		echo "$count";
		while ($i<$count) {
		
			$sql="INSERT INTO `se_5_others`(`Roll_No`, `Name_of_Student`, `S1`, `S2`, `CT1`, `CT2`, `P1`, `P2`, `CS1`, `CS2`, `CS3`) VALUES ($Roll_no[$i],$Name_of_Student[$i],$S1[$i],$S2[$i],$CT1[$i],$CT2[$i],$P1[$i],$P2[$i],$CS1[$i],CS2[$i],CS3[$i])";
            // $sql = "INSERT INTO `se_5_others`(`Roll_No`, `Name_of_Student`, `S1`, `S2`, `CT1`, `CT2`, `P1`, `P2`, `CS1`, `CS2`, `CS3`) VALUES ($Roll_no[$i],'$Name_of_Student[$i]',$S1[$i],$S2[$i],$CT1[$i],$CT2[$i],$P1[$i],$P2[$i],$CS1[$i],$CS2[$i],$CS3[$i])";

            $result = mysqli_query($conn1,$sql);
            if (!$result) {
            	echo "string";
            }else{echo "Success";}

       $i++; }
 // header("Location:stude0ntmarks.php?success");

  }
    ?> 