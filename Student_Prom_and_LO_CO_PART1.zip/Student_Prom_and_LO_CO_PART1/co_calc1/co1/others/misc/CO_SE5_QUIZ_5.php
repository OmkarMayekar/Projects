<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
	<TITLE> CO se5 Quiz 1 </TITLE>
	<SCRIPT language="javascript">
		function addRow(tableID_CO_SE5_Quiz_5) {
			
			var table = document.getElementById(tableID_CO_SE5_Quiz_5);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Marks[]'/>";

			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  name='Fin_Marks[]'/>";

		}

		function deleteRow(tableID_CO_SE5_Quiz_5) {

			try {
				var table = document.getElementById(tableID_CO_SE5_Quiz_5);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY><!-- 
	========================================================================================================== -->

	<table>
		<t>
			<th>Marks</th>
			<th>Fin_Marks</th>
		</t>
		
		<?php
		if(isset($_POST['print_CO_SE5_Quiz_5']))
		{
			$sql_new = "SELECT Marks, Fin_Marks FROM CO_SE5_QUIZ_5";
			$result_new = $conn->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
   <!--  /*echo "<table><tr><td>" . $row["Marks"]. "</td><td>" . $row["Fin_Marks"] . "</td><td>"
. $row["Class"]. "</td><td>" . $row["Email_ID"]. "</td><td>" . $row["Mobile_Number"]. "</td></tr>";*/
-->
<tr>
	<td><?php echo $row['Marks']; ?></td>
	<td><?php echo $row['Fin_Marks']; ?></td>
</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>






<!-- 
	========================================================================================================== -->
	<?php
	if(isset($_POST['submit_CO_SE5_Quiz_5']))
	{
		
		foreach ($_POST['Marks'] as $key => $value) 
			
			{          $Marks = $_POST["Marks"][$key];
		$Fin_Marks = $_POST["Fin_Marks"][$key];
            /*$sql = mysql_query("insert into your_table_name values ('','$Marks', '$Fin_Marks', '$Class')");   
*/
            $sql = "INSERT INTO CO_SE5_QUIZ_5 (Marks, Fin_Marks) VALUES ('$Marks','$Fin_Marks')";
            $result = mysqli_query($conn,$sql);

        }
        
    } 
    ?> 
    <INPUT type="button" value="Add Row" onClick="addRow('dataTable_CO_SE5_Quiz_5')" />

    <INPUT type="button" value="Delete Row" onClick="deleteRow('dataTable_CO_SE5_Quiz_5')" />

    <form action="" method="post" name="f">  

    	<TABLE width="425" border="1">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<th width="94" name ="Marks">Marks</th>
    				<th width="121" name ="Fin_Marks">Fin_Marks</th>
    			</tr>
    		</thead>

    		<tbody id="dataTable_CO_SE5_Quiz_5">

    		</tbody>
    	</TABLE>

    	<INPUT type="submit" value="Insert" name="submit_CO_SE5_Quiz_5" />

    	<INPUT type="submit" value="print" name="print_CO_SE5_Quiz_5" />
    </form>
</BODY>
</HTML>