<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
	<TITLE> Student Marks </TITLE>
	<SCRIPT language="javascript">
		function addRow1(tableID) {
			
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Roll_No[]'/>";

			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  name='Name_of_Student[]'/>";

			var cell4 = row.insertCell(3);
			cell4.innerHTML =  "<input type='text'  name='S1[]' />";

			var cell5 = row.insertCell(4);
			cell5.innerHTML = "<input type='text' name='S2[]'/>";

			var cell6 = row.insertCell(5);
			cell6.innerHTML = "<input type='text' name='CT1[]'/>";

			var cell7 = row.insertCell(6);
			cell7.innerHTML = "<input type='text' name='CT2[]'/>";

			var cell8 = row.insertCell(7);
			cell8.innerHTML = "<input type='text' name='CT2[]'/>";

			var cell9 = row.insertCell(8);
			cell9.innerHTML = "<input type='text' name='P1[]'/>";

			var cell10 = row.insertCell(9);
			cell10.innerHTML = "<input type='text' name='P2[]'/>";


			var cell11 = row.insertCell(10);
			cell11.innerHTML = "<input type='text' name='CS1[]'/>";


			var cell112 = row.insertCell(11);
			cell12.innerHTML = "<input type='text' name='CS2[]'/>";


			var cell13 = row.insertCell(12);
			cell13.innerHTML = "<input type='text' name='CS1[]'/>";


		}

		function deleteRow1(tableID) {

			try {
				var table = document.getElementById(tableID);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow1(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY><!-- 
	========================================================================================================== -->

	<table>
		<t>
			<th>Roll_No</th>
			<th>Name_of_Student</th>
			<th>S1</th>
			<th>S2</th>
			<th>CT1</th>
			<th>CT2</th>
			<th>P1</th>
			<th>P2</th>
			<th>CS1</th>
			<th>CS2</th>
			<th>CS3</th>
		</t>
		
		<?php
		if(isset($_POST['print1']))
		{
			$sql_new = "SELECT Roll_No, Name_of_Student, S1, S2, CT1, CT2, P1, P2, CS1, CS2, CS3 FROM se_5_others";
			$result_new = $conn1->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
   <!--  /*echo "<table><tr><td>" . $row["Roll_No"]. "</td><td>" . $row["Name_of_Student"] . "</td><td>"
. $row["S1"]. "</td><td>" . $row["S2"]. "</td><td>" . $row["CT1"]. "</td></tr>";*/
-->
<tr>
	<td><?php echo $row['Roll_No']; ?></td>
	<td><?php echo $row['Name_of_Student']; ?></td>
	<td><?php echo $row['S1']; ?></td>
	<td><?php echo $row['S2']; ?></td>
	<td><?php echo $row['CT1']; ?></td>
	<td><?php echo $row['CT2']; ?></td>
	<td><?php echo $row['P1']; ?></td>
	<td><?php echo $row['P2']; ?></td>
	<td><?php echo $row['CS1']; ?></td>
	<td><?php echo $row['CS2']; ?></td>
	<td><?php echo $row['CS3']; ?></td>

</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>






<!-- 
	========================================================================================================== -->
	<?php
	if(isset($_POST['submit1']))
	{
		
		foreach ($_POST['Roll_No'] as $key => $value) 
			
			{          $Roll_No = $_POST["Roll_No"][$key];
		$Name_of_Student = $_POST["Name_of_Student"][$key];
		$S1 = $_POST["S1"][$key];
		$S2 = $_POST["S2"][$key];
		$CT1 = $_POST["CT1"][$key];
		$CT2 = $_POST["CT2"][$key];
		$P1 = $_POST["P1"][$key];
		$P2 = $_POST["P2"][$key];
		$CS1 = $_POST["CS1"][$key];
		$CS2 = $_POST["CS2"][$key];
		$CS3 = $_POST["CS3"][$key];

            /*$sql = mysql_query("insert into your_table_name values ('','$Roll_No', '$Name_of_Student', '$S1')");   
*/
            $sql = "INSERT INTO se_5_others (Roll_No, Name_of_Student, S1, S2, CT1, CT2, P1, P2, CS1, CS2, CS3) VALUES ('$Roll_No','$Name_of_Student','$S1','$S2','$CT1','$CT2','$P1','$P2','$CS1','$CS2','$CS3')";
            $result = mysqli_query($conn1,$sql);

        }
        
    } 
    ?> 
    <INPUT type="button" value="Add Row" onClick="addRow1('dataTable1')" />

    <INPUT type="button" value="Delete Row" onClick="deleteRow1('dataTable1')" />

    <form action="" method="post" name="f">  

    	<TABLE width="425" border="1">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<th width="94" name ="Roll_No">Roll_No</th>
    				<th width="121" name ="Name_of_Student">Name_of_Student</th>
    				<th width="84" name ="S1">S1</th>
    				<th width="84" name ="S2">S2</th>
    				<th width="100" name ="CT1">CT1</th>
    				<th width="84" name ="CT2">CT2</th>
    				<th width="84" name ="P1">P1</th>
    				<th width="84" name ="P2">P2</th>
    				<th width="84" name ="CT1">CT1</th>
    				<th width="84" name ="CT2">CT2</th>
    				<th width="84" name ="CT3">CT3</th>

    			</tr>
    		</thead>

    		<tbody id="dataTable1">

    		</tbody>
    	</TABLE>

    	<INPUT type="submit" value="Insert" name="submit1" />

    	<INPUT type="submit" value="print1" name="print1" />
    </form>
</BODY>
</HTML>