<?php 

 ?>
 <!DOCTYPE html>
 <html>
 <head>
	<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">

 	<title></title>
 </head>
 <body>
 		<form action="weightageback.php" method="post">
 	
	
    	<TABLE class="table table-bordered" width="425" border="1">

 	<!-- <thead><tr><th width="2%">CO</th>
 		<th>T1</th>
 		<th>T2</th>
 		<th>T3</th>
 		<th>T4</th>
 		<th>T5</th>
 		<th>T6</th>
 		<th>T7</th>
 		<th>T8</th>
 		<th>T9</th>
 		<th>T10</th> -->
 		<!-- <th>S1</th>
 		<th>S2</th>
 		<th>CT1</th>
 		<th>CT2</th>
 		<th>P1</th>
 		<th>P2</th>
 		<th>CS1</th>
 		<th>CS2</th>
 		<th>CS3</th> -->
 	<!-- </tr></thead> -->
 	<!-- <tbody> -->
 		<!-- <?php $i=1;
 		// while ($i<7) {
 		 	# code...
 		 ?>
 		<tr><td><?php ; ?></td>
 		<td><input type="text"  style="width: 100px;"name="t1[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t2[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t3[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t4[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t5[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t6[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t7[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t8[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t9[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="t10[]" value="0"></td>


 	</tr>
 	<?php $i ?>
 </tbody> -->
 	
 </table>	
   <!-- <input type="text" name="tuts" value="tuts" hidden="true">
 <center><input type="submit" name="submit" value="Submit" class="btn btn-success"></center> -->

 <br>
 	<TABLE class="table table-bordered" width="425" border="1">

 	<thead><tr><th width="2%">CO</th>
 		<th>S1</th>
 		<th>S2</th>
 		<th>CT1</th>
 		<th>CT2</th>
 		<th>P1</th>
 		<th>P2</th>
 		<th>CS1</th>
 		<th>CS2</th>
 		<th>CS3</th>
 		
 		<!-- <th>S1</th>
 		<th>S2</th>
 		<th>CT1</th>
 		<th>CT2</th>
 		<th>P1</th>
 		<th>P2</th>
 		<th>CS1</th>
 		<th>CS2</th>
 		<th>CS3</th> -->
 	</tr></thead>
 	<tbody>
 		<?php $i=1;
 		while ($i<7) {
 		 	# code...
 		 ?>
 		<tr><td><?php echo "$i"; ?></td>
 		<td><input type="text"  style="width: 100px;" name="S1[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="S2[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="CT1[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="CT2[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="P1[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="P2[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="CS1[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="CS2[]" value="0"></td>
 		<td><input type="text" style="width: 100px;" name="CS3[]" value="0"></td>


 	</tr>
 	<?php $i++;} ?>
 </tbody>
 	
 </table><input type="text" name="others" value="others" hidden="true">
 <center><input type="submit" name="submit1" value="Push" class="btn btn-success"></center>
 
 </body>
 </html>