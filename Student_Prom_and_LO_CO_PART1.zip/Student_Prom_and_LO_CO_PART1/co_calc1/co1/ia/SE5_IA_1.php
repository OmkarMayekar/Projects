<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<TITLE>SE5 IA 1</TITLE>
	<SCRIPT language="javascript">
		function addRow(tableID_SE5_IA_1) {
			
			var table = document.getElementById(tableID_SE5_IA_1);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Roll_no[]'/>";

			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  name='Name[]'/>";

			var cell4 = row.insertCell(3);
			cell4.innerHTML =  "<input type='text'  name='Q1_A[]' />";

			var cell5 = row.insertCell(4);
			cell5.innerHTML = "<input type='text' name='Q1_B[]'/>";

			var cell6 = row.insertCell(5);
			cell6.innerHTML = "<input type='text' name='Q1_C[]'/>";

			var cell7 = row.insertCell(6);
			cell7.innerHTML = "<input type='text' name='Q1_D[]'/>";

			var cell8 = row.insertCell(7);
			cell8.innerHTML = "<input type='text' name='Q1_E[]'/>";

			var cell9 = row.insertCell(8);
			cell9.innerHTML = "<input type='text' name='Q1_F[]'/>";

		

			var cell10 = row.insertCell(9);
			cell10.innerHTML = "<input type='text' name='Q2_A[]'/>";

			var cell11 = row.insertCell(10);
			cell11.innerHTML = "<input type='text' name='Q2_B[]'/>";

			var cell12 = row.insertCell(11);
			cell12.innerHTML = "<input type='text' name='Q3_A[]'/>";

			var cell13 = row.insertCell(12);
			cell13.innerHTML = "<input type='text' name='Q3_B[]'/>";
	

		}

		function deleteRow(tableID_SE5_IA_1) {

			try {
				var table = document.getElementById(tableID_SE5_IA_1);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY>

<!-- 
	========================================================================================================== -->


    <INPUT type="button" value="Add Row" onClick="addRow('dataTable_SE5_IA_1')" class="btn btn-secondary"/>

    <INPUT type="button" value="Delete Row" onClick="deleteRow('dataTable_SE5_IA_1')" class="btn btn-secondary"/>

    <form action="SE5_IA_BCK.php" method="post">  
    		<select name="select">
    			<option value="SE5_IA_1">SE5_IA_1</option>
    			<option value="SE5_IA_2">SE5_IA_2</option>
    			
    		</select>
    	<TABLE width="425" border="1" class="table table-hover">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<th width="94" name ="Roll_no">Roll_no</th>
    				<th width="121" name ="Name">Name</th>
    				<th width="84" name ="Q1_A">Q1_A</th>
    				<th width="84" name ="Q1_B">Q1_B</th>
    				<th width="99" name ="Q1_C">Q1_C</th>
    				<th width="84" name ="Q1_D">Q1_D</th>
    				<th width="84" name ="Q1_E">Q1_E</th>
    				<th width="84" name ="Q1_F">Q1_F</th>
    				
    				
    				<th width="84" name ="Q2_A">Q2_A</th>
					<th width="84" name ="Q2_B">Q2_B</th>
    				
    				
    				<th width="99" name ="Q3_A">Q3_A</th>
    				<th width="84" name ="Q3_B">Q3_B</th>
					
    				
    			</tr>
    		</thead>

    		<tbody id="dataTable_SE5_IA_1">

    		</tbody>
    	</TABLE>

    	<INPUT type="submit" value="Insert" name="submit_SE5_IA_1" class="btn btn-secondary"/>

    	<INPUT type="submit" value="total_round" name="total_round" class="btn btn-secondary"/>

    </form>
</BODY>
</HTML>