<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
	<TITLE> Internal_Assessment </TITLE>
	<SCRIPT language="javascript">
		function addRow(tableID2) {
			
			var table = document.getElementById(tableID2);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Course_Outcome_Number[]'/>";

			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  name='Internal_Assessment_1[]'/>";

			var cell4 = row.insertCell(3);
			cell4.innerHTML =  "<input type='text'  name='Internal_Assessment_2[]' />";
		}

		function deleteRow(tableID2) {

			try {
				var table = document.getElementById(tableID2);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY><!-- 
	========================================================================================================== -->

	<table>
		<t>
			<th>Course_Outcome_Number</th>
			<th>Internal_Assessment_1</th>
			<th>Internal_Assessment_2</th>
		</t>
		
		<?php
		if(isset($_POST['print2']))
		{
			$sql_new = "SELECT Course_Outcome_Number, Internal_Assessment_1, Internal_Assessment_2 FROM Internal_Assessment";
			$result_new = $conn->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
   
<tr>
	<td><?php echo $row['Course_Outcome_Number']; ?></td>
	<td><?php echo $row['Internal_Assessment_1']; ?></td>
	<td><?php echo $row['Internal_Assessment_2']; ?></td>
</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>






<!-- 
	========================================================================================================== -->
	<?php
	if(isset($_POST['submit2']))
	{
		
		foreach ($_POST['Course_Outcome_Number'] as $key => $value) 
			
			{          $Course_Outcome_Number = $_POST["Course_Outcome_Number"][$key];
		$Internal_Assessment_1 = $_POST["Internal_Assessment_1"][$key];
		$Internal_Assessment_2 = $_POST["Internal_Assessment_2"][$key];
	
            $sql = "INSERT INTO Internal_Assessment (Course_Outcome_Number, Internal_Assessment_1, Internal_Assessment_2) VALUES ('$Course_Outcome_Number','$Internal_Assessment_1','$Internal_Assessment_2')";
            $result = mysqli_query($conn,$sql);

        }
        
    } 
    ?> 




    <INPUT type="button" value="Add Row" onClick="addRow('dataTable2')" />

    <INPUT type="button" value="Delete Row" onClick="deleteRow('dataTable2')" />

    <form action="" method="post" name="f2">  

    	<TABLE width="425" border="1">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<th width="94" name ="Course_Outcome_Number">Course_Outcome_Number</th>
    				<th width="121" name ="Internal_Assessment_1">Internal_Assessment_1</th>
    				<th width="84" name ="Internal_Assessment_2">Internal_Assessment_2</th>
    			</tr>
    		</thead>

    		<tbody id="dataTable2">

    		</tbody>
    	</TABLE>


		<INPUT type="submit" value="Insert" name="submit2" />

    	<INPUT type="submit" value="Print" name="print2" />

    </form>
</BODY>
</HTML>