<?php
include('dbConfig.php');
?>
	<?php
	if(isset($_POST['submit_SE5_IA_1']))
	{
		$db=$_POST['select'];
		$qarray1=array();
		$qarray2=array();
		$qarray3=array();

		$Roll_no = $_POST['Roll_no'];
		$Name = $_POST['Name'];

		$q1=$_POST['Q1_A'];
		$q2=$_POST['Q1_B'];
		$q3=$_POST['Q1_C'];
		$q4=$_POST['Q1_D'];
		$q5=$_POST['Q1_E'];
		$q6=$_POST['Q1_F'];
		$c1=count($q1);
		$sum1=0;
		$totarray1=array();
		
		$q7=$_POST['Q2_A'];
		$q8=$_POST['Q2_B'];
		$totarray2=array();

		$q9=$_POST['Q3_A'];
		$q10=$_POST['Q3_B'];
		
		$totarray3=array();

		for ($i=0; $i < $c1; $i++) 
		{ 
			$qarray1[0]=$q1[$i];
			$qarray1[1]=$q2[$i];
			$qarray1[2]=$q3[$i];
			$qarray1[3]=$q4[$i];
			$qarray1[4]=$q5[$i];
			$qarray1[5]=$q6[$i];
			rsort($qarray1);
			$sum1=$qarray1[0]+$qarray1[1]+$qarray1[2]+$qarray1[3]+$qarray1[4];
			$totarray1[$i]=$sum1;


					$qarray2[0]=$q7[$i];
					$qarray2[1]=$q8[$i];
					rsort($qarray2);

					
					$totarray2[$i]=$qarray2[0];


					$qarray3[0]=$q9[$i];
					$qarray3[1]=$q10[$i];
					rsort($qarray3);

					
					$totarray3[$i]=$qarray3[0];



		}

		
			$i=0;
		while ($i<$c1) {
			$roundoff1=round($totarray1[$i]/2);
			$roundoff2=round($totarray2[$i]/2);
			$roundoff3=round($totarray3[$i]/2);

			$sql = "INSERT INTO $db (Roll_no, Name, Q1_A, Q1_B, Q1_C, Q1_D, Q1_E, Q1_F, Total_Q1, Total_Q1_ADJ, Q2_A, Q2_B, TotalQ2, Total_Q2_ADJ, Q3_A, Q3_B, TotalQ3, Total_Q3_ADJ) VALUES ('$Roll_no[$i]','$Name[$i]','$q1[$i]','$q2[$i]','$q3[$i]','$q4[$i]','$q5[$i]','$q6[$i]', $totarray1[$i],$roundoff1,'$q7[$i]','$q8[$i]',$totarray2[$i] ,$roundoff2,'$q9[$i]','$q10[$i]',$totarray3[$i],$roundoff3)";
			$result = mysqli_query($conn,$sql);
			$i++;   echo "Success!";
		}	
    } 
 
    ?> 

