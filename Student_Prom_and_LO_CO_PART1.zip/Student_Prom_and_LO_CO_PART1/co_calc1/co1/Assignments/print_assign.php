<!DOCTYPE html>
<html>
<head>
	<title>Print</title>
</head>
<body>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<center><h2><b>Select Assignment Number<br></b></h2>
			<select name="asno" id="asno" onchange="fun()">
			<option>Select</option>
			<option value="se_5_co_assignment_1">Assignment 1</option>
			<option value="se_5_co_assignment_2">Assignment 2</option>
			<option value="se_5_co_assignment_3">Assignment 3</option>
			<option value="se_5_co_assignment_4">Assignment 4</option>
	</select></center><br>
	<div id="data"></div>
	<script>  
		function fun(){
			var sel = document.getElementById('asno');
			var sv = sel.options[sel.selectedIndex].value;
			//alert(sv);
		 $(document).ready(function(){ 
 		$('#data').load("print_assignback.php",{db:sv});
 	 });
 }




  </script>
</body>
</html>