<?php
include 'dbConfig.php';
	if(isset($_POST['submit']))
	{
		$db=$_POST['asno'];
		
		$Sr_no = $_POST["Sr_no"];
		$Roll_no = $_POST["Roll_no"];
		$Name_of_Student = $_POST["Name_of_Student"];
		$Question_no_1 = $_POST["Question_no_1"];
		$Question_no_2 = $_POST["Question_no_2"];
		$Question_no_3 = $_POST["Question_no_3"];
		$Question_no_4 = $_POST["Question_no_4"];
		$Question_no_5 = $_POST["Question_no_5"];
		$i=0;
		$count=count($Sr_no);

		while ($i<$count) {
		
		$Total =$Question_no_1[$i]+$Question_no_2[$i]+$Question_no_3[$i]+$Question_no_4[$i]+$Question_no_5[$i];
		// echo "$Total <br>";
		if ($Total>=12) {
			$Grade='A+';
		}elseif ($Total>=10 and $Total<=11) {	
			# code..
			$Grade='A';
		}elseif($Total>=0 and $Total<10){$Grade='B';}
		//$Grade = $_POST["Grade"][$key];
		$RoundOFF_Q1 = ROUND(($Question_no_1[$i]/4)*5,0);
		$RoundOFF_Q2 = ROUND(($Question_no_2[$i]/4)*5,0);
		$RoundOFF_Q3 = ROUND(($Question_no_3[$i]/4)*5,0);
		$RoundOFF_Q4 = ROUND(($Question_no_4[$i]/4)*5,0);
		$RoundOFF_Q5 = ROUND(($Question_no_5[$i]/4)*5,0);

		// echo "$RoundOFF_Q1";echo "<br>";
		// echo "$RoundOFF_Q2";echo "<br>";
		// echo "$RoundOFF_Q3";echo "<br>";
		// echo "$RoundOFF_Q4";echo "<br>";
		// echo "$RoundOFF_Q5";echo "<br>";
            $sql = "INSERT INTO `$db`(`Sr_no`, `Roll_no`, `Name_of_Student`, `Question_no_1`, `RoundOFF_Q1`, `Question_no_2`, `RoundOFF_Q2`, `Question_no_3`, `RoundOFF_Q3`, `Question_no_4`, `RoundOFF_Q4`, `Question_no_5`, `RoundOFF_Q5`, `Total`, `Grade`) VALUES ($Sr_no[$i],$Roll_no[$i],'$Name_of_Student[$i]',$Question_no_1[$i],$RoundOFF_Q1,$Question_no_2[$i],$RoundOFF_Q2,$Question_no_3[$i],$RoundOFF_Q3,$Question_no_4[$i],$RoundOFF_Q4,$Question_no_5[$i],$RoundOFF_Q5,$Total,'$Grade')";

            $result = mysqli_query($conn,$sql);
            // if (!$result) {
            // 	echo "string";
            // }else{echo "Sucess";}

       $i++; }
    }
        
  header("Location:studentmarks.php?success")
    ?> 