<?php 
include 'dbConfig.php';
if (isset($_POST['db'])) {
	$db=$_POST['db'];
	
?>
<!DOCTYPE html>
<html>
<head>
	<title></title><link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">
</head>
<body>

<table class="table table-bordered">
		<tr>
			<th>Sr_no</th>
			<th>Roll_no</th>
			<th>Name_of_Student</th>
			<th>Question_no_1</th>
			<th>Question_no_2</th>
			<th>Question_no_3</th>
			<th>Question_no_4</th>
			<th>Question_no_5</th>
			<th>Total</th>
			<th>Grade</th>
		</tr>

<?php 

$sql_new = "SELECT Sr_no, Roll_no, Name_of_Student, Question_no_1, Question_no_2, Question_no_3, Question_no_4, Question_no_5, Total, Grade FROM $db";
			$result_new = $conn->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
   
<tr>
	<td><?php echo $row['Sr_no']; ?></td>
	<td><?php echo $row['Roll_no']; ?></td>
	<td><?php echo $row['Name_of_Student']; ?></td>
	<td><?php echo $row['Question_no_1']; ?></td>
	<td><?php echo $row['Question_no_2']; ?></td>
	<td><?php echo $row['Question_no_3']; ?></td>
	<td><?php echo $row['Question_no_4']; ?></td>
	<td><?php echo $row['Question_no_5']; ?></td>
	<td><?php echo $row['Total']; ?></td>
	<td><?php echo $row['Grade']; ?></td>
	</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>
</body></html>

