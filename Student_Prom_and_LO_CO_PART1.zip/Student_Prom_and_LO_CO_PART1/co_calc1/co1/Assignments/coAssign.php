<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">
	<title></title>
</head>
<body>
	<form action="coAssignback.php" method="post">
<table class="table table-bordered">
	<?php $j=1; while ($j <= 4) {
	?>
	<tr>
	<th rowspan="2" width=5%>CO No.</th>
	<th colspan="5">Assignment <?php echo "$j"; ?><input type="text" name="Ano[]" value="<?php echo($j);?>" hidden="true"></th>
	
	</tr>
	<tr>
		<td width="10%">Q1</td>
    	<td width="10%">Q2</td>
    	<td width="10%">Q3</td>
    	<td width="10%">Q4</td>
    	<td width="10%">Q5</td>
	</tr></td>
</td>
</td>
</td>
</td>
</td><?php $i=1;while ($i<7) {
?>
	<tr><td><span id="co1"></span>CO<?php echo "$i";?><input type="text" name="co[]" value="<?php echo($i);?>" hidden="true"></td>
		<td width="10%"><input type="text" name="q1[]" value="0"></td>
		<td width="10%"><input type="text" name="q2[]" value="0"></td>
		<td width="10%"><input type="text" name="q3[]" value="0"></td>
		<td width="10%"><input type="text" name="q4[]" value="0"></td>
		<td width="10%"><input type="text" name="q5[]" value="0"></td>

	</tr>
	<?php $i++; }?>

	</tbody>


<?php $j++;	} ?>
</table>
<input type="submit" name="submit"></form>
</body>
</html>