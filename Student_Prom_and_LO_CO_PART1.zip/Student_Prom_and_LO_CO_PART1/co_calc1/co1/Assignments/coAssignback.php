<?php
include('dbConfig1.php');
if($_POST['submit'])
{	
			$Q1=$_POST['q1'];
			$Q2=$_POST['q2'];
			$Q3=$_POST['q3'];
			$Q4=$_POST['q4'];
			$Q5=$_POST['q5'];
	 $i=1;
	 $n=0;
	 //$c=1;
	while ($i<=4) {
		$assignment=$i;	
		$j=1;
		while ($j<=6) {
			
			$assign=$i;
			$co=$j;
			$q1=$Q1[$n];
			$q2=$Q2[$n];
			$q3=$Q3[$n];
			$q4=$Q4[$n];
			$q5=$Q5[$n];
			$n++;




			

			

			$sql = "INSERT INTO `4pg_coassign`(`CO`, `Assignment_no`, `Q1`, `Q2`, `Q3`, `Q4`, `Q5`) VALUES ($co,$i,$q1,$q2,$q3,$q4,$q5)";
			$result=mysqli_query($conn,$sql);
			if (!$result) {
				echo "UNsucess<br>";
			}
			
		$j++;}
	$i++;}
}
echo"Success";
?>