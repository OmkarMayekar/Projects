<?php
include('dbConfig.php');
?>
<!Doctype html>
<HTML>
<HEAD>
	<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">
	<TITLE> SE_5_CO_Assignment_1 </TITLE>
	<SCRIPT language="javascript">
		function addRow(tableID) {
			
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			cell2.innerHTML = "<input type='text' name='Sr_no[]'/>";

			var cell3 = row.insertCell(2);
			cell3.innerHTML = "<input type='text'  name='Roll_no[]'/>";

			var cell4 = row.insertCell(3);
			cell4.innerHTML =  "<input type='text'  name='Name_of_Student[]' />";

			var cell5 = row.insertCell(4);
			cell5.innerHTML = "<input type='text' name='Question_no_1[]'/>";

			var cell6 = row.insertCell(5);
			cell6.innerHTML = "<input type='text' name='Question_no_2[]'/>";

			var cell7 = row.insertCell(6);
			cell7.innerHTML = "<input type='text' name='Question_no_3[]'/>";

			var cell8 = row.insertCell(7);
			cell8.innerHTML = "<input type='text' name='Question_no_4[]'/>";

			var cell9 = row.insertCell(8);
			cell9.innerHTML = "<input type='text' name='Question_no_5[]'/>";

			// var cell10 = row.insertCell(9);
			// cell10.innerHTML = "<input type='text' name='Total[]'/>";

			// var cell11 = row.insertCell(10);
			// cell11.innerHTML = "<input type='text' name='Grade[]'/>";


		}

		function deleteRow(tableID) {

			try {
				var table = document.getElementById(tableID);
				var rowCount = table.rows.length;

				for(var i=0; i<rowCount; i++) {
					var row = table.rows[i];
					var chkbox = row.cells[0].childNodes[0];
					if(null != chkbox && true == chkbox.checked) {
						table.deleteRow(i);
						rowCount--;
						i--;
					}
				}
			}catch(e) {
				alert(e);
			}
		}



	</SCRIPT>
	<style>
	table, th, td {
		border: 1px solid black;
	}
</style>
</HEAD>
<BODY><!-- 
	========================================================================================================== -->

	<table class="table table-bordered">
		<t>
			<th>Sr_no</th>
			<th>Roll_no</th>
			<th>Name_of_Student</th>
			<th>Question_no_1</th>
			<th>Question_no_2</th>
			<th>Question_no_3</th>
			<th>Question_no_4</th>
			<th>Question_no_5</th>
			<th>Total</th>
			<th>Grade</th>
		</t>
		
		<?php
		if(isset($_POST['print']))
		{
			$sql_new = "SELECT Sr_no, Roll_no, Name_of_Student, Question_no_1, Question_no_2, Question_no_3, Question_no_4, Question_no_5, Total, Grade FROM SE_5_CO_Assignment_1";
			$result_new = $conn->query($sql_new);
			

			if ($result_new->num_rows > 0) {
   // output data of each row


				while($row = $result_new->fetch_assoc()) 
				{
					?>
   
<tr>
	<td><?php echo $row['Sr_no']; ?></td>
	<td><?php echo $row['Roll_no']; ?></td>
	<td><?php echo $row['Name_of_Student']; ?></td>
	<td><?php echo $row['Question_no_1']; ?></td>
	<td><?php echo $row['Question_no_2']; ?></td>
	<td><?php echo $row['Question_no_3']; ?></td>
	<td><?php echo $row['Question_no_4']; ?></td>
	<td><?php echo $row['Question_no_5']; ?></td>
	<td><?php echo $row['Total']; ?></td>
	<td><?php echo $row['Grade']; ?></td>
	</tr>
<?php

}

} else { echo "0 results"; }

}
?>
</table>






<!-- 
	========================================================================================================== -->
	<?php
	if(isset($_POST['submit']))
	{
		
		foreach ($_POST['Sr_no'] as $key => $value) 
			
			{          $Sr_no = $_POST["Sr_no"][$key];
		$Roll_no = $_POST["Roll_no"][$key];
		$Name_of_Student = $_POST["Name_of_Student"][$key];
		$Question_no_1 = $_POST["Question_no_1"][$key];
		$Question_no_2 = $_POST["Question_no_2"][$key];
		$Question_no_3 = $_POST["Question_no_3"][$key];
		$Question_no_4 = $_POST["Question_no_4"][$key];
		$Question_no_5 = $_POST["Question_no_5"][$key];
		$Total =$Question_no_1+$Question_no_2+$Question_no_3+$Question_no_4+$Question_no_5;
		// echo "$Total <br>";
		if ($Total>=12) {
			$Grade='A+';
		}elseif ($Total>=10 and $Total<=11) {	
			# code..
			$Grade='A';
		}elseif($Total>=0 and $Total<10){$Grade='B';}
		//$Grade = $_POST["Grade"][$key];
		$RoundOFF_Q1 = ROUND(($Question_no_1/4)*5,0);
		$RoundOFF_Q2 = ROUND(($Question_no_2/4)*5,0);
		$RoundOFF_Q3 = ROUND(($Question_no_3/4)*5,0);
		$RoundOFF_Q4 = ROUND(($Question_no_4/4)*5,0);
		$RoundOFF_Q5 = ROUND(($Question_no_5/4)*5,0);

		// echo "$RoundOFF_Q1";echo "<br>";
		// echo "$RoundOFF_Q2";echo "<br>";
		// echo "$RoundOFF_Q3";echo "<br>";
		// echo "$RoundOFF_Q4";echo "<br>";
		// echo "$RoundOFF_Q5";echo "<br>";
            $sql = "INSERT INTO `se_5_co_assignment_1`(`Sr_no`, `Roll_no`, `Name_of_Student`, `Question_no_1`, `RoundOFF_Q1`, `Question_no_2`, `RoundOFF_Q2`, `Question_no_3`, `RoundOFF_Q3`, `Question_no_4`, `RoundOFF_Q4`, `Question_no_5`, `RoundOFF_Q5`, `Total`, `Grade`) VALUES ('$Sr_no','$Roll_no','$Name_of_Student','$Question_no_1','$RoundOFF_Q1','$Question_no_2','$RoundOFF_Q2','$Question_no_3','$RoundOFF_Q3','$Question_no_4','$RoundOFF_Q4','$Question_no_5','$RoundOFF_Q5','$Total','$Grade')";

            $result = mysqli_query($conn,$sql);

        }
        
    } 
    ?> 

   <center>
<INPUT type="submit" value="Print" class="btn btn-success"name="print" /></center>
<br><hr>

    <form action="" method="post" name="f">  

    	<TABLE class="table table-bordered" width="425" border="1">
    		<thead>
    			<tr>
    				<th width="98"></th>
    				<th width="94" name ="Sr_no">Sr_no</th>
    				<th width="121" name ="Roll_no">Roll_no</th>
    				<th width="84" name ="Name_of_Student">Name_of_Student</th>
    				<th width="84" name ="Question_no_1">Question_no_1</th>
    				<th width="84" name ="Question_no_2">Question_no_2</th>
    				<th width="84" name ="Question_no_3">Question_no_3</th>
    				<th width="84" name ="Question_no_4">Question_no_4</th>
    				<th width="84" name ="Question_no_5">Question_no_5</th>
					<!-- <th width="84" name ="Total">Total</th>
					<th width="84" name ="Grade">Grade</th> -->
    			</tr>
    		</thead>

    		<tbody id="dataTable">

    		</tbody>
    	</TABLE>
<center>

    <INPUT type="button" value="Add Row" class="btn btn-success" onClick="addRow('dataTable')" />

    <INPUT type="button" value="Delete Row" class="btn btn-danger" onClick="deleteRow('dataTable')" />

		<INPUT type="submit" value="Insert" class="btn btn-success" name="submit" />

    	

    	<!-- <INPUT type="submit" value="RoundOff" name="calculateroundoff" /> -->

    </form>
</BODY>
</HTML>