
<html>
<head>
	<link rel="stylesheet" href="../../../bootstrap4/css/bootstrap.css">
	<title>Select Assignment</title>
	<style type="text/css">
		 div {
  background-color: #636c70;
  background-repeat: no-repeat;
 /*background-position: right top;*/
   margin-top: 100px;
  margin-right: 100px;
   margin-left: 100px;
   /*margin-bottom: 10px;*/
   background-size: 100px;
   height: 300px
}
	</style>
</head>
<body><div>
	<center>
	<h2><b>Select Assignment Number</b></h2>
	<br><br>
	<form action="SE_5_CO_Assignment_1.php" method="post">
			<select name="asno"><option value="se_5_co_assignment_1">Assignment 1</option>
			<option value="se_5_co_assignment_2">Assignment 2</option>
			<option value="se_5_co_assignment_3">Assignment 3</option>
			<option value="se_5_co_assignment_4">Assignment 4</option>
</select>
<br><br>
<input type="submit" name="submit" class="btn btn-outline-success" value="submit"/>
</form>

</body>
</html>