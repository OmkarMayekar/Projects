<?php 
session_start();

require("db.php");

?>
<!DOCTYPE html>
<html>
<head>
	<title>domainSelect</title>
	<meta charset="utf-8"/>
</head>
<link rel="stylesheet" href="../bootstrap4/css/bootstrap.css">
<body>
	<form action="domainselectback1.php" method="POST">
	<h6><b>●
		Course Information: -	</b></h6>
	<script src="bootstrap4/js/bootstrap.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<div id="hel"><form action="domainselectback1.php" method="post">
	<table border="1" cellspacing="0" cellpadding="5" class="table table-striped" > 
		<tr>
			<td>Domain Number: 	Domain  <span id="yo"><select name="domainno" id="domainno">
			<option>Select Domain Number</option>
			<option value="1"> 1</option>
			<option value="2"> 2</option>
			<option value="3"> 3</option>
			<option value="4"> 4</option>
			<option value="5"> 5</option>
			<option value="6"> 6</option>
			<option value="7"> 7</option>
			<option value="8"> 8</option>
			<option value="9"> 9</option>


	</select></span>
</td>
		<td>Domain Name: <span id="domainname"></span> </td></tr>
		<tr><td>Theory Course Name:<span id="tcnamef"></span> </td>
			<td>Theory Course Number: <span id="dono"></span></td>
			</tr>
		<tr><td>Lab Course Name:<span id="lcnamef"></span></td>
			<td>Lab Cource Number: <span id="lcnf"></span> </td>
			</tr>
		<tr><td>Academic  Year: <?php echo date("Y",strtotime('-1 years'));echo "/"; echo date("Y");?></td>
			<td>Semester: <span id="sem"></span> </td></tr>
	</table>
</div>
 <script>  
 $(document).ready(function(){  					//load after page is ready
      $('select#domainno').change(function(){  
            var domaino = $(this).children("option:selected").val();  		//gets selected value
           // var string="a";
           $.ajax({  														//ajax call
                url:"domainselectback.php",  
                method:"POST",  
                data:{domaino:domaino, choice: "a"},  
                success:function(data){  
                     $('#domainname').html(data); 

                }  
           });  
      });  



      $('select#domainno').change(function(){  											//for domain name
            var domaino = $(this).children("option:selected").val();  
      	$('#tcnamef').load("domainselectback.php",{domaino:domaino,choice:"b"});			//alternative way for ajax call
      });

     $('select#domainno').change(function(){  
            var domaino = $(this).children("option:selected").val();  		//gets selected value
           // var string="a";

           $.ajax({  														//ajax call
                url:"domainselectback.php",  
                method:"POST",  
                data:{domaino:domaino, choice: "d"},  
                success:function(data){  
                     $('#lcnamef').html(data); 

                }  
           }); 
          
           			 //document.getElementById("uc1").value = temp;

            });
      });  

      // $('select#tcn').change(function(){  											//for domain name
      //       var domaino = $(this).children("option:selected").val();  
      //       alert("jhgfd");
      // 	$('#lcnf').load("domainselectback.php",{domaino:domaino,choice:"e"});			//alternative way for ajax call
      // });


 //});  
 function fun() {									//onchange is used this fun is called from backend
 	// body...
 	$(document).ready(function(){ 
 		var e = document.getElementById("tcname");
		var strUser = e.options[e.selectedIndex].value;
		//alert(strUser);
            
 		var e1 = document.getElementById("domainno");
		var strUser1 = e1.options[e.selectedIndex].value;


		$('#dono,#dono1').load("domainselectback.php",{coursename:strUser,domaino:strUser1, choice:"c"});
 	});
 }

 function fun1() {									//onchange is used this fun is called from backend
 	// body...
 	$(document).ready(function(){ 
 		var e = document.getElementById("lcname");
		var lcname = e.options[e.selectedIndex].value;
		//alert(strUser)
		//alert(strUser);
            
 		var e1 = document.getElementById("domainno");
		var domainno = e1.options[e.selectedIndex].value;


		$('#lcnf').load("domainselectback.php",{coursename:lcname,domaino:domainno, choice:"e"});
		$('#sem').load("domainselectback.php",{coursename:lcname,domaino:domainno, choice:"f"});

 	});
 }

 </script>
<!--  <script>	$(document).ready(function(){$('.dono1').on('DOMSubtreeModified',function(){ alert('changed') }) });
					</script> -->
 <!-- <input type="submit" name="submit"> </form> -->
</center>
<h6><b>●	Reasoning of Course Outcome and Performance Indicator Mapping: -<span id="succes"></span></b></h6>

	<table border="1" cellspacing="0" cellpadding="5" class="table" > 
<thead>
	<tr>
		<th>Course Outcome Number</th>
		<th>Unique Course Outcome Number</th>
		<th>Performance Indicator <!-- <select id="pi" onchange="fun5()"> --><!-- <option>1</option><option>2</option><option>3</option><option>4</option></select> --></th>
		<th>Reason</th>
	</tr>
</thead>
<tbody>
	<?php $n=1; 
	 echo"<script>var a=document.getElementById('dono').innerHTML;</script>";
	  echo"<script> document.writeln(a);</script>";
		while ($n <= 6) {
			?>
			<tr>
				<td><input type="text" name="co<?php echo($n);?>" value="CO<?php echo($n);?>"></td>
				<!-- <td> <span id="dono1"></span></td> -->
				<td><input type="text"  name="uc<?php echo($n);?>" value=""></td>
					<td><textarea rows="4" cols="20" name="pi<?php echo($n);?>"  ></textarea>
					</td>
					<td><textarea rows="4" cols="50" name="comment<?php echo($n);?>"></textarea></td>
			</tr>
			<?php
		$n++;
		
	} ?>
<!-- <script type="text/javascript">$(document).ready(function(){  					//load after page is ready
      $('#dono1').change(function(){ alert("hello"); }); }); </script>
</tbody> -->
</table><center>
<input type="text" name="choice" value="a" hidden="true">

 
<input type="submit" name="submit" value="Submit" class="btn btn-success"></center>
<!-- <center><input type="submit" name="submit" value="Submit" class="btn btn-success" id="btnSubmit" onclick="fun6()"></center><hr width="100%"> -->

<!-- <script type="text/javascript"> //script for pi 
function fun5() {

  var x = document.getElementById("pi").value;
  //alert(x);
  var i=1;
  var text = "";
  while (i <= x) {
  text += "PI " + i+"<br>";
  i++;
}
  document.getElementById("dono2").innerHTML = text;
}
</script> -->  <!-- pi for performance indicator -->
<!-- ------------------------------------------------------------------------------------------------------ -->
<!-- <script >
	function fun6(){
		alert("hello");
		// $(document).ready(function(){ $("#btnSubmit").click(function(){
			$(document).ready(function(){
			var a=document.getElementById("dono1").innerHTML;

			var b=$("#dono11").val();
			var c=a.concat(b);
			var d=document.getElementById("dono1").innerHTML;
			var e=document.getElementById("dono2").innerHTML;
			var f=document.getElementById("dono0").innerHTML;
			var g=$("#Reason").val();


			//alert(g);
		$('#succes').load("domainselectback.php",{a:a,b:b,,c:c,d:d,e:e,f:f,g:g,choice:"e"});
        
    }); 

		//});

	}

</script> -->

<!-- <button type="button" onclick="myfun()">clickme</button>

<script> function myfun(){ var a=document.getElementById("dono1").innerHTML;
													var b=document.getElementById("dono2").innerHTML;
													var c=a.concat(b)
													alert(c);
												}
												</script> -->
											</form>
</body>
</html>