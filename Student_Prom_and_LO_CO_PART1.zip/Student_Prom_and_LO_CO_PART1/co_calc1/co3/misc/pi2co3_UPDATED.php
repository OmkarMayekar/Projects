<?php

include_once('dbConfig.php');
include_once 'db.php';
include_once 'db2.php';
include_once 'db3.php';
/*session_start();*/
$ttlm2=array();
?>

<!DOCTYPE html>

<html>

  <head>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>PI2 CO3

    </title>

  </head>

  <body>

      <?php

$sqlwght = "SELECT * FROM `CO_IA_Mapping` WHERE Course_Outcome_Number=3";

$result_newwght = $conn3->query($sqlwght);

if ($result_newwght->num_rows > 0) {

while(($rowwght = $result_newwght->fetch_assoc())) 

{

?>

      

       

          <?php $w1=$rowwght['IA1_Q_No_1']; ?>

        

       

          <?php $w2=$rowwght['IA1_Q_No_2'];  ?>

        

       

          <?php $w3=$rowwght['IA1_Q_No_3'];  ?>

        

       

          <?php $w4=$rowwght['IA2_Q_No_1'];  ?>

        

       

          <?php $w5=$rowwght['IA2_Q_No_2'];  ?>

        

       

          <?php $w6=$rowwght['IA2_Q_No_3'];  ?>

        

      

      <?php

}

}

else{



} 

?>

      

      <?php 

$sql="SELECT *
FROM `se5_ia_1` AS A
INNER JOIN `se5_ia_2` AS B
ON B.`Roll_no` = A.`Roll_no`";
$result=mysqli_query($conn3,$sql);
$i=0;
$j=1;
while($row=mysqli_fetch_assoc($result)) 

{

?>

     
          <?php  $a1=$rowrollno['Roll_no']; ?>

        

          <?php  $a2=$rowname['Name'];  ?>

      

          <?php  $a3=$row1_7['Total_Q1_ADJ'];  ?>

      

          <?php  $a4=$row1_7['Total_Q2_ADJ'];  ?>


          <?php  $a5=$row1_7['Total_Q3_ADJ'];  ?>

       

          <?php  $a6=$row2_7['Total_Q1_ADJ'];  ?>

       

          <?php  $a7=$row2_7['Total_Q2_ADJ'];  ?>

       

          <?php  $a8=$row2_7['Total_Q3_ADJ'];  ?>

        

          <?php $sum=$a3+$a4+$a5+$a6+$a7+$a8;  

          $ttlm2[$j]=$sum;
          $j++;

          ?>

      <?php

}

} else { }

?>

      <?php

$sqlIA1i1 = "select count(Total_Q1_ADJ)/100 as countIA1i1 from SE5_IA_1 where Total_Q1_ADJ > 4 ";

$result_new11 = $conn3->query($sqlIA1i1);

$sqlIA1i2 = "select count(Total_Q2_ADJ)/100 as countIA1i2 from SE5_IA_1 where Total_Q2_ADJ > 4";

$result_new12 = $conn3->query($sqlIA1i2);

$sqlIA1i3 = "select count(Total_Q3_ADJ)/100 as countIA1i3 from SE5_IA_1 where Total_Q3_ADJ > 4";

$result_new13 = $conn3->query($sqlIA1i3);

$sqlIA2i1 = "select count(Total_Q3_ADJ)/100 as countIA2i1 from SE5_IA_1 where Total_Q3_ADJ > 4";

$result_new21 = $conn3->query($sqlIA2i1);

$sqlIA2i2 = "select count(Total_Q3_ADJ)/100 as countIA2i2 from SE5_IA_1 where Total_Q3_ADJ > 4";

$result_new22 = $conn3->query($sqlIA2i2);

$sqlIA2i3 = "select count(Total_Q3_ADJ)/100 as countIA2i3 from SE5_IA_1 where Total_Q3_ADJ > 4";

$result_new23 = $conn3->query($sqlIA2i3);                                                

$sqlavg = "select count(*) as c from SE5_IA_1";

$result_newavg = $conn3->query($sqlavg);

while (($rowi1 = $result_new11->fetch_assoc()) &&  ($rowi2 = $result_new12->fetch_assoc()) && ($rowi3 = $result_new13->fetch_assoc()) &&  ($rowj1 = $result_new21->fetch_assoc()) && ($rowj2 = $result_new22->fetch_assoc()) && ($rowj3 = $result_new23->fetch_assoc()) && ($rowavg = $result_newavg->fetch_assoc()))

{ 

$divavg = "{$rowavg['c']}";

$avg1i1 = "{$rowi1['countIA1i1']}";

$avg1i1f = $avg1i1 * $divavg;

$avg1i2 = "{$rowi2['countIA1i2']}";

$avg1i2f = $avg1i2 * $divavg;

$avg1i3 = "{$rowi3['countIA1i3']}";

$avg1i3f = $avg1i3 * $divavg;

$avg2i1 = "{$rowj1['countIA2i1']}";

$avg2i1f = $avg2i1 * $divavg;

$avg2i2 = "{$rowj2['countIA2i2']}";

$avg2i2f = $avg2i2 * $divavg;

$avg2i3 = "{$rowj3['countIA2i3']}";

$avg2i3f = $avg1i1 * $divavg;


/////////////////////////////////////////////////////////////////////

$a=$avg1i1f/100;

$b=$avg1i2f/100;

$c=$avg1i3f/100;

$d=$avg2i1f/100;

$e=$avg2i2f/100;

$f=$avg2i3f/100;

$total = $avg1i1f+$avg1i2f+$avg1i3f+$avg2i1f+$avg2i2f+$avg2i3f;
/*echo "$avg1i1f";echo "<br>";
echo "$avg1i2f";
echo "$avg1i3f";
echo "$avg2i1f";
echo "$avg2i2f";
echo "$avg2i3f";*/
$x=$total;



if($avg1i1f > 70){ 
$x1=3.0;


}elseif ($avg1i1f > 65) 

{
$x1=2.0;


}

else 

{
$x1=1.0;


}

/*++++++++++++++++*/

if($avg1i2f > 70){ 
$x2=3.0;

}elseif ($avg1i2f > 65) 

{
$x2=2.0;


}

else 

{
$x2=1.0;


}

/*++++++++++++++++*/

/*++++++++++++++++*/

if($avg1i3f > 70){ 
$x3=3.0;


}elseif ($avg1i3f > 65) 

{
$x3=2.0;


}

else 

{
$x3=1.0;


}

/*++++++++++++++++*/

/*++++++++++++++++*/

if($avg2i1f > 70){ 
$x4=3.0;


}elseif ($avg2i1f > 65) 

{
$x4=2.0;


}

else 

{
$x4=1.0;


}

/*++++++++++++++++*/

/*++++++++++++++++*/

if($avg2i2f > 70){ 
$x5=3.0;

}elseif ($avg2i2f > 65) 

{
$x5=2.0;


}

else 

{
$x5=1.0;


}

/*++++++++++++++++*/

/*++++++++++++++++*/

if($avg2i3f > 70){ 
$x6=3.0;


}elseif ($avg2i3f > 65) 

{
$x6=2.0;


}

else 

{
$x6=1.0;


}



}


$ATP=$avg1i1f*$x1+$avg1i2f*$x2+$avg1i3f*$x3+$avg2i1f*$x4+$avg2i2f*$x5+$avg2i3f*$x6;
$ATPF=$ATP/100;

$_SESSION['pi2co1_ttl'] = $ttlm2;
/*print_r
($ttlm2);*/


?>

      </body>

    </html>

​