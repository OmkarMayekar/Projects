<?php
/* Database connection settings */
$host = 'localhost';
$user = 'root';
$pass = 'donquixote';
$db = 'extra_co';
$conn3 = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
?>
