<?php 

include_once 'db.php';



include_once 'C:/xampp/htdocs/project/co_calc1/co3/pi1co3_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co3/pi2co3_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co3/pi3co3_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co3/pi4co3_UPDATED.php';
?>
 <!DOCTYPE html>
 <html>
 <head>	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
 	<title>CO1</title>
 </head>
 <body>
<table class="table table-bordered">
	<tr><th colspan="3">Performance Indicator Number</th>
		<td>P1</td>
		<td>P2</td>
		<td>P3</td>
		<td>P4</td>
		<th width="10%">Total</th>
	</tr>



		<?php
		$sqlwght1 ="SELECT * FROM courseoutcome3 WHERE co3_id=2";
		$result_newwght1 = $conn3->query($sqlwght1);
		//print_r($result_newwght1);

$wtg3=array();
		if ($result_newwght1) {


while(($rowwght1 = $result_newwght1->fetch_assoc())) 

{
?>
	<tr><th colspan="3">Weightage</th>
<td><?php $w1=$rowwght1['co3pi1'];echo $w1; $wtg3[1]=$w1;?></td>
<td><?php $w2=$rowwght1['co3pi2']; echo $w2;$wtg3[2]=$w2;?></td>
<td><?php $w3=$rowwght1['co3pi3']; echo $w3;$wtg3[3]=$w3;?></td>
<td><?php $w4=$rowwght1['co3pi4']; echo $w4;$wtg3[4]=$w4;?></td>
<?php
}
// print_r($wtg3);
}
else{
	echo "hello";
} 
?>

<td><?php $tot=$w1+$w2+$w3+$w4;  echo $tot;?></td></tr>
<tr><th>Sr_No.</th><th width="10%">Roll no</th><th width="10%">Name</th></tr>

<?php

$i=0;
$a=1;
$c=count($roll);

$c=$c-1;
$a1=array();//P1 MARKS
$a2=array();
$a3=array();
$a4=array();
$ttlmco3=array();

while($i<=$c) 
{ 
	?><tr>
		<td><?php echo "$a"; ?></td>
		<td><?php echo $roll[$a];?></td>
		<td><?php echo $name[$a];?></td>
		<td><?php $x1=($ttlm13[$a]/20);echo $x1;?></td>
		<td><?php $x2=($ttlm23[$a]/20);echo $x2;?></td>
		<td><?php $x3=($ttlm33[$a]/20);echo $x3;?></td>
		<td><?php $x4=($ttlm43[$a]/20);echo $x4;?></td>
		






<?php

$z1=$x1*$wtg3[1];
$z2=$x2*$wtg3[2];
$z3=$x3*$wtg3[3];
$z4=$x4*$wtg3[4];

$ttlv=($z1+$z2+$z3+$z4)/5;
echo "<td>"; echo $ttlv;echo"</td></tr>";
$ttlmco3[$a]=$ttlv;
$a1[$a]=$x1;
$a2[$a]=$x2;
$a3[$a]=$x3;
$a4[$a]=$x4;
$i++;
$a++;
}
$ab=1;
$s1=1;
?>
	<tr>
		<td colspan="3">% of Students getting equal or more than 60%</td>
		<?php 
		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a1[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var1 = ($sum/$c)*100; echo "$var1"; echo "</td>";
		$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a2[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var2 = ($sum/$c)*100; echo "$var2"; echo "</td>";
		

			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a3[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var3 = ($sum/$c)*100; echo "$var3"; echo "</td>";
		
			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a4[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


echo "<td>"; $var4 = ($sum/$c)*100; echo "$var4"; echo "</td>";
		?>
	</tr>

	<tr>

		<td colspan="3">OUT OF 10</td>

		<?php
		$q1=0;
		$q2=0;
		$q3=0;
		$q4=0;

		$q1=($var1*$wtg3[1])/1000;
		$q2=($var2*$wtg3[2])/1000;
		$q3=($var3*$wtg3[3])/1000;
		$q4=($var4*$wtg3[4])/1000;

		echo "<td>"; echo $q1."</td>";
		echo "<td>"; echo $q2."</td>";
		echo "<td>"; echo $q3."</td>";
		echo "<td>"; echo $q4."</td>";

		$qtotal = $q1+$q2+$q3+$q4;	


		?><td></td>

	</tr>
	
	<tr>
		<td colspan="3">TOTAL</td>
		<?php echo "<td colspan='4' align='center'>"; echo $qtotal."</td>";
		?><td></td>
	</tr>

	<tr>
		<th colspan="3">
			Attainment Level from Performance Indicator
		</th>
		<?php 
		echo "<td>"; echo $fnlatt13."</td>";
		echo "<td>"; echo $fnlatt23."</td>";
		echo "<td>"; echo $fnlatt33."</td>";
		echo "<td>"; echo $fnlatt43."</td>";

?><td></td>
	</tr>
	<tr>
		<th colspan="3">
			Attainment Level for Course Outcome
		</th>
		<td colspan="5" align="center">
			<?php 
					$qx1=($fnlatt13*$wtg3[1])/100;
		$qx2=($fnlatt23*$wtg3[2])/100;
		$qx3=($fnlatt33*$wtg3[3])/100;
		$qx4=($fnlatt43*$wtg3[4])/100;
		$add=$qx1+$qx2+$qx3+$qx4;
		 echo $add."</td>";

			?>

		</td>

	</tr>


</table> 
 </body>
 </html>
