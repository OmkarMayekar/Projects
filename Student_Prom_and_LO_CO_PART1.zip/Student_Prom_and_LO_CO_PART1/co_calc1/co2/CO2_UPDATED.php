<?php 

include_once 'db.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co2/pi1co2_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co2/pi2co2_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co2/pi3co2_UPDATED.php';
include_once 'C:/xampp/htdocs/project/co_calc1/co2/pi4co2_UPDATED.php';
?>
 <!DOCTYPE html>
 <html>
 <head>	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
 	<title>CO1</title>
 </head>
 <body>
		<?php
		$sqlwght1 ="SELECT * FROM courseoutcome2 WHERE co2_id=1";
		$result_newwght1 = $conn3->query($sqlwght1);
		//print_r($result_newwght1);

$wtg2=array();
		if ($result_newwght1) {


while(($rowwght1 = $result_newwght1->fetch_assoc())) 

{
?>
	
<?php $w1=$rowwght1['co2pi1'];$wtg2[1]=$w1;?>
<?php $w2=$rowwght1['co2pi2']; $wtg2[2]=$w2;?>
<?php $w3=$rowwght1['co2pi3']; $wtg2[3]=$w3;?>
<?php $w4=$rowwght1['co2pi4']; $wtg2[4]=$w4;?>
<?php
}
// print_r($wtg2);
}
else{
	echo "hello";
} 
$tot=$w1+$w2+$w3+$w4; 

$i=0;
$a=1;
$c=count($roll);

$c=$c-1;
$a1=array();//P1 MARKS
$a2=array();
$a3=array();
$a4=array();
$ttlmco2=array();

while($i<=$c) 
{ 
	
 $x1=($ttlm12[$a]/20);
 $x2=($ttlm22[$a]/20);
 $x3=($ttlm32[$a]/20);
$x4=($ttlm42[$a]/20);
		








$z1=$x1*$wtg2[1];
$z2=$x2*$wtg2[2];
$z3=$x3*$wtg2[3];
$z4=$x4*$wtg2[4];

$ttlvco2=($z1+$z2+$z3+$z4)/5;
$ttlmco2[$a]=$ttlvco2;
$a1[$a]=$x1;
$a2[$a]=$x2;
$a3[$a]=$x3;
$a4[$a]=$x4;
$i++;
$a++;
}
$ab=1;
$s1=1;
?>
	
		<?php 
		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a1[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


 $var1 = ($sum/$c)*100; 
		$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a2[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}

 $var2 = ($sum/$c)*100; 
		

			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a3[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


 $var3 = ($sum/$c)*100; 
		
			$s1=1;

		$sum= 0;
		while ($s1 <= $c) {
				# code...
			
			if ($a4[$s1]>=3) {
				$sum=$sum+1;
			}
			$s1++;
		}


 $var4 = ($sum/$c)*100; 
		?>
	

		<?php
		$q1=0;
		$q2=0;
		$q3=0;
		$q4=0;

		$q1=($var1*$wtg2[1])/1000;
		$q2=($var2*$wtg2[2])/1000;
		$q3=($var3*$wtg2[3])/1000;
		$q4=($var4*$wtg2[4])/1000;

		

		$qtotal = $q1+$q2+$q3+$q4;	




?>
			<?php 
					$qx1=($fnlatt12*$wtg2[1])/100;
		$qx2=($fnlatt22*$wtg2[2])/100;
		$qx3=($fnlatt32*$wtg2[3])/100;
		$qx4=($fnlatt42*$wtg2[4])/100;
		$fnlttlco2=$qx1+$qx2+$qx3+$qx4;
		

			?>

	


</table> 
 </body>
 </html>
