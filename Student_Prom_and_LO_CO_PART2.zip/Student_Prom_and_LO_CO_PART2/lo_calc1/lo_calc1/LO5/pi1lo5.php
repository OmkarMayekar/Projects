<?php
	include 'dbConfig.php';
	$percenl11pi1lo5=array();
	$row_value=array();
	$wpi1lo5=array();
	$outoftenpi1lo5=array();
	$tot_finalarraypi1lo5=array();
	$Attlevelarraypi1lo5=array();
	$tot_final=0;
	$count=0;
	$totalbottompi1lo5=0;
	$performancelevel=0;
	$final_performancelevelpi1lo5=0;	
	session_start();
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>PI_1_LO_1</title>
</head>
<body>
<table class="table table-bordered">
	<tr>
		<th colspan="2">Experiment Number</th>
		<?php
		for ($i=1; $i <=25; $i++) 
		{ 
		?>	
		<td><?php echo $i; ?></td>
		<?php
		}?>
		
		<td>Total</td>
		</tr>
		
		<?php
		
		$sql = "SELECT * FROM `LO_EXP_MAPPING` WHERE lo_No=5";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	<tr><th colspan="2">Weightage</th>
		<?php
		for ($i=1; $i <=25 ; $i++) { 
			?>
			<td><?php $wpi1lo5[$i]=$row['EXP_No_'.$i]; echo $wpi1lo5[$i]; ?></td>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=25 ; $i++) { 
$tot=$tot+$wpi1lo5[$i];
?>

<?php
}
?><td><?php echo $tot; ?></td>

</td></tr>





<tr>
<th>Roll no</th>
<th>Name</th>
<?php
for ($i=1; $i<=25  ; $i++) 
{
?>
<th></th>
<?php
}
?>
</tr>
<?php
	$sql_rollname = "SELECT se5a.Roll_no,se5a.exp1,se5a.exp2,se5a.exp3,se5a.exp4,se5a.exp5,se5a.exp6,se5a.exp7,se5a.exp8,se5a.exp9,se5a.exp10,se5a.exp11,se5a.exp12,se5a.exp13,se5a.exp14,se5a.exp15,se5a.exp16,se5a.exp17,\n"

    . "se5a.exp18,se5a.exp19,se5a.exp20,se5a.exp21,se5a.exp22,se5a.exp23,se5a.exp24,se5a.exp25,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$j=1;
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>

<?php
for ($i=1; $i <= 25; $i++) 
{ 
?>
<td>
<?php  
$row_value[$i] = $row_rollname['exp'.$i]; echo $row_value[$i]; ?>
</td>
<?php
}
?>

<td><?php $tot_final=(($wpi1lo5[$j]*$row_value[$j])+$tot_final)/5; $tot_finalarraypi1lo5[$j]=$tot_final; echo $tot_finalarraypi1lo5[$j]; ?></td>
<?php
$j++;
}
}
?>
<tr><th colspan="2">% of Students getting equal or more than 60%</th>

<?php

$sql="SELECT COUNT(Roll_no) FROM SE5_A";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);


	for ($i=1; $i <=25 ; $i++) 
	{ 
 $sql1="SELECT COUNT(exp$i) FROM SE5_A WHERE exp$i>2";
 $result1=mysqli_query($conn,$sql1);
 $row1=mysqli_fetch_array($result1);
 echo "<td>";
 $var=($row1[0]/$row[0])*100;
 $var1=round($var,2);
 $percenl11pi1lo5[$i]=$var1;
 echo "$percenl11pi1lo5[$i]";
 echo "</td>";
}
?>
</tr>
<!-- <?php
echo "<pre>";
var_dump($percenl11pi1lo5);
?> -->
<tr>
<th colspan="2">OUT OF 10</th>
<?php
for ($i=1; $i <=25 ; $i++) 
{ 
?>
<td><?php $outoftenpi1lo5[$i]=$wpi1lo5[$i]*$percenl11pi1lo5[$i]/1000; echo $outoftenpi1lo5[$i]; ?></td>
<?php
}
?>
</tr>
<tr>
	<th colspan="2">Total</th>
	<td align="center"><?php $totalbottompi1lo5=array_sum($outoftenpi1lo5); echo $totalbottompi1lo5;?></td>
</tr>
<tr>
<th colspan="2">Attainment Level</th>
<?php
$at1=1;
$at2=2;
$at3=3;

for ($i=1; $i <=25 ; $i++) 
{ 
if($percenl11pi1lo5[$i]>=70)
	{?>
		<td><?php $Attlevelarraypi1lo5[$i]=$at3; echo $at3; ?></td>
	<?php
	}
	elseif ($percenl11pi1lo5[$i]>=65) 
	{?>
		<td><?php $Attlevelarraypi1lo5[$i]=$at2; echo $at2; ?></td>
	<?php
	}
	elseif($percenl11pi1lo5[$i]>=60)
		{?>
			<td><?php $Attlevelarraypi1lo5[$i]=$at1; echo $at1;?></td>
<?php
	}
	else
		{?>

		<td><?php $Attlevelarraypi1lo5[$i]=round($percenl11pi1lo5[$i]/60,2); echo $Attlevelarraypi1lo5[$i];?></td>
	<?php }
}
?>
</tr>
<tr>
<th colspan="2">Attainment Level for Performance Indicator</th>
<?php
for ($i=1; $i <=25 ; $i++) 
	{$performancelevel=$performancelevel+($Attlevelarraypi1lo5[$i]*$wpi1lo5[$i]);
		?>
		
<?php
	}	
?><td><?php  $final_performancelevelpi1lo5=$performancelevel/100; echo $final_performancelevelpi1lo5; ?></td>
</tr>
</table>
</body>
</html>