<?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO5/pi1lo5_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO5/pi2lo5_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO5/pi3lo5_updated.php';

	$percenl11LO5=array();
	$row_value=array();
	$avg=array();
	$wLO5=array();
	$outoftenLO5=array();
	$LO5ARRAYPI1=array();
	$LO5ARRAYPI2=array();
	$LO5ARRAYPI3=array();
	$outoftenlo5=array();
	$LOPI1ARRAYLO5=array();
	$LO5TOTALROW=array();
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO5=0;
	$AttainmentLevelLO5_final=0;
	$n=sizeof($tot_finalarraypi1lo5);
	$n1=sizeof($LO5ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_5</title>
</head>
<body>
<table class="table table-bordered">
	<tr>
		<th colspan="2">Performance Indicator Number</th>
		<?php 
		for ($i=1; $i <=3; $i++) 
		{ 
		?>	
		<td><?php echo $i; ?></td>
		<?php
		}?>
		
		<td>Total</td>
		</tr>

				<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =5";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	<tr><th colspan="2">Weightage</th>
		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<td><?php $wLO5[$i]=$row['lo1pi'.$i]; echo $wLO5[$i]; ?></td>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$wLO5[$i];
?>

<?php
}
?><td><?php echo $tot; ?></td>

</td></tr>

<tr>
<th>Roll no</th>
<th>Name</th></tr>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;		
			$k=0;
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>

<td>
	<?php $LO5ARRAYPI1[$i]=$tot_finalarraypi1lo5[$j]/5; echo $tot_finalarraypi1lo5[$j]/5; ?>
</td>

<td>
	<?php $LO5ARRAYPI2[$i]=$totalrowpi2lo5[$j]/5; echo $totalrowpi2lo5[$j]/5; ?>
</td>

<td>
	<?php $LO5ARRAYPI3[$i]=$tot_finalarraypi3lo5[$j]/5; echo $tot_finalarraypi3lo5[$j]/5; ?>
</td>

<td>
	<?php $LO5TOTALROW[$k]=$LO5ARRAYPI1[$k]+$LO5ARRAYPI2[$k]+$LO5ARRAYPI3[$k]; echo $LO5TOTALROW[$k]; ?>
</td>

<?php
$i++;
$j++;
$k++;
}
}
?>
</tr>
<tr>
<th colspan="2">% of Students getting equal or more than 60%</th>
<?php
$j=1;
for ($i=0; $i <sizeof($LO5ARRAYPI1) ; $i++) { 
if ($LO5ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count1/sizeof($LO5ARRAYPI1))*100; echo $per1lo1[$j]; $j++;?></td>

<?php
for ($i=0; $i <sizeof($LO5ARRAYPI2) ; $i++) { 
if ($LO5ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count2/sizeof($LO5ARRAYPI2))*100; echo $per1lo1[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($LO5ARRAYPI3) ; $i++) { 
if ($LO5ARRAYPI3[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count3/sizeof($LO5ARRAYPI3))*100; echo $per1lo1[$j]; $j++; ?></td>

</tr>
<tr><th colspan="2">Out Of Ten</th>
<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo5[$i]=($per1lo1[$i]*$wLO5[$i])/1000;
?>
<td><?php echo $outoftenlo5[$i]; ?></td>
<?php
}
?>	
</tr>
<tr>
	<th colspan="2">Total</th>
	<td><?php echo array_sum($outoftenlo5); ?></td>
</tr>

<tr>
	<th colspan="2">Attainment Level from Performance Indicator</th>
	<td><?php $LOPI1ARRAYLO5[1]=$final_performancelevelpi1lo5; echo $LOPI1ARRAYLO5[1]; ?></td>
	<td><?php $LOPI1ARRAYLO5[2]=$performancelevelfinalpi2lo5; echo $LOPI1ARRAYLO5[2]; ?></td>
	<td><?php $LOPI1ARRAYLO5[3]=$totalperformancelevelpi3lo5; echo $LOPI1ARRAYLO5[3]; ?></td>
</tr>

<tr><th colspan="2">Attainment Level for Course Outcome</th>
<?php
for ($i=1; $i <sizeof($LOPI1ARRAYLO5) ; $i++) { 
$AttainmentLevelLO5=(($LOPI1ARRAYLO5[$i]*$wLO5[$i])+$AttainmentLevelLO5);
?>
<?php
}
?>	<td><?php $AttainmentLevelLO5_final=$AttainmentLevelLO5/100; echo $AttainmentLevelLO5_final; ?></td>

</tr>
</table>
</body>
</html>