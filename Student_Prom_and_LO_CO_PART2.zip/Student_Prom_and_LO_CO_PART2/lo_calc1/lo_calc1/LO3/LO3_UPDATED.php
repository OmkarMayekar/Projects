<?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO3/pi1lo3_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO3/pi2lo3_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO3/pi3lo3_updated.php';

	$percenl11LO3=array();
	$row_value=array();
	$avg=array();
	$wLO3=array();
	$outoftenLO3=array();
	$LO3ARRAYPI1=array();
	$LO3ARRAYPI2=array();
	$LO3ARRAYPI3=array();
	$outoftenlo3=array();
	$LOPI1ARRAYLO3=array();
	$LO3TOTALROW=array();
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO3=0;
	$AttainmentLevelLO3_final=0;
	$n=sizeof($tot_finalarraypi1lo3);
	$n1=sizeof($LO3ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_3</title>
</head>
<body>
	<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =3";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	
		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<?php $wLO3[$i]=$row['lo1pi'.$i];  ?>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$wLO3[$i];
?>

<?php
}
?>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;		
			$k=0;
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>



	<?php $LO3ARRAYPI1[$i]=$tot_finalarraypi1lo3[$j]/5; ?>


	<?php $LO3ARRAYPI2[$i]=$totalrowpi2lo3[$j]/5;  ?>



	<?php $LO3ARRAYPI3[$i]=$tot_finalarraypi3lo3[$j]/5;  ?>




	<?php $LO3TOTALROW[$k]=$LO3ARRAYPI1[$k]+$LO3ARRAYPI2[$k]+$LO3ARRAYPI3[$k];  ?>


<?php
$i++;
$j++;
$k++;
}
}
?>

<?php
$j=1;
for ($i=0; $i <sizeof($LO3ARRAYPI1) ; $i++) { 
if ($LO3ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count1/sizeof($LO3ARRAYPI1))*100;  $j++;?>

<?php
for ($i=0; $i <sizeof($LO3ARRAYPI2) ; $i++) { 
if ($LO3ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count2/sizeof($LO3ARRAYPI2))*100;  $j++; ?>

<?php
for ($i=0; $i <sizeof($LO3ARRAYPI3) ; $i++) { 
if ($LO3ARRAYPI3[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count3/sizeof($LO3ARRAYPI3))*100;  $j++; ?>

<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo3[$i]=($per1lo1[$i]*$wLO3[$i])/1000;
?>

<?php
}
?>	


	
	<?php $LOPI1ARRAYLO3[1]=$final_performancelevelpi1lo3;  ?>
<?php $LOPI1ARRAYLO3[2]=$performancelevelfinalpi2lo3; ?>
	<?php $LOPI1ARRAYLO3[3]=$totalperformancelevelpi3lo3; ?>


<?php
for ($i=1; $i <sizeof($LOPI1ARRAYLO3) ; $i++) { 
$AttainmentLevelLO3=(($LOPI1ARRAYLO3[$i]*$wLO3[$i])+$AttainmentLevelLO3);
?>
<?php
}
?>	<?php $AttainmentLevelLO3_final=$AttainmentLevelLO3/100; ?>

</body>
</html>