 <?php
/* Database connection settings */
$host = 'localhost';
$user = 'root';
$pass = 'donquixote';
$db = 'lo_calc1';
$conn = new mysqli($host,$user,$pass,$db) or die($mysqli->error);

$host1 = 'localhost';
$user1 = 'root';
$pass1 = 'donquixote';
$db1 = 'assignments';
$conn1 = new mysqli($host1,$user1,$pass1,$db1) or die($mysqli->error);

$host2 = 'localhost';
$user2 = 'root';
$pass2 = 'donquixote';
$db2 = 'others';
$conn2 = new mysqli($host2,$user2,$pass2,$db2) or die($mysqli->error);

$host3= 'localhost';
$user3= 'root';
$pass3= 'donquixote';
$db3= 'extra_co';
$conn3 = new mysqli($host3,$user3,$pass3,$db3) or die($mysqli->error);

$host4= 'localhost';
$user4= 'root';
$pass4= 'donquixote';
$db4= 'co_calc';
$conn4 = new mysqli($host4,$user4,$pass4,$db4) or die($mysqli->error);


?>
