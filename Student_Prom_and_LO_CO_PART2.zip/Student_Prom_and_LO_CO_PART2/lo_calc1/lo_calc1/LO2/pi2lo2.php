<?php
include 'dbConfig.php';
$Assignmentarrraypi2lo2=array();
$MiniProjectarraypi2lo2=array();
$wpi2lo2=array();
$percenl11pi2lo2=array();
$percenl11xpi2lo2=array();
$Attlevelarraypi2lo2=array();
$outoftenpi2lo2=array();
$outoftenxpi2lo2=array();
$totalrowpi2lo2=array();
$tot_final=0;
$totalbottom=0;
$performancelevel=0;
$performancelevelfinalpi2lo2=0;
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>PI2 LO2</title>
</head>
<body>
<table class="table table-bordered">
	<tr>
		<th colspan="2">Experiment Number</th>
		<?php
		for ($i=1; $i <=7; $i++) 
		{ 
		?>	
		<td><?php echo $i; ?></td>
		<?php
		}?>
		
		<td>Total</td>
		</tr>

		<?php
		
		$sql = "SELECT * FROM `LO_PROG_ASGNMT` WHERE lo_No=2";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	<tr><th colspan="2">Weightage</th>
		<?php
		for ($i=1; $i <=7 ; $i++) { 
			?>
			<td><?php $wpi2lo2[$i]=$row['PA_'.$i]; echo $wpi2lo2[$i]; ?></td>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=7 ; $i++) { 
$tot=$tot+$wpi2lo2[$i];
?>

<?php
}
?>

<td><?php echo $tot; ?></td></tr>

<tr>
<th>Roll no</th>
<th>Name</th>
<?php
for ($i=1; $i<=7  ; $i++) 
{
?>
<th></th>
<?php
}
?>
</tr>
<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name,SE5LMINI.Assignment_1,SE5LMINI.Assignment_2,SE5LMINI.Assignment_3,SE5LMINI.Assignment_4,SE5LMINI.Assignment_5,SE5LMINI.Assignment_6,SE5LMINI.Mini_Project FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no INNER JOIN SE5_LO_ASGNMT_MINI_PROJECT AS \n"."SE5LMINI ON SE5LMINI.Roll_No= IA1.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);





	if ($result_rollname->num_rows > 0) 
		{
			$j=1;

		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>
	
<?php
for ($i=1; $i <= 6; $i++) 
{ 
?>

<td>
<?php $Assignmentarrraypi2lo2[$i]=$row_rollname['Assignment_'.$i]; echo $Assignmentarrraypi2lo2[$i];?>
</td>

<?php
}$i=1;
?>

<td><?php $MiniProjectarraypi2lo2[$i]=$row_rollname['Mini_Project']; echo $MiniProjectarraypi2lo2[$i];?></td>
<td><?php $tot_final=($wpi2lo2[$i]*$Assignmentarrraypi2lo2[$i]); $totalrowpi2lo2[$j]=$tot_final/5; echo $totalrowpi2lo2[$j]; ?></td>
<?php
$i++;
?>
<?php
$j++;
}
}
?>
</tr>

<tr><th colspan="2">% of Students getting equal or more than 60%</th>
<?php

$sql="SELECT COUNT(Roll_no) FROM SE5_A";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);


	for ($i=1; $i <=6 ; $i++) 
	{ 
 $sql1="SELECT COUNT(Assignment_$i) FROM SE5_LO_ASGNMT_MINI_PROJECT WHERE Assignment_$i>2";
 $result1=mysqli_query($conn,$sql1);
 $row1=mysqli_fetch_array($result1);

   $sql1x="SELECT COUNT(Mini_Project) FROM SE5_LO_ASGNMT_MINI_PROJECT WHERE Mini_Project>2";
 $result1x=mysqli_query($conn,$sql1x);
 $row1x=mysqli_fetch_array($result1x);


 echo "<td>";
 $var=($row1[0]/$row[0])*100;
 $var1=round($var,2);
 $percenl11pi2lo2[$i]=$var1;
  $varx=($row1x[0]/$row[0])*100;
 $var1x=round($varx,2);
 $percenl11xpi2lo2[$i]=$var1x;
 echo "$percenl11pi2lo2[$i]";
 }
?><td><?php echo $percenl11xpi2lo2[$i-1]; ?></td>
</tr>
<tr>
<th colspan="2">OUT OF 10</th>

<?php
for ($i=1; $i <=6 ; $i++) 
{ 
?>
<td><?php $outoftenpi2lo2[$i]=$wpi2lo2[$i]*$percenl11pi2lo2[$i]/1000; echo $outoftenpi2lo2[$i]; ?></td>
<?php
}
?><td><?php $outoftenxpi2lo2[$i]=$wpi2lo2[$i]*$percenl11xpi2lo2[$i-1]/1000; echo $outoftenxpi2lo2[$i]; ?></td>
</tr>
<tr>
	<th colspan="2">Total</th>
	<td align="center"><?php $totalbottom=array_sum($outoftenpi2lo2)+$outoftenxpi2lo2[$i]; echo $totalbottom;?></td>
</tr>

<tr>
<th colspan="2">Attainment Level</th>
<?php
$at1=1;
$at2=2;
$at3=3;
$Attlevelarraypi2lo2=array();
for ($i=1; $i <=6 ; $i++) 
{ 
if($percenl11pi2lo2[$i]>=70)
	{?>
		<td><?php $Attlevelarraypi2lo2[$i]=$at3; echo $at3; ?></td>
	<?php
	}
	elseif ($percenl11pi2lo2[$i]>=65) 
	{?>
		<td><?php $Attlevelarraypi2lo2[$i]=$at2; echo $at2; ?></td>
	<?php
	}
	else
		{?>
			<td><?php $Attlevelarraypi2lo2[$i]=$at1; echo $at1;?></td>
<?php
	}
}
?>
<?php
if($percenl11xpi2lo2[$i-1]>=70)
	{?>
		<td><?php $Attlevelarrayx[$i]=$at3; echo $at3; ?></td>
	<?php
	}
	elseif ($percenl11pi2lo2[$i-1]>=65) 
	{?>
		<td><?php $Attlevelarrayx[$i]=$at2; echo $at2; ?></td>
	<?php
	}
		elseif($percenl11xpi2lo2[$i]>=60)
		{?>
			<td><?php $Attlevelarrayx[$i]=$at1; echo $at1;?></td>
<?php
	}
	else
		{?>

		<td><?php $Attlevelarrayx[$i]=round($percenl11xpi2lo2[$i]/60,2); echo $Attlevelarrayx[$i];?></td>
	<?php 
}
?>
</tr>


<tr>
<th colspan="2">Attainment Level for Performance Indicator</th>
<?php
for ($i=1; $i <=6 ; $i++) 
	{$performancelevel=$performancelevel+($Attlevelarraypi2lo2[$i]*$wpi2lo2[$i]);
		?>
		
<?php
	}	
?><td><?php $performancelevelfinalpi2lo2=($performancelevel+$Attlevelarrayx[$i])/100;  echo $performancelevelfinalpi2lo2; ?></td>
</tr>
</body>
</html>