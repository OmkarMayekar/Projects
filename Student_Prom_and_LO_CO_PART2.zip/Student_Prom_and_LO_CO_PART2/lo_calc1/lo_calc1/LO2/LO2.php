<?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO2/pi1lo2_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO2/pi2lo2_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO2/pi3lo2_updated.php';
	$percenl11LO2=array();
	$row_value=array();
	$wLO2=array();
	$outoftenLO2=array();
	$LO2ARRAYPI1=array();
	$LO2ARRAYPI2=array();
	$LO3ARRAYPI3=array();
	$outoftenlo2=array();
	$LOPI1ARRAYLO2=array();
	$LO2TOTALROW=array();
	/*$tot_finalarraypi1lo2=array();*/
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO2=0;
	$AttainmentLevelLO2_final=0;
	$n=sizeof($tot_finalarraypi1lo2);
	$n1=sizeof($LO2ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_2</title>
</head>
<body>
<table class="table table-bordered">
	<tr>
		<th colspan="2">Performance Indicator Number</th>
		<?php 
		for ($i=1; $i <=3; $i++) 
		{ 
		?>	
		<td><?php echo $i; ?></td>
		<?php
		}?>
		
		<td>Total</td>
		</tr>

				<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =2";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	<tr><th colspan="2">Weightage</th>
		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<td><?php $wLO2[$i]=$row['lo1pi'.$i]; echo $wLO2[$i]; ?></td>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$wLO2[$i];
?>

<?php
}
?><td><?php echo $tot; ?></td>

</td></tr>

<tr>
<th>Roll no</th>
<th>Name</th></tr>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;	
			$k=0;	
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>

<td>
	<?php $LO2ARRAYPI1[$i]=$tot_finalarraypi1lo2[$j]/5; echo $tot_finalarraypi1lo2[$j]/5; ?>
</td>

<td>
	<?php $LO2ARRAYPI2[$i]=$totalrowpi2lo2[$j]/5; echo $totalrowpi2lo2[$j]/5; ?>
</td>

<td>
	<?php $LO3ARRAYPI3[$i]=$tot_finalarraypi3lo2[$j]/5; echo $tot_finalarraypi3lo2[$j]/5; ?>
</td>

<td>
	<?php $LO2TOTALROW[$k]=$LO2ARRAYPI1[$k]+$LO2ARRAYPI2[$k]+$LO3ARRAYPI3[$k]; echo $LO2TOTALROW[$k]; ?>
</td>

<?php
$i++;
$j++;
$k++;
}
}
?>
</tr>
<tr>
<th colspan="2">% of Students getting equal or more than 60%</th>
<?php
$j=1;
for ($i=0; $i <sizeof($LO2ARRAYPI1) ; $i++) { 
if ($LO2ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count1/sizeof($LO2ARRAYPI1))*100; echo $per1lo1[$j]; $j++;?></td>

<?php
for ($i=0; $i <sizeof($LO2ARRAYPI2) ; $i++) { 
if ($LO2ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count2/sizeof($LO2ARRAYPI2))*100; echo $per1lo1[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($LO3ARRAYPI3) ; $i++) { 
if ($LO3ARRAYPI3[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count3/sizeof($LO3ARRAYPI3))*100; echo $per1lo1[$j]; $j++; ?></td>

</tr>
<tr><th colspan="2">Out Of Ten</th>
<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo2[$i]=($per1lo1[$i]*$wLO2[$i])/1000;
?>
<td><?php echo $outoftenlo2[$i]; ?></td>
<?php
}
?>	
</tr>
<tr>
	<th colspan="2">Total</th>
	<td><?php echo array_sum($outoftenlo2); ?></td>
</tr>

<tr>
	<th colspan="2">Attainment Level from Performance Indicator</th>
	<td><?php $LOPI1ARRAYLO2[1]=$final_performancelevelpi1lo2; echo $LOPI1ARRAYLO2[1]; ?></td>
	<td><?php $LOPI1ARRAYLO2[2]=$performancelevelfinalpi2lo2; echo $LOPI1ARRAYLO2[2]; ?></td>
	<td><?php $LOPI1ARRAYLO2[3]=$totalperformancelevelpi3lo2; echo $LOPI1ARRAYLO2[3]; ?></td>
</tr>

<tr><th colspan="2">Attainment Level for Course Outcome</th>
<?php
for ($i=1; $i <sizeof($LOPI1ARRAYLO2) ; $i++) { 
$AttainmentLevelLO2=(($LOPI1ARRAYLO2[$i]*$wLO2[$i])+$AttainmentLevelLO2);
?>
<?php
}
?>	<td><?php $AttainmentLevelLO2_final=$AttainmentLevelLO2/100; echo $AttainmentLevelLO2_final; ?></td>

</tr>
</table>
</body>
</html>