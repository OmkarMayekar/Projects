<?php 
         include("dbConfig.php");
     $query11 = mysqli_query($conn,"SELECT Unique_CO_Number, SUM(Out_of_10_Marks) AS Out_of_10_MarksCAL FROM overall_course_db GROUP BY Unique_CO_Number");
    if(!$query11)
{
  echo "string";
}

    
 while ($row11=mysqli_fetch_assoc($query11))
        {
         

           $qa=$row11['Unique_CO_Number']; 
           $xy=$row11['Out_of_10_MarksCAL'];
               

      if(isset($_POST['INSERT']))
        {
           $val=round($xy,2);
           $val1=round(($val*0.3),2);
          $sqlx11="INSERT INTO `Final_att`(`Unique_CO_Number`, `Out_of_10_MarksCAL`,`Out_of_3`) VALUES ('$qa',round($xy,2),$val1)";
          $resultab= mysqli_query($conn,$sqlx11);

        }
        elseif(isset($_POST['UPDATE']))
          {

              $sqlav="UPDATE `Final_att` SET `Unique_CO_Number`='$qa',`Out_of_10_MarksCAL`=round($xy,2)";
               $resultabc= mysqli_query($conn,$sqlav);
          }
        }
        



   ?>
