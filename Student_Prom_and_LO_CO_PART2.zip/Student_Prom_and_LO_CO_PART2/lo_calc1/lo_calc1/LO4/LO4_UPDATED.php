<?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO4/pi1lo4_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO4/pi2lo4_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO4/pi3lo4_updated.php';

	$percenl11LO4=array();
	$row_valueLO4=array();
	$avg=array();
	$wLO4=array();
	$outoftenLO4=array();
	$LO4ARRAYPI1=array();
	$LO4ARRAYPI2=array();
	$LO4ARRAYPI2=array();
	$outoftenlo4=array();
	$LOPI1ARRAYLO4=array();
	$LO4TOTALROW=array();
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO4=0;
	$AttainmentLevelLO4_final=0;
	$n=sizeof($tot_finalarraypi1lo4);
	$n1=sizeof($LO4ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_4</title>
</head>
<body>

	

				<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =4";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	
		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<?php $wLO4[$i]=$row['lo1pi'.$i];  ?>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$wLO4[$i];
?>

<?php
}
?>


<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;	
			$k=0;	
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>


	<?php $LO4ARRAYPI1[$i]=$tot_finalarraypi1lo4[$j]/5;  ?>



	<?php $LO4ARRAYPI2[$i]=$totalrowpi2lo4[$j]/5;  ?>



	<?php $LO4ARRAYPI3[$i]=$tot_finalarraypi3lo4[$j]/5;  ?>



	<?php $LO4TOTALROW[$k]=$LO4ARRAYPI1[$k]+$LO4ARRAYPI2[$k]+$LO4ARRAYPI3[$k]; ?>


<?php
$i++;
$j++;
$k++;
}
}
?>

<?php
$j=1;
for ($i=0; $i <sizeof($LO4ARRAYPI1) ; $i++) { 
if ($LO4ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count1/sizeof($LO4ARRAYPI1))*100;  $j++;?>

<?php
for ($i=0; $i <sizeof($LO4ARRAYPI2) ; $i++) { 
if ($LO4ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count2/sizeof($LO4ARRAYPI2))*100;  $j++; ?>

<?php
for ($i=0; $i <sizeof($LO4ARRAYPI2) ; $i++) { 
if ($LO4ARRAYPI2[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count3/sizeof($LO4ARRAYPI2))*100;  $j++; ?>


<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo4[$i]=($per1lo1[$i]*$wLO4[$i])/1000;
?>

<?php
}
?>	


	
<?php $LOPI1ARRAYLO4[1]=$final_performancelevelpi1lo4; ?>
<?php $LOPI1ARRAYLO4[2]=$performancelevelfinalpi2lo4;  ?>
<?php $LOPI1ARRAYLO4[3]=$totalperformancelevelpi3lo4;  ?>



<?php
for ($i=1; $i <sizeof($LOPI1ARRAYLO4) ; $i++) { 
$AttainmentLevelLO4=(($LOPI1ARRAYLO4[$i]*$wLO4[$i])+$AttainmentLevelLO4);
?>
<?php
}
?>	<?php $AttainmentLevelLO4_final=$AttainmentLevelLO4/100;  ?>


</body>
</html>