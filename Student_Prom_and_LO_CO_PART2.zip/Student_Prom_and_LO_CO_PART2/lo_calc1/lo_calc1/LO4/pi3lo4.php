<?php
include 'dbConfig.php';
$wprespi3lo4=array();
$wsemipi3lo4=array();
$wcasepi3lo4=array();
$row_value=array();
$row_valuepres=array();
$row_valuesemi=array();
$row_valueclass=array();
$row_valuecase=array();
$percenl11pi3lo4=array();
$percenl11Classpi3lo4=array();
$percenl11Casepi3lo4=array();
$percenl11Prespi3lo4=array();
$percenl11Prespi3lo4=array();
$outoftenCasepi3lo4=array();
$outoftenPrespi3lo4=array();
$AttlevelarraySemipi3lo4=array();
$AttlevelarrayClasspi3lo4=array();
$AttlevelarrayCasepi3lo4=array();
$AttlevelarrayPrespi3lo4=array();
$tot_finalarraypi3lo4=array();
$tot=0;
$w=array(0,0,0,0,0);
$performancelevel1=0;
$performancelevel2=0;
$performancelevel3=0;
$performancelevel4=0;
$totalperformancelevelpi3lo4=0;
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>PI3 LO4</title>
</head>
<body>
<table class="table table-bordered">
	<tr>
		<th colspan="2">Performance Indicator Name</th>
		<th>Seminar_1</th>
	<th>Seminar_2</th>
	<th>Class_Test_1</th>
	<th>Class_Test_2</th>
	<th>Case_Study_1</th>
	<th>Case_Study_2</th>
	<th>Presentation_1</th>
	<th>Presentation_2</th>
		<th>Total</th>
	</tr>
	<tr><th colspan="2">Weightage</th>
	<td><?php echo $w[1]; ?></td>
	<td><?php echo $w[2]; ?></td>
	<td><?php echo $w[3]; ?></td>
	<td><?php echo $w[4]; ?></td>
		<?php
		$sql = "SELECT CS_1,CS_2,P1,P2 FROM `SE5_LO_ASGNMT_MINI_PROJECT` WHERE Lo_No=4";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while($row = $result->fetch_assoc()) 
			{
			?>
		<!-- ///////////////////////////////////////////////////////////////////////////// -->
		<?php
		for ($i=1; $i <=2 ; $i++) { 
			?>
		
	<td><?php $wcasepi3lo4[$i]=$row['CS_'.$i]; echo $wcasepi3lo4[$i]; ?></td>
		<?php
		}
		?>
		<!-- ///////////////////////////////////////////////////////////////////////////// -->
		<?php
		for ($i=1; $i <=2 ; $i++) { 
			?>
		
	<td><?php $wprespi3lo4[$i]=$row['P'.$i]; echo $wprespi3lo4[$i]; ?></td>
		<?php
		}
		?>


		<?php 
		for ($i=1; $i <=2 ; $i++) { 
		$tot=$tot+$wcasepi3lo4[$i]+$wprespi3lo4[$i]+$w[$i];
		?>
		<?php
		}
		?>
		
	<td><?php echo $tot; ?></td></tr>

		<?php
		}
		}
		?>



	<tr>
	<th>Roll no</th>
	<th>Name</th>
	</tr>

		<?php
		$sql_rollname = "SELECT COSNC.Roll_no, COSNC.Name,COSNC.Seminar_1,COSNC.Seminar_2,COSNC.Class_Test_1,COSNC.Class_Test_2,LOPNC.Case_Study_1,LOPNC.Case_Study_2,LOPNC.Presentation_1,LOPNC.Presentation_2 FROM CO_SE5_SEMINAR_N_CASE AS COSNC INNER JOIN LO_SE5_PRES_N_CASE AS LOPNC ON COSNC.Roll_no=LOPNC.Roll_no";
    	$result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$x=1;
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
		?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>

		<?php
		for ($i=1; $i <= 2; $i++) 
		{ 
		?>
<td>
		<?php  
		$row_valuesemi[$i] = $row_rollname['Seminar_'.$i]; echo $row_valuesemi[$i]; ?></td>
		<?php
		}
		?>

		<?php
		for ($i=1; $i <= 2; $i++) 
		{ 
		?>

<td>
		<?php  
		$row_valueclass[$i] = $row_rollname['Class_Test_'.$i]; echo $row_valueclass[$i]; ?></td>
		<?php
		}
		?>

		<?php
		for ($i=1; $i <= 2; $i++) 
		{ 
		?>

<td>
		<?php  
		$row_valuecase[$i] = $row_rollname['Case_Study_'.$i]; echo $row_valuecase[$i]; ?></td>

		<?php
		}
		?>

		<?php
		for ($i=1; $i <= 2; $i++) 
		{ 
		?>


<td>
		<?php  
		$row_valuepres[$i] = $row_rollname['Presentation_'.$i]; echo $row_valuepres[$i]; ?></td>
		<?php
		}
		?>

		<?php 
		$tot_final=0;
		$i=1;
		$j=1;
		$k=1;
		$l=1;

		?>

		<td>
		<?php $tot_final = $tot_final+(($row_valuesemi[$i]*$w[1])+($row_valuesemi[$i+1]*$w[2])+($row_valueclass[$j]*$w[3])+($row_valueclass[$j+1]*$w[4])+($row_valuecase[$k]*$wcasepi3lo4[$k])+($row_valuecase[$k+1]*$wcasepi3lo4[$k+1])+($row_valuepres[$l]*$wprespi3lo4[$l])+($row_valuepres[$l+1]*$wprespi3lo4[$l+1])); $tot_finalarraypi3lo4[$x]=$tot_final/5; echo $tot_finalarraypi3lo4[$x];?></td>
		

		<?php
		$i++;
		$j++;
		$k++;
		$l++;
		$x++;		
		}
		}
		?>



	<tr><th colspan="2">% of Students getting equal or more than 60%</th>

		<?php

		$sqlrolllast="SELECT COUNT(Roll_no) FROM CO_SE5_SEMINAR_N_CASE";
		$resultrolllast=mysqli_query($conn,$sqlrolllast);
		$row=mysqli_fetch_array($resultrolllast);


			for ($i=1; $i <=2 ; $i++) 
			{ 
		 $sql1="SELECT COUNT(Seminar_$i) FROM CO_SE5_SEMINAR_N_CASE WHERE Seminar_$i>2";
		 $result1=mysqli_query($conn,$sql1);
		 $row1=mysqli_fetch_array($result1);
		 echo "<td>";
		 $var=($row1[0]/$row[0])*100;
		 $var1=round($var,2);
		 $percenl11pi3lo4[$i]=$var1;
		 echo "$percenl11pi3lo4[$i]";
		 echo "</td>";
			}

			for ($i=1; $i <=2 ; $i++) 
			{ 
		 $sql1="SELECT COUNT(Class_Test_$i) FROM CO_SE5_SEMINAR_N_CASE WHERE Class_Test_$i>2";
		 $result1=mysqli_query($conn,$sql1);
		 $row1=mysqli_fetch_array($result1);
		 echo "<td>";
		 $var=($row1[0]/$row[0])*100;
		 $var1=round($var,2);
		 $percenl11Classpi3lo4[$i]=$var1;
		 echo "$percenl11Classpi3lo4[$i]";
		 echo "</td>";
			}

			for ($i=1; $i <=2 ; $i++) 
			{ 
		 $sql1="SELECT COUNT(Case_Study_$i) FROM CO_SE5_SEMINAR_N_CASE WHERE Case_Study_$i>2";
		 $result1=mysqli_query($conn,$sql1);
		 $row1=mysqli_fetch_array($result1);
		 echo "<td>";
		 $var=($row1[0]/$row[0])*100;
		 $var1=round($var,2);
		 $percenl11Casepi3lo4[$i]=$var1;
		 echo "$percenl11Casepi3lo4[$i]";
		 echo "</td>";
			}

			for ($i=1; $i <=2 ; $i++) 
			{ 
		 $sql1="SELECT COUNT(Presentation_$i) FROM CO_SE5_SEMINAR_N_CASE WHERE Presentation_$i>2";
		 $result1=mysqli_query($conn,$sql1);
		 $row1=mysqli_fetch_array($result1);
		 echo "<td>";
		 $var=($row1[0]/$row[0])*100;
		 $var1=round($var,2);
		 $percenl11Prespi3lo4[$i]=$var1;
		 echo "$percenl11Prespi3lo4[$i]";
		 echo "</td>";
			}
		?>
</tr>

<tr>
<th colspan="2">OUT OF 10</th>
<?php
for ($i=1; $i <=2 ; $i++) 
{ 
?>
<td><?php $outoften[$i]=$w[$i]*$percenl11pi3lo4[$i]/1000; echo $outoften[$i]; ?></td>
<?php
}
?>

<?php
for ($i=1; $i <=2 ; $i++) 
{ 
?>
<td><?php $percenl11Prespi3lo4[$i]=$w[$i]*$percenl11Classpi3lo4[$i]/1000; echo $percenl11Prespi3lo4[$i]; ?></td>
<?php
}
?>

<?php
for ($i=1; $i <=2 ; $i++) 
{ 
?>
<td><?php $outoftenCasepi3lo4[$i]=$wcasepi3lo4[$i]*$percenl11Casepi3lo4[$i]/1000; echo $outoftenCasepi3lo4[$i]; ?></td>
<?php
}
?>

<?php
for ($i=1; $i <=2 ; $i++) 
{ 
?>
<td><?php $outoftenPrespi3lo4[$i]=$wprespi3lo4[$i]*$percenl11Prespi3lo4[$i]/1000; echo $outoftenPrespi3lo4[$i]; ?></td>
<?php
}
?>
</tr>

<tr>
<th colspan="2">Attainment Level</th>
<?php
$at0=0;
$at1=1;
$at2=2;
$at3=3;
for ($i=1; $i <=2 ; $i++) 
{ 
if($percenl11pi3lo4[$i]>=70)
	{?>
		<td><?php $AttlevelarraySemipi3lo4[$i]=$at3; echo $at3; ?></td>
	<?php
	}
	elseif ($percenl11pi3lo4[$i]>=65) 
	{?>
		<td><?php $AttlevelarraySemipi3lo4[$i]=$at2; echo $at2; ?></td>
	<?php
	}
	elseif ($percenl11pi3lo4[$i]>=60) 
	{?>
		<td><?php $AttlevelarraySemipi3lo4[$i]=$at2; echo $at1; ?></td>
	<?php
	}
	else
		{?>
			<td><?php $AttlevelarraySemipi3lo4[$i]=$at1; echo $at0;?></td>
<?php
	}
}
?>
<?php
for ($i=1; $i <=2 ; $i++) 
{ 
if($percenl11Classpi3lo4[$i]>=70)
	{?>
		<td><?php $AttlevelarrayClasspi3lo4[$i]=$at3; echo $at3; ?></td>
	<?php
	}
	elseif ($percenl11Classpi3lo4[$i]>=65) 
	{?>
		<td><?php $AttlevelarrayClasspi3lo4[$i]=$at2; echo $at2; ?></td>
	<?php
	}
	elseif ($percenl11Classpi3lo4[$i]>=60) 
	{?>
		<td><?php $AttlevelarrayClasspi3lo4[$i]=$at2; echo $at1; ?></td>
	<?php
	}
	else
		{?>
			<td><?php $AttlevelarrayClasspi3lo4[$i]=$at1; echo $at0;?></td>
<?php
	}
}
?>

<?php
for ($i=1; $i <=2 ; $i++) 
{ 
if($percenl11Casepi3lo4[$i]>=70)
	{?>
		<td><?php $AttlevelarrayCasepi3lo4[$i]=$at3; echo $at3; ?></td>
	<?php
	}
	elseif ($percenl11Casepi3lo4[$i]>=65) 
	{?>
		<td><?php $AttlevelarrayCasepi3lo4[$i]=$at2; echo $at2; ?></td>
	<?php
	}
	elseif ($percenl11Casepi3lo4[$i]>=60) 
	{?>
		<td><?php $AttlevelarrayCasepi3lo4[$i]=$at2; echo $at1; ?></td>
	<?php
	}
	else
		{?>
			<td><?php $AttlevelarrayCasepi3lo4[$i]=$at1; echo $at0;?></td>
<?php
	}
}
?>

<?php
for ($i=1; $i <=2 ; $i++) 
{ 
if($percenl11Prespi3lo4[$i]>=70)
	{?>
		<td><?php $AttlevelarrayPrespi3lo4[$i]=$at3; echo $at3; ?></td>
	<?php
	}
	elseif ($percenl11Prespi3lo4[$i]>=65) 
	{?>
		<td><?php $AttlevelarrayPrespi3lo4[$i]=$at2; echo $at2; ?></td>
	<?php
	}
	elseif ($percenl11Prespi3lo4[$i]>=60) 
	{?>
		<td><?php $AttlevelarrayPrespi3lo4[$i]=$at2; echo $at1; ?></td>
	<?php
	}
		elseif($percenl11Prespi3lo4[$i]>=60)
		{?>
			<td><?php $AttlevelarrayPrespi3lo4[$i]=$at1; echo $at1;?></td>
<?php
	}
	else
		{?>

		<td><?php $AttlevelarrayPrespi3lo4[$i]=round($percenl11Prespi3lo4[$i]/60,2); echo $AttlevelarrayPrespi3lo4[$i];?></td>
	<?php }
}
?>
</tr>

<tr>
<th colspan="2">Attainment Level for Performance Indicator</th>
	<?php
	for ($i=1; $i <=2 ; $i++) {
	$performancelevel1=$performancelevel1+($AttlevelarraySemipi3lo4[$i]*$w[$i]);
	?>
		
	<?php
	}
	?>

		<?php
	for ($i=1; $i <=2 ; $i++) {
	$performancelevel2=$performancelevel2+($AttlevelarrayClasspi3lo4[$i]*$w[$i]);
	?>
		
	<?php
	}
	?>

		<?php
	for ($i=1; $i <=2 ; $i++) {
	$performancelevel3=$performancelevel3+($AttlevelarrayCasepi3lo4[$i]*$wcasepi3lo4[$i]);
	?>
		
	<?php
	}
	?>

		<?php
	for ($i=1; $i <=2 ; $i++) {
	$performancelevel4=$performancelevel4+($AttlevelarrayPrespi3lo4[$i]*$wprespi3lo4[$i]);
	?>
		
	<?php
	}
	?>

<?php $totalperformancelevelpi3lo4=($performancelevel1+$performancelevel2+$performancelevel3+$performancelevel4)/100; ?>
<td><?php echo $totalperformancelevelpi3lo4; ?></td>
</tr>

</table>
</body>	
</html>
		