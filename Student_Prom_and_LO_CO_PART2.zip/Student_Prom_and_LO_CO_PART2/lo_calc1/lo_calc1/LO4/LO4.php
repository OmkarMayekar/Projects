<?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO4/pi1lo4_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO4/pi2lo4_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO4/pi3lo4_updated.php';

	$percenl11LO4=array();
	$row_valueLO4=array();
	$avg=array();
	$wLO4=array();
	$outoftenLO4=array();
	$LO4ARRAYPI1=array();
	$LO4ARRAYPI2=array();
	$LO4ARRAYPI2=array();
	$outoftenlo4=array();
	$LOPI1ARRAYLO4=array();
	$LO4TOTALROW=array();
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO4=0;
	$AttainmentLevelLO4_final=0;
	$n=sizeof($tot_finalarraypi1lo4);
	$n1=sizeof($LO4ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_4</title>
</head>
<body>
<table class="table table-bordered">
	<tr>
		<th colspan="2">Performance Indicator Number</th>
		<?php 
		for ($i=1; $i <=3; $i++) 
		{ 
		?>	
		<td><?php echo $i; ?></td>
		<?php
		}?>
		
		<td>Total</td>
		</tr>

				<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =4";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	<tr><th colspan="2">Weightage</th>
		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<td><?php $wLO4[$i]=$row['lo1pi'.$i]; echo $wLO4[$i]; ?></td>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$wLO4[$i];
?>

<?php
}
?><td><?php echo $tot; ?></td>

</td></tr>

<tr>
<th>Roll no</th>
<th>Name</th></tr>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;	
			$k=0;	
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>

<td>
	<?php $LO4ARRAYPI1[$i]=$tot_finalarraypi1lo4[$j]/5; echo $tot_finalarraypi1lo4[$j]/5; ?>
</td>

<td>
	<?php $LO4ARRAYPI2[$i]=$totalrowpi2lo4[$j]/5; echo $totalrowpi2lo4[$j]/5; ?>
</td>

<td>
	<?php $LO4ARRAYPI3[$i]=$tot_finalarraypi3lo4[$j]/5; echo $tot_finalarraypi3lo4[$j]/5; ?>
</td>

<td>
	<?php $LO4TOTALROW[$k]=$LO4ARRAYPI1[$k]+$LO4ARRAYPI2[$k]+$LO4ARRAYPI3[$k]; echo $LO4TOTALROW[$k]; ?>
</td>

<?php
$i++;
$j++;
$k++;
}
}
?>
</tr>
<tr>
<th colspan="2">% of Students getting equal or more than 60%</th>
<?php
$j=1;
for ($i=0; $i <sizeof($LO4ARRAYPI1) ; $i++) { 
if ($LO4ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count1/sizeof($LO4ARRAYPI1))*100; echo $per1lo1[$j]; $j++;?></td>

<?php
for ($i=0; $i <sizeof($LO4ARRAYPI2) ; $i++) { 
if ($LO4ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count2/sizeof($LO4ARRAYPI2))*100; echo $per1lo1[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($LO4ARRAYPI2) ; $i++) { 
if ($LO4ARRAYPI2[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count3/sizeof($LO4ARRAYPI2))*100; echo $per1lo1[$j]; $j++; ?></td>

</tr>
<tr><th colspan="2">Out Of Ten</th>
<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo4[$i]=($per1lo1[$i]*$wLO4[$i])/1000;
?>
<td><?php echo $outoftenlo4[$i]; ?></td>
<?php
}
?>	
</tr>
<tr>
	<th colspan="2">Total</th>
	<td><?php echo array_sum($outoftenlo4); ?></td>
</tr>

<tr>
	<th colspan="2">Attainment Level from Performance Indicator</th>
	<td><?php $LOPI1ARRAYLO4[1]=$final_performancelevelpi1lo4; echo $LOPI1ARRAYLO4[1]; ?></td>
	<td><?php $LOPI1ARRAYLO4[2]=$performancelevelfinalpi2lo4; echo $LOPI1ARRAYLO4[2]; ?></td>
	<td><?php $LOPI1ARRAYLO4[3]=$totalperformancelevelpi3lo4; echo $LOPI1ARRAYLO4[3]; ?></td>
</tr>

<tr><th colspan="2">Attainment Level for Course Outcome</th>
<?php
for ($i=1; $i <sizeof($LOPI1ARRAYLO4) ; $i++) { 
$AttainmentLevelLO4=(($LOPI1ARRAYLO4[$i]*$wLO4[$i])+$AttainmentLevelLO4);
?>
<?php
}
?>	<td><?php $AttainmentLevelLO4_final=$AttainmentLevelLO4/100; echo $AttainmentLevelLO4_final; ?></td>

</tr>
</table>
</body>
</html>