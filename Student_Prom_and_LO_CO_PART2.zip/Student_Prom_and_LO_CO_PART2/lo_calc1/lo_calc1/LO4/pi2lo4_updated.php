<?php
include 'dbConfig.php';
$Assignmentarrraypi2lo4=array();
$MiniProjectarraypi2lo4=array();
$wpi2lo1=array();
$percenl11pi2lo4=array();
$percenl11xpi2lo4=array();
$Attlevelarraypi2lo4=array();
$outoftenpi2lo4=array();
$outoftenxpi2lo4=array();
$totalrowpi2lo4=array();
$tot_final=0;
$totalbottom=0;
$performancelevel=0;
$performancelevelfinalpi2lo4=0;
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>PI2 LO4</title>
</head>
<body>


		<?php
		
		$sql = "SELECT * FROM `LO_PROG_ASGNMT` WHERE lo_No=4";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	
		<?php
		for ($i=1; $i <=7 ; $i++) { 
			?>
             <?php $wpi2lo1[$i]=$row['PA_'.$i];  ?>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=7 ; $i++) { 
$tot=$tot+$wpi2lo1[$i];
?>

<?php
}
?>




<?php
for ($i=1; $i<=7  ; $i++) 
{
?>

<?php
}
?>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name,SE5LMINI.Assignment_1,SE5LMINI.Assignment_2,SE5LMINI.Assignment_3,SE5LMINI.Assignment_4,SE5LMINI.Assignment_5,SE5LMINI.Assignment_6,SE5LMINI.Mini_Project FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no INNER JOIN SE5_LO_ASGNMT_MINI_PROJECT AS \n"."SE5LMINI ON SE5LMINI.Roll_No= IA1.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);





	if ($result_rollname->num_rows > 0) 
		{
			$j=1;

		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>

	
<?php
for ($i=1; $i <= 6; $i++) 
{ 
?>


<?php $Assignmentarrraypi2lo4[$i]=$row_rollname['Assignment_'.$i]; ?>


<?php
}$i=1;
?>

<?php $MiniProjectarraypi2lo4[$i]=$row_rollname['Mini_Project']; ?>
<?php $tot_final=($wpi2lo1[$i]*$Assignmentarrraypi2lo4[$i]); $totalrowpi2lo4[$j]=$tot_final/5;  ?>
<?php
$i++;
?>
<?php
$j++;
}
}
?>

<?php

$sql="SELECT COUNT(Roll_no) FROM SE5_A";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);


	for ($i=1; $i <=6 ; $i++) 
	{ 
 $sql1="SELECT COUNT(Assignment_$i) FROM SE5_LO_ASGNMT_MINI_PROJECT WHERE Assignment_$i>2";
 $result1=mysqli_query($conn,$sql1);
 $row1=mysqli_fetch_array($result1);

   $sql1x="SELECT COUNT(Mini_Project) FROM SE5_LO_ASGNMT_MINI_PROJECT WHERE Mini_Project>2";
 $result1x=mysqli_query($conn,$sql1x);
 $row1x=mysqli_fetch_array($result1x);


 
 $var=($row1[0]/$row[0])*100;
 $var1=round($var,2);
 $percenl11pi2lo4[$i]=$var1;
  $varx=($row1x[0]/$row[0])*100;
 $var1x=round($varx,2);
 $percenl11xpi2lo4[$i]=$var1x;
 
 }
?>

<?php
for ($i=1; $i <=6 ; $i++) 
{ 
?>
<?php $outoftenpi2lo4[$i]=$wpi2lo1[$i]*$percenl11pi2lo4[$i]/1000;  ?>
<?php
}
?><?php $outoftenxpi2lo4[$i]=$wpi2lo1[$i]*$percenl11xpi2lo4[$i-1]/1000;  ?>
	<?php $totalbottom=array_sum($outoftenpi2lo4)+$outoftenxpi2lo4[$i]; ?>

<?php
$at1=1;
$at2=2;
$at3=3;
$Attlevelarraypi2lo4=array();
for ($i=1; $i <=6 ; $i++) 
{ 
if($percenl11pi2lo4[$i]>=70)
	{?>
		<?php $Attlevelarraypi2lo4[$i]=$at3;  ?>
	<?php
	}
	elseif ($percenl11pi2lo4[$i]>=65) 
	{?>
		<?php $Attlevelarraypi2lo4[$i]=$at2;  ?>
	<?php
	}
	else
		{?>
			<?php $Attlevelarraypi2lo4[$i]=$at1; ?>
<?php
	}
}
?>
<?php
if($percenl11xpi2lo4[$i-1]>=70)
	{?>
		<?php $Attlevelarrayx[$i]=$at3;  ?>
	<?php
	}
	elseif ($percenl11pi2lo4[$i-1]>=65) 
	{?>
		<?php $Attlevelarrayx[$i]=$at2; ?>
	<?php
	}
	else
		{?>
			<?php $Attlevelarrayx[$i]=$at1; ?>
<?php
	}?>

<?php
for ($i=1; $i <=6 ; $i++) 
	{$performancelevel=$performancelevel+($Attlevelarraypi2lo4[$i]*$wpi2lo1[$i]);
		?>
		
<?php
	}	
?><?php $performancelevelfinalpi2lo4=($performancelevel+$Attlevelarrayx[$i])/100;   ?>

</body>
</html>