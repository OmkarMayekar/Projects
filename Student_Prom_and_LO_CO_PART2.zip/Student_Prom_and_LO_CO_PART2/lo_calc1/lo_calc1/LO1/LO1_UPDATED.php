<?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO1/pi1lo1_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO1/pi2lo1_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO1/pi3lo1_updated.php';
	$percenl11=array();
	$row_value=array();
	$avg=array();
	$w=array();
	$outoften=array();
	$LO1ARRAYPI1=array();
	$LO1ARRAYPI2=array();
	$LO1ARRAYPI3=array();
	$outoftenlo1=array();
	$LOPI1ARRAY=array();
	$LO1TOTALROW=array();
/*	$tot_finalarraypi1lo1=array();*/
/*	$totalrowpi2lo1=array();*/
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO1=0;
	$AttainmentLevelLO1_final=0;
	$n=sizeof($tot_finalarraypi1lo1);
	$n1=sizeof($LO1ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_1</title>
</head>
<body>



				<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =1";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	
		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<?php $w[$i]=$row['lo1pi'.$i]; ?>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$w[$i];
?>

<?php
}
?>


<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;	
			$k=0;	
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>



	<?php $LO1ARRAYPI1[$i]=$tot_finalarraypi1lo1[$j]/5; ?>



	<?php $LO1ARRAYPI2[$i]=$totalrowpi2lo1[$j]/5; ?>



	<?php $LO1ARRAYPI3[$i]=$tot_finalarraypi3lo1[$j]/5;  ?>



	<?php $LO1TOTALROW[$k]=$LO1ARRAYPI1[$k]+$LO1ARRAYPI2[$k]+$LO1ARRAYPI3[$k];  ?>


<?php
$i++;
$j++;
$k++;
}
}
?>


<?php
$j=1;
for ($i=0; $i <sizeof($LO1ARRAYPI1) ; $i++) { 
if ($LO1ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count1/sizeof($LO1ARRAYPI1))*100;  $j++;?>

<?php
for ($i=0; $i <sizeof($LO1ARRAYPI2) ; $i++) { 
if ($LO1ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count2/sizeof($LO1ARRAYPI2))*100;  $j++; ?>

<?php
for ($i=0; $i <sizeof($LO1ARRAYPI3) ; $i++) { 
if ($LO1ARRAYPI3[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count3/sizeof($LO1ARRAYPI3))*100;  $j++; ?>


<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo1[$i]=($per1lo1[$i]*$w[$i])/1000;
?>

<?php
}
?>	



	<?php $LOPI1ARRAY[1]=$final_performancelevelpi1lo1;  ?>
	<?php $LOPI1ARRAY[2]=$performancelevelfinalpi2lo1;  ?>
	<?php $LOPI1ARRAY[3]=$totalperformancelevelpi3lo1;  ?>

<?php
for ($i=1; $i <sizeof($LOPI1ARRAY) ; $i++) { 
$AttainmentLevelLO1=(($LOPI1ARRAY[$i]*$w[$i])+$AttainmentLevelLO1);
?>
<?php
}
?>	<?php $AttainmentLevelLO1_final=$AttainmentLevelLO1/100; ?>

</body>
</html>