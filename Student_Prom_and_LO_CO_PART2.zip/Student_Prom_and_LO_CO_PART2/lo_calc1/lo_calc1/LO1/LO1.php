 <?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO1/pi1lo1_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO1/pi2lo1_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO1/pi3lo1_updated.php';
	$percenl11=array();
	$row_value=array();
	$avg=array();
	$w=array();
	$outoften=array();
	$LO1ARRAYPI1=array();
	$LO1ARRAYPI2=array();
	$LO1ARRAYPI3=array();
	$outoftenlo1=array();
	$LOPI1ARRAY=array();
	$LO1TOTALROW=array();
/*	$tot_finalarraypi1lo1=array();*/
/*	$totalrowpi2lo1=array();*/
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO1=0;
	$AttainmentLevelLO1_final=0;
	$n=sizeof($tot_finalarraypi1lo1);
	$n1=sizeof($LO1ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_1</title>
</head>
<body>
<table class="table table-bordered">
	<tr>
		<th colspan="2">Performance Indicator Number</th>
		<?php 
		for ($i=1; $i <=3; $i++) 
		{ 
		?>	
		<td><?php echo $i; ?></td>
		<?php
		}?>
		
		<td>Total</td>
		</tr>

				<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =1";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	<tr><th colspan="2">Weightage</th>
		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<td><?php $w[$i]=$row['lo1pi'.$i]; echo $w[$i]; ?></td>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$w[$i];
?>

<?php
}
?><td><?php echo $tot; ?></td>

</td></tr>

<tr>
<th>Roll no</th>
<th>Name</th></tr>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;	
			$k=0;	
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>

<td>
	<?php $LO1ARRAYPI1[$i]=$tot_finalarraypi1lo1[$j]/5; echo $LO1ARRAYPI1[$i]; ?>
</td>

<td>
	<?php $LO1ARRAYPI2[$i]=$totalrowpi2lo1[$j]/5; echo $LO1ARRAYPI2[$i]; ?>
</td>

<td>
	<?php $LO1ARRAYPI3[$i]=$tot_finalarraypi3lo1[$j]/5; echo $LO1ARRAYPI3[$i]; ?>
</td>

<td>
	<?php $LO1TOTALROW[$k]=$LO1ARRAYPI1[$k]+$LO1ARRAYPI2[$k]+$LO1ARRAYPI3[$k]; echo $LO1TOTALROW[$k]; ?>
</td>

<?php
$i++;
$j++;
$k++;
}
}
?>
</tr>
<tr>
<th colspan="2">% of Students getting equal or more than 60%</th>
<?php
$j=1;
for ($i=0; $i <sizeof($LO1ARRAYPI1) ; $i++) { 
if ($LO1ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count1/sizeof($LO1ARRAYPI1))*100; echo $per1lo1[$j]; $j++;?></td>

<?php
for ($i=0; $i <sizeof($LO1ARRAYPI2) ; $i++) { 
if ($LO1ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count2/sizeof($LO1ARRAYPI2))*100; echo $per1lo1[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($LO1ARRAYPI3) ; $i++) { 
if ($LO1ARRAYPI3[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1[$j]=($count3/sizeof($LO1ARRAYPI3))*100; echo $per1lo1[$j]; $j++; ?></td>

</tr>
<tr><th colspan="2">Out Of Ten</th>
<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo1[$i]=($per1lo1[$i]*$w[$i])/1000;
?>
<td><?php echo $outoftenlo1[$i]; ?></td>
<?php
}
?>	
</tr>
<tr>
	<th colspan="2">Total</th>
	<td><?php echo array_sum($outoftenlo1); ?></td>
</tr>

<tr>
	<th colspan="2">Attainment Level from Performance Indicator</th>
	<td><?php $LOPI1ARRAY[1]=$final_performancelevelpi1lo1; echo $LOPI1ARRAY[1]; ?></td>
	<td><?php $LOPI1ARRAY[2]=$performancelevelfinalpi2lo1; echo $LOPI1ARRAY[2]; ?></td>
	<td><?php $LOPI1ARRAY[3]=$totalperformancelevelpi3lo1; echo $LOPI1ARRAY[3]; ?></td>
</tr>

<tr><th colspan="2">Attainment Level for Course Outcome</th>
<?php
for ($i=1; $i <sizeof($LOPI1ARRAY) ; $i++) { 
$AttainmentLevelLO1=(($LOPI1ARRAY[$i]*$w[$i])+$AttainmentLevelLO1);
?>
<?php
}
?>	<td><?php $AttainmentLevelLO1_final=$AttainmentLevelLO1/100; echo $AttainmentLevelLO1_final; ?></td>

</tr>
</table>
</body>
</html>