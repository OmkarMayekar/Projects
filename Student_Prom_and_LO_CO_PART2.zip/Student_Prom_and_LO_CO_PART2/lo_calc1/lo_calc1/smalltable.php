  <html><body>
  <form action="smalltableback.php" method="post"><table>
    <?php 
   include("dbConfig.php");
     $query11 = mysqli_query($conn,"SELECT Unique_CO_Number, SUM(Out_of_10_Marks) AS Out_of_10_MarksCAL FROM overall_course_db GROUP BY Unique_CO_Number");
    if(!$query11)
{
  echo "string";
}

  
                  
             echo "<table border='1' class='table table-bordered table-striped table-highlight'>";
             echo "<tr><th>Unique_CO_Number</th>
             <th>Out_of_10_Marks</th></tr>";
 while ($row11=mysqli_fetch_assoc($query11))
        {
         ?>

          <tr><td> <?php echo $row11['Unique_CO_Number'] ?></td>
            <td> <?php $xy=$row11['Out_of_10_MarksCAL']; echo round($xy,2); ?></td></tr>
               
      <?php
          }
      ?>
 
   
 </table>
 <input type="submit" value="INSERT" name="INSERT">
   <input type="submit" value="UPDATE" name="UPDATE">
   </form></body></html>