<?php
	include 'dbConfig.php';
	$percenl11pi1lo6=array();
	$row_value=array();
	$wpi1lo6=array();
	$outoftenpi1lo6=array();
	$tot_finalarraypi1lo6=array();
	$Attlevelarraypi1lo6=array();
	$tot_final=0;
	$count=0;
	$totalbottompi1lo6=0;
	$performancelevel=0;
	$final_performancelevelpi1lo6=0;	
	/*session_start();*/
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>PI_1_LO_1</title>
</head>
<body>

		<?php
		
		$sql = "SELECT * FROM `LO_EXP_MAPPING` WHERE lo_No=6";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>
	
		<?php
		for ($i=1; $i <=25 ; $i++) { 
			?>
			<?php $wpi1lo6[$i]=$row['EXP_No_'.$i];  ?>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=25 ; $i++) { 
$tot=$tot+$wpi1lo6[$i];
?>

<?php
}
?>







<?php
for ($i=1; $i<=25  ; $i++) 
{
?>

<?php
}
?>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,se5a.exp1,se5a.exp2,se5a.exp3,se5a.exp4,se5a.exp5,se5a.exp6,se5a.exp7,se5a.exp8,se5a.exp9,se5a.exp10,se5a.exp11,se5a.exp12,se5a.exp13,se5a.exp14,se5a.exp15,se5a.exp16,se5a.exp17,\n"

    . "se5a.exp18,se5a.exp19,se5a.exp20,se5a.exp21,se5a.exp22,se5a.exp23,se5a.exp24,se5a.exp25,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$j=1;
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>


<?php
for ($i=1; $i <= 25; $i++) 
{ 
?>

<?php  
$row_value[$i] = $row_rollname['exp'.$i];?>

<?php
}
?>

<?php $tot_final=(($wpi1lo6[$j]*$row_value[$j])+$tot_final)/5; $tot_finalarraypi1lo6[$j]=$tot_final;  ?>
<?php
$j++;
}
}
?>


<?php

$sql="SELECT COUNT(Roll_no) FROM SE5_A";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);


	for ($i=1; $i <=25 ; $i++) 
	{ 
 $sql1="SELECT COUNT(exp$i) FROM SE5_A WHERE exp$i>2";
 $result1=mysqli_query($conn,$sql1);
 $row1=mysqli_fetch_array($result1);

 $var=($row1[0]/$row[0])*100;
 $var1=round($var,2);
 $percenl11pi1lo6[$i]=$var1;

}
?>

<!-- <?php
echo "<pre>";
var_dump($percenl11pi1lo6);
?> -->

<?php
for ($i=1; $i <=25 ; $i++) 
{ 
?>
<?php $outoftenpi1lo6[$i]=$wpi1lo6[$i]*$percenl11pi1lo6[$i]/1000; ?>
<?php
}
?>

	<?php $totalbottompi1lo6=array_sum($outoftenpi1lo6); ?>


<?php
$at1=1;
$at2=2;
$at3=3;

for ($i=1; $i <=25 ; $i++) 
{ 
if($percenl11pi1lo6[$i]>=70)
	{?>
		<?php $Attlevelarraypi1lo6[$i]=$at3;  ?>
	<?php
	}
	elseif ($percenl11pi1lo6[$i]>=65) 
	{?>
		<?php $Attlevelarraypi1lo6[$i]=$at2;  ?>
	<?php
	}
	else
		{?>
			<?php $Attlevelarraypi1lo6[$i]=$at1; ?>
<?php
	}
}
?>

<?php
for ($i=1; $i <=25 ; $i++) 
	{$performancelevel=$performancelevel+($Attlevelarraypi1lo6[$i]*$wpi1lo6[$i]);
		?>
		
<?php
	}	
?><?php  $final_performancelevelpi1lo6=$performancelevel/100;  ?>

</body>
</html>