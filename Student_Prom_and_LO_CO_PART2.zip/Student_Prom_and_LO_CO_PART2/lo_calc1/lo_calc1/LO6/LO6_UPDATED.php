<?php
include 'dbConfig.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO6/pi1lo6_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO6/pi2lo6_updated.php';
include 'C:/xampp/htdocs/project/lo_calc1/LO6/pi3lo6_updated.php';

	$percenl11LO6=array();
	$row_value=array();
	$avg=array();
	$wLO6=array();
	$outoftenLO6=array();
	$LO6ARRAYPI1=array();
	$LO6ARRAYPI2=array();
	$LO6ARRAYPI2=array();
	$outoftenlo6=array();
	$LOPI1ARRAYLO6=array();
	$LO6TOTALROW=array();
	$tot_final=0;
	$count=0;
	$totalbottom=0;
	$count1=0;
	$count2=0;
	$count3=0;
	$performancelevel=0;
	$AttainmentLevelLO6=0;
	$AttainmentLevelLO6_final=0;
	$n=sizeof($tot_finalarraypi1lo6);
	$n1=sizeof($LO6ARRAYPI1);
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<title>LO_6</title>
</head>
<body>


				<?php
		
		$sql = "SELECT * FROM `laboutcome1` WHERE lo1_id  =6";
		$result=mysqli_query($conn,$sql);
		
		if ($result->num_rows > 0) {

			while(($row = $result->fetch_assoc())) 

			{
			?>

		<?php
		for ($i=1; $i <=3 ; $i++) { 
			?>
			<?php $wLO6[$i]=$row['lo1pi'.$i];  ?>
			<?php
			}
			?>
<?php
}
}
else{
echo "not working";
} 
?>

<?php 
$tot=0;
for ($i=1; $i <=3 ; $i++) { 
$tot=$tot+$wLO6[$i];
?>

<?php
}
?>


<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);
	

		if ($result_rollname->num_rows > 0) 
		{
			$i=0;
			$j=1;	
			$k=0;	
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>



	<?php $LO6ARRAYPI1[$i]=$tot_finalarraypi1lo6[$j]/5; ?>



	<?php $LO6ARRAYPI2[$i]=$totalrowpi2lo6[$j]/5;  ?>



	<?php $LO6ARRAYPI3[$i]=$tot_finalarraypi3lo6[$j]/5;  ?>




	<?php $LO6TOTALROW[$k]=$LO6ARRAYPI1[$k]+$LO6ARRAYPI2[$k]+$LO6ARRAYPI3[$k];  ?>


<?php
$i++;
$j++;
$k++;
}
}
?>

<?php
$j=1;
for ($i=0; $i <sizeof($LO6ARRAYPI1) ; $i++) { 
if ($LO6ARRAYPI1[$i]>=3) {
	?>
	<?php $count1++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count1/sizeof($LO6ARRAYPI1))*100;  $j++;?><

<?php
for ($i=0; $i <sizeof($LO6ARRAYPI2) ; $i++) { 
if ($LO6ARRAYPI2[$i]>=3) {
	?>
	<?php $count2++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count2/sizeof($LO6ARRAYPI2))*100;  $j++; ?>

<?php
for ($i=0; $i <sizeof($LO6ARRAYPI2) ; $i++) { 
if ($LO6ARRAYPI2[$i]>=3) {
	?>
	<?php $count3++; ?>
	<?php
}?>
<?php
}
?><?php $per1lo1[$j]=($count3/sizeof($LO6ARRAYPI2))*100;  $j++; ?>


<?php
for ($i=1; $i <=sizeof($per1lo1) ; $i++) { 
$outoftenlo6[$i]=($per1lo1[$i]*$wLO6[$i])/1000;
?>

<?php
}
?>	


	
<?php $LOPI1ARRAYLO6[1]=$final_performancelevelpi1lo6;  ?>
<?php $LOPI1ARRAYLO6[2]=$performancelevelfinalpi2lo6; ?>
<?php $LOPI1ARRAYLO6[3]=$totalperformancelevelpi3lo6;  ?>



<?php
for ($i=1; $i <sizeof($LOPI1ARRAYLO6) ; $i++) { 
$AttainmentLevelLO6=(($LOPI1ARRAYLO6[$i]*$wLO6[$i])+$AttainmentLevelLO6);
?>
<?php
}
?>	<?php $AttainmentLevelLO6_final=$AttainmentLevelLO6/100;  ?>


</body>
</html>