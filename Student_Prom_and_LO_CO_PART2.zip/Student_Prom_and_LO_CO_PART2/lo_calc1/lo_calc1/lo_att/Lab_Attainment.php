x<?php
include_once 'dbConfig.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO1/LO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO2/LO2_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO3/LO3_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO4/LO4_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO5/LO5_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO6/LO6_UPDATED.php';

include_once 'universitynew_UPDATED.php';
$wtgsub=array();
$Final_total_LO=0;
$x=0;
$AttLES=array();
$IA=array();
$wtgatt=array();
$LASTARRAY=array();
$attuni_var=0;
include('dbConfig.php');
			?>
<!DOCTYPE html>
<html>
<head>
	<title>Subject</title>
</head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<body>

<table class="table table-bordered">
	
		<tr><th colspan="2">Lab Outcome Number</th><th>Weightage in(%)</th>
			<?php
			for ($i=1; $i <=6; $i++) { 
				
				?>
				<th><?php echo "LO".$i; ?></th>
			<?php } ?>
			
			<th>Total</th></tr>
			<tr><th colspan="2">Weightage</th><th></th>
			<?php
			$sql= "SELECT * FROM `laboutcome_weightage` WHERE lowid=1";

			$result=mysqli_query($conn,$sql);
			$i=0;
			while ($row=mysqli_fetch_assoc($result)) 
			{	
				echo "<td>"; $wtgsub[1]=$row['lo1'];echo $row['lo1'];echo "</td>";
				echo "<td>"; $wtgsub[2]=$row['lo2'];echo $row['lo2'];echo "</td>";
				echo "<td>"; $wtgsub[3]=$row['lo3'];echo $row['lo3'];echo "</td>";
				echo "<td>"; $wtgsub[4]=$row['lo4'];echo $row['lo4'];echo "</td>";
				echo "<td>"; $wtgsub[5]=$row['lo5'];echo $row['lo5'];echo "</td>";
				echo "<td>"; $wtgsub[6]=$row['lo6'];echo $row['lo6'];echo "</td>";
				echo "<td>"; $wtgsub[7]=$row['Total'];echo $row['Total'];echo "</td>";

			}

			?>

		</tr>

		<tr>
			<th colspan="2">Attainment Level by Internal Assessment</th><td><?php $wtgatt[0]=48; echo $wtgatt[0]; ?></td>
			<td><?php $IA[0]=$AttainmentLevelLO1_final; echo $IA[0]; ?></td>
			<td><?php $IA[1]=$AttainmentLevelLO2_final; echo $IA[1]; ?></td>
			<td><?php $IA[2]=$AttainmentLevelLO3_final; echo $IA[2]; ?></td>
			<td><?php $IA[3]=$AttainmentLevelLO4_final; echo $IA[3]; ?></td>
			<td><?php $IA[4]=$AttainmentLevelLO5_final; echo $IA[4]; ?></td>
			<td><?php $IA[5]=$AttainmentLevelLO6_final; echo $IA[5]; ?></td>
		</tr>

		<tr>
			<th colspan="2">Attainment Level by University Direct Method</th><td><?php $wtgatt[1]=32; echo $wtgatt[1]; ?></td>
			<?php
			$attuni_var=$attuni[2];
			for ($i=0; $i <6; $i++) { 
				?>
				<td><?php echo $attuni_var; ?></td>
				<?php
			}
			?>
		</tr>

		<tr>
			<th colspan="2">Attainment Level by Lab Exit Survey</th><td><?php $wtgatt[2]=20; echo $wtgatt[2]; ?></td>
			<?php
			$sql3="SELECT Out_of_3 FROM `final_att_lab`";
			$result3=mysqli_query($conn,$sql3);
			$i=0;
			while ($row3=mysqli_fetch_assoc($result3)) 
			{	
				/*for ($i=0; $i <sizeof($IA) ; $i++) {*/
				
				$AttLES[$i]=$row3['Out_of_3'];

				echo "<td>";echo $AttLES[$i];echo "</td>";
				
			/*}*/
			$i++;
			}

			?>
		</tr>
		
		<tr>
			<th colspan="3">Attainment Level for each Lab Outcome</th>
			
				<?php $j=1;
				for ($i=0; $i <sizeof($IA) ; $i++) { 
					?>
					<td>
						<?php $LASTARRAY[$j]=(($IA[$i]*48)+($attuni_var*32)+($AttLES[$i]*20))/100; echo $LASTARRAY[$j]; ?>
					</td>
				<?php
				$j++; }
				 ?>
			
		</tr>


		<tr><th colspan="3">Total</th>
			<?php
			for ($i=1; $i <7; $i++) { 
				
				 $Final_total_LO=$Final_total_LO+($LASTARRAY[$i]*$wtgsub[$i])/100; 
				}?>
				<td><?php echo $Final_total_LO; ?></td>
		</tr><!-- <?php var_dump($AttLES); ?> <?php $x=sizeof($IA); echo $x; ?> -->