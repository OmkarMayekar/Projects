x<?php
include_once 'dbConfig.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO1/LO1_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO2/LO2_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO3/LO3_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO4/LO4_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO5/LO5_UPDATED.php';
include_once 'C:/xampp/htdocs/project/lo_calc1/LO6/LO6_UPDATED.php';
include_once 'universitynew_UPDATED.php';
$wtgsub=array();
$Final_total_LO=0;
$x=0;
$AttLES=array();
$IA=array();
$wtgatt=array();
$LASTARRAY=array();
$attuni_var=0;
include('dbConfig.php');
			?>
<!DOCTYPE html>
<html>
<head>
	<title>Subject</title>
</head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<body>

	


		
			<?php
			$sql= "SELECT * FROM `laboutcome_weightage` WHERE lowid=1";

			$result=mysqli_query($conn,$sql);
			$i=0;
			while ($row=mysqli_fetch_assoc($result)) 
			{	
				 $wtgsub[1]=$row['lo1'];
				 $wtgsub[2]=$row['lo2'];
				 $wtgsub[3]=$row['lo3'];
				 $wtgsub[4]=$row['lo4'];
				 $wtgsub[5]=$row['lo5'];
				 $wtgsub[6]=$row['lo6'];
				 $wtgsub[7]=$row['Total'];

			}

			?>

	<?php $wtgatt[0]=48;  ?>
			<?php $IA[0]=$AttainmentLevelLO1_final; ?>
			<?php $IA[1]=$AttainmentLevelLO2_final; ?>
			<?php $IA[2]=$AttainmentLevelLO3_final; ?>
			<?php $IA[3]=$AttainmentLevelLO4_final; ?>
			<?php $IA[4]=$AttainmentLevelLO5_final; ?>
			<?php $IA[5]=$AttainmentLevelLO6_final; ?>
		<

		
			<?php $wtgatt[1]=32; ?>
			<?php
			$attuni_var=$attuni[2];?>
			
			<?php $wtgatt[2]=20; ?>
			<?php
			$sql3="SELECT Out_of_3 FROM `final_att_lab`";
			$result3=mysqli_query($conn,$sql3);
			$i=0;
			while ($row3=mysqli_fetch_assoc($result3)) 
			{	
				/*for ($i=0; $i <sizeof($IA) ; $i++) {*/
				
				$AttLES[$i]=$row3['Out_of_3'];

				
				
			/*}*/
			$i++;
			}

			?>
		
			
				<?php $j=1;
				for ($i=0; $i <sizeof($IA) ; $i++) { 
					?>
					
						<?php $LASTARRAY[$j]=(($IA[$i]*48)+($attuni_var*32)+($AttLES[$i]*20))/100;?>
					
				<?php
				$j++; }
				 ?>
			
		
			<?php
			for ($i=1; $i <7; $i++) { 
				
				 $Final_total_LO=$Final_total_LO+($LASTARRAY[$i]*$wtgsub[$i])/100; 
				}?>
				
		<!-- <?php var_dump($AttLES); ?> <?php $x=sizeof($IA); echo $x; ?> -->