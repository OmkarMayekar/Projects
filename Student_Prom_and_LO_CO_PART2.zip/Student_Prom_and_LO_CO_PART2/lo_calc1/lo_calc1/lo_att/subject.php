<?php
include_once 'dbConfig.php';
include_once '../LO1/LO1_UPDATED.php';
include_once '../LO2/LO2_UPDATED.php';
include_once '../LO3/LO3_UPDATED.php';
include_once '../LO4/LO4_UPDATED.php';
include_once '../LO5/LO5_UPDATED.php';
include_once '../LO6/LO6_UPDATED.php';
$wtgsub=array();
$count1_sub=0;
$count2_sub=0;
$count3_sub=0;
$count4_sub=0;
$count5_sub=0;
$count6_sub=0;
$per1lo1_sub=array();
$outoftenlo1_sub=array();
include('dbConfig.php');
			?>
<!DOCTYPE html>
<html>
<head>
	<title>Subject</title>
</head><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<body>

<table class="table table-bordered">
	
		<tr><th colspan="2">Lab Outcome Number</th>
			<?php
			for ($i=1; $i <=6; $i++) { 
				
				?>
				<th><?php echo "LO".$i; ?></th>
			<?php } ?>
			
			<th>Total</th></tr>
		<tr><th colspan="2">Weightage</th>
			<?php
			$sql= "SELECT * FROM `laboutcome_weightage` WHERE lowid=1";

			$result=mysqli_query($conn,$sql);
			while ($row=mysqli_fetch_assoc($result)) 
			{
				echo "<td>"; $wtgsub[1]=$row['lo1'];echo $row['lo1'];echo "</td>";
				echo "<td>"; $wtgsub[2]=$row['lo2'];echo $row['lo2'];echo "</td>";
				echo "<td>"; $wtgsub[3]=$row['lo3'];echo $row['lo3'];echo "</td>";
				echo "<td>"; $wtgsub[4]=$row['lo4'];echo $row['lo4'];echo "</td>";
				echo "<td>"; $wtgsub[5]=$row['lo5'];echo $row['lo5'];echo "</td>";
				echo "<td>"; $wtgsub[6]=$row['lo6'];echo $row['lo6'];echo "</td>";
				echo "<td>"; $wtgsub[7]=$row['Total'];echo $row['Total'];echo "</td>";

			}

			?>

		</tr>
		<tr>
<th>Roll no</th>
<th>Name</th></tr>

<?php
	$sql_rollname = "SELECT se5a.Roll_no,IA1.Name FROM SE5_A AS se5a INNER JOIN SE5_IA_1 AS IA1 ON IA1.Roll_no=se5a.Roll_no INNER JOIN SE5_LO_ASGNMT_MINI_PROJECT AS \n"."SE5LMINI ON SE5LMINI.Roll_No= IA1.Roll_no";
    $result_rollname=mysqli_query($conn,$sql_rollname);





	if ($result_rollname->num_rows > 0) 
		{
			$i=0;
		while(($row_rollname = $result_rollname->fetch_assoc())) 

		{
?>
<tr>
<td><?php echo $row_rollname['Roll_no']; ?></td>
<td><?php echo $row_rollname['Name']; ?></td>

<td><?php $SUB_LO1TOTALROW[$i]=$LO1TOTALROW[$i]/20; echo $SUB_LO1TOTALROW[$i];?></td>
<td><?php $SUB_LO2TOTALROW[$i]=$LO2TOTALROW[$i]/20; echo $SUB_LO2TOTALROW[$i];?></td>
<td><?php $SUB_LO3TOTALROW[$i]=$LO3TOTALROW[$i]/20; echo $SUB_LO3TOTALROW[$i];?></td>
<td><?php $SUB_LO4TOTALROW[$i]=$LO4TOTALROW[$i]/20; echo $SUB_LO4TOTALROW[$i];?></td>
<td><?php $SUB_LO5TOTALROW[$i]=$LO5TOTALROW[$i]/20; echo $SUB_LO5TOTALROW[$i];?></td>
<td><?php $SUB_LO6TOTALROW[$i]=$LO6TOTALROW[$i]/20; echo $SUB_LO6TOTALROW[$i];?></td>
<td><?php $SUB_TOTAL[$i]=$SUB_LO1TOTALROW[$i]+$SUB_LO2TOTALROW[$i]+$SUB_LO3TOTALROW[$i]+$SUB_LO4TOTALROW[$i]+$SUB_LO5TOTALROW[$i]+$SUB_LO6TOTALROW[$i]; echo $SUB_TOTAL[$i]; ?></td>

<?php
$i++;
}
}
?>
</tr>

<tr>
<th colspan="2">% of Students getting equal or more than 60%</th>
<?php
$j=1;
for ($i=0; $i <sizeof($SUB_LO1TOTALROW) ; $i++) { 
if ($SUB_LO1TOTALROW[$i]>=3) {
	?>
	<?php $count1_sub++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1_sub[$j]=($count1_sub/sizeof($SUB_LO1TOTALROW))*100; echo $per1lo1_sub[$j]; $j++;?></td>

<?php
for ($i=0; $i <sizeof($SUB_LO2TOTALROW) ; $i++) { 
if ($SUB_LO2TOTALROW[$i]>=3) {
	?>
	<?php $count2_sub++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1_sub[$j]=($count2_sub/sizeof($SUB_LO2TOTALROW))*100; echo $per1lo1_sub[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($SUB_LO3TOTALROW) ; $i++) { 
if ($SUB_LO3TOTALROW[$i]>=3) {
	?>
	<?php $count3_sub++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1_sub[$j]=($count3_sub/sizeof($SUB_LO3TOTALROW))*100; echo $per1lo1_sub[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($SUB_LO4TOTALROW) ; $i++) { 
if ($SUB_LO4TOTALROW[$i]>=3) {
	?>
	<?php $count4_sub++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1_sub[$j]=($count4_sub/sizeof($SUB_LO4TOTALROW))*100; echo $per1lo1_sub[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($SUB_LO5TOTALROW) ; $i++) { 
if ($SUB_LO5TOTALROW[$i]>=3) {
	?>
	<?php $count5_sub++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1_sub[$j]=($count5_sub/sizeof($SUB_LO5TOTALROW))*100; echo $per1lo1_sub[$j]; $j++; ?></td>

<?php
for ($i=0; $i <sizeof($SUB_LO6TOTALROW) ; $i++) { 
if ($SUB_LO6TOTALROW[$i]>=3) {
	?>
	<?php $count6_sub++; ?>
	<?php
}?>
<?php
}
?><td><?php $per1lo1_sub[$j]=($count6_sub/sizeof($SUB_LO6TOTALROW))*100; echo $per1lo1_sub[$j]; $j++; ?></td>

</tr>
<tr><th colspan="2">Out Of Ten</th>
<?php
for ($i=1; $i <=sizeof($per1lo1_sub) ; $i++) { 
$outoftenlo1_sub[$i]=($per1lo1_sub[$i]*$wtgsub[$i])/1000;
?>
<td><?php echo $outoftenlo1_sub[$i]; ?></td>
<?php
}
?>	
</tr>

<tr>
	<th colspan="2">Total</th>
	<td><?php echo array_sum($outoftenlo1_sub); ?></td>
</tr>

</thead>
</table>


</body>
</html>